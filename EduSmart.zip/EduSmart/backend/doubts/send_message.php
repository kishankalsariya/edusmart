<?php
ob_start();
session_start();
include("../config/connection.php");
header('Content-Type: application/json');

$role    = $_SESSION['role'] ?? '';
$user_id = (int)($_SESSION['user_id'] ?? 0);
if (!$user_id || !in_array($role, ['student', 'teacher'])) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$data      = json_decode(file_get_contents('php://input'), true);
$message   = trim($data['message'] ?? '');
$other_id  = (int)($data['with'] ?? 0);

if (!$message || !$other_id) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Missing data']);
    exit();
}

if ($role === 'student') {
    $sq = $conn->prepare("SELECT student_id FROM students WHERE user_id=?");
    $sq->bind_param("i", $user_id);
    $sq->execute();
    $srow = $sq->get_result()->fetch_assoc();
    $sq->close();
    $student_id = $srow ? $srow['student_id'] : 0;
    $teacher_id = $other_id;
    $sent_by    = 'student';
} else {
    $tq = $conn->prepare("SELECT teacher_id FROM teachers WHERE user_id=?");
    $tq->bind_param("i", $user_id);
    $tq->execute();
    $trow = $tq->get_result()->fetch_assoc();
    $tq->close();
    $teacher_id = $trow ? $trow['teacher_id'] : 0;
    $student_id = $other_id;
    $sent_by    = 'teacher';
}

if (!$student_id || !$teacher_id) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Invalid IDs']);
    exit();
}

$ins = $conn->prepare("INSERT INTO doubts (student_id, teacher_id, message, sent_by) VALUES (?,?,?,?)");
$ins->bind_param("iiss", $student_id, $teacher_id, $message, $sent_by);
$ins->execute();
$new_id = $conn->insert_id;
$ins->close();

ob_end_clean();
echo json_encode(['success' => true, 'doubt_id' => $new_id]);

?>