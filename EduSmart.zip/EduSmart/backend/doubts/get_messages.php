<?php
ob_start();
session_start();
include("../config/connection.php");
header('Content-Type: application/json');

$role    = $_SESSION['role'] ?? '';
$user_id = (int)($_SESSION['user_id'] ?? 0);
if (!$user_id || !in_array($role, ['student', 'teacher'])) {
    ob_end_clean();
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$other_id  = (int)($_GET['with'] ?? 0);
$after_id  = (int)($_GET['after'] ?? 0);  // for polling — only fetch new

if (!$other_id) {
    ob_end_clean();
    echo json_encode(['messages' => []]);
    exit();
}

if ($role === 'student') {
    $sq = $conn->prepare("SELECT student_id FROM students WHERE user_id=?");
    $sq->bind_param("i", $user_id);
    $sq->execute();
    $srow = $sq->get_result()->fetch_assoc();
    $sq->close();
    $student_id  = $srow ? $srow['student_id'] : 0;
    $teacher_id  = $other_id;
} else {
    $tq = $conn->prepare("SELECT teacher_id FROM teachers WHERE user_id=?");
    $tq->bind_param("i", $user_id);
    $tq->execute();
    $trow = $tq->get_result()->fetch_assoc();
    $tq->close();
    $teacher_id  = $trow ? $trow['teacher_id'] : 0;
    $student_id  = $other_id;
}

if (!$student_id || !$teacher_id) {
    ob_end_clean();
    echo json_encode(['messages' => []]);
    exit();
}

// Mark incoming messages as read
if ($role === 'student') {
    $conn->query("UPDATE doubts SET is_read=1 WHERE student_id=$student_id AND teacher_id=$teacher_id AND sent_by='teacher' AND is_read=0");
} else {
    $conn->query("UPDATE doubts SET is_read=1 WHERE student_id=$student_id AND teacher_id=$teacher_id AND sent_by='student' AND is_read=0");
}

// Fetch messages
$sql  = "SELECT doubt_id, message, sent_by, is_read, created_at FROM doubts WHERE student_id=? AND teacher_id=?";
$args = [$student_id, $teacher_id];
$types = "ii";
if ($after_id > 0) {
    $sql .= " AND doubt_id > ?";
    $args[] = $after_id;
    $types .= "i";
}
$sql .= " ORDER BY created_at ASC LIMIT 200";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$args);
$stmt->execute();
$messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

ob_end_clean();
echo json_encode(['messages' => $messages]);

?>