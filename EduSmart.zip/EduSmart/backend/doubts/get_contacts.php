<?php
ob_start();
session_start();
include("../config/connection.php");
header('Content-Type: application/json');

$role    = $_SESSION['role'] ?? '';
$user_id = (int)($_SESSION['user_id'] ?? 0);
if (!$user_id || !in_array($role, ['student','teacher'])) {
    ob_end_clean(); echo json_encode(['error'=>'Unauthorized']); exit();
}

if ($role === 'student') {
    $sq = $conn->prepare("SELECT student_id FROM students WHERE user_id=?");
    $sq->bind_param("i",$user_id); $sq->execute();
    $srow = $sq->get_result()->fetch_assoc(); $sq->close();
    if (!$srow) { ob_end_clean(); echo json_encode(['role'=>'student','my_id'=>0,'contacts'=>[]]); exit(); }
    $student_id = $srow['student_id'];

    $q = $conn->prepare("
        SELECT DISTINCT
            t.teacher_id,
            u.name AS teacher_name,
            GROUP_CONCAT(DISTINCT s.subject_name ORDER BY s.subject_name SEPARATOR ', ') AS subjects,
            (SELECT d.message FROM doubts d WHERE d.student_id=? AND d.teacher_id=t.teacher_id ORDER BY d.created_at DESC LIMIT 1) AS last_msg,
            (SELECT d.created_at FROM doubts d WHERE d.student_id=? AND d.teacher_id=t.teacher_id ORDER BY d.created_at DESC LIMIT 1) AS last_time,
            (SELECT COUNT(*) FROM doubts d WHERE d.student_id=? AND d.teacher_id=t.teacher_id AND d.sent_by='teacher' AND d.is_read=0) AS unread
        FROM subject_teacher_assignment sta
        JOIN teachers t ON sta.teacher_id=t.teacher_id
        JOIN users u ON t.user_id=u.id
        JOIN subjects s ON sta.subject_id=s.subject_id
        JOIN students stu ON stu.semester_id=sta.semester_id AND stu.division_id=sta.division_id
        WHERE stu.student_id=? AND sta.status='active'
        GROUP BY t.teacher_id, u.name
        ORDER BY last_time DESC, u.name
    ");
    $q->bind_param("iiii",$student_id,$student_id,$student_id,$student_id);
    $q->execute();
    $contacts = $q->get_result()->fetch_all(MYSQLI_ASSOC);
    $q->close();
    ob_end_clean();
    echo json_encode(['role'=>'student','my_id'=>$student_id,'contacts'=>$contacts]);

} else {
    $tq = $conn->prepare("SELECT teacher_id FROM teachers WHERE user_id=?");
    $tq->bind_param("i",$user_id); $tq->execute();
    $trow = $tq->get_result()->fetch_assoc(); $tq->close();
    if (!$trow) { ob_end_clean(); echo json_encode(['role'=>'teacher','my_id'=>0,'contacts'=>[]]); exit(); }
    $teacher_id = $trow['teacher_id'];

    $q = $conn->prepare("
        SELECT DISTINCT
            s.student_id,
            u.name AS student_name,
            s.roll_no,
            sem.semester_no,
            dv.division_name,
            (SELECT db.message FROM doubts db WHERE db.student_id=s.student_id AND db.teacher_id=? ORDER BY db.created_at DESC LIMIT 1) AS last_msg,
            (SELECT db.created_at FROM doubts db WHERE db.student_id=s.student_id AND db.teacher_id=? ORDER BY db.created_at DESC LIMIT 1) AS last_time,
            (SELECT COUNT(*) FROM doubts db WHERE db.student_id=s.student_id AND db.teacher_id=? AND db.sent_by='student' AND db.is_read=0) AS unread
        FROM subject_teacher_assignment sta
        JOIN students s ON s.semester_id=sta.semester_id AND s.division_id=sta.division_id
        JOIN users u ON s.user_id=u.id
        JOIN semesters sem ON s.semester_id=sem.semester_id
        JOIN divisions dv ON s.division_id=dv.division_id
        WHERE sta.teacher_id=? AND sta.status='active'
        ORDER BY last_time DESC, u.name
    ");
    $q->bind_param("iiii",$teacher_id,$teacher_id,$teacher_id,$teacher_id);
    $q->execute();
    $contacts = $q->get_result()->fetch_all(MYSQLI_ASSOC);
    $q->close();
    ob_end_clean();
    echo json_encode(['role'=>'teacher','my_id'=>$teacher_id,'contacts'=>$contacts]);
}

?>