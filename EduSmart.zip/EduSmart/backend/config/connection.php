<?php
$conn = new mysqli("localhost", "root", "", "edusmart");

if ($conn->connect_error) {
    die("Database connection failed");
}
?>
