<?php
session_start();
include("../config/connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$user_id = $_SESSION['user_id'];
$academic_year = date('Y') . '-' . (date('Y') + 1);

// Get teacher_id
$t = $conn->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$t->bind_param("i", $user_id);
$t->execute();
$teacher = $t->get_result()->fetch_assoc();

if (!$teacher) {
    echo json_encode(['error' => 'Teacher not found']);
    exit();
}

$teacher_id = $teacher['teacher_id'];

// Get all assigned classes with subject info
$stmt = $conn->prepare("
    SELECT 
        sta.subject_id,
        sta.semester_id,
        sta.division_id,
        s.subject_name,
        sem.semester_no,
        d.division_name
    FROM subject_teacher_assignment sta
    JOIN subjects s ON sta.subject_id = s.subject_id
    JOIN semesters sem ON sta.semester_id = sem.semester_id
    JOIN divisions d ON sta.division_id = d.division_id
    WHERE sta.teacher_id = ?
      AND sta.academic_year = ?
      AND sta.status = 'active'
    ORDER BY sem.semester_no, d.division_name, s.subject_name
");
$stmt->bind_param("is", $teacher_id, $academic_year);
$stmt->execute();
$result = $stmt->get_result();

$classes = [];
while ($row = $result->fetch_assoc()) {
    $classes[] = $row;
}

header('Content-Type: application/json');
echo json_encode($classes);
?>
