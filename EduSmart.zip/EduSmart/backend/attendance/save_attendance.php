<?php
session_start();
include("../config/connection.php");

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Only allow teachers
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$user_id = $_SESSION['user_id'];

// Get teacher_id
$t = $conn->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$t->bind_param("i", $user_id);
$t->execute();
$teacher = $t->get_result()->fetch_assoc();

if (!$teacher) {
    echo json_encode(['success' => false, 'message' => 'Teacher not found']);
    exit();
}
$teacher_id = $teacher['teacher_id'];

// Parse input
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'Invalid data']);
    exit();
}

$semester_id = (int)($data['semester_id'] ?? 0);
$division_id  = (int)($data['division_id']  ?? 0);
$subject_id   = (int)($data['subject_id']   ?? 0);
$records      = $data['records'] ?? [];

// Validate required fields
if (!$semester_id || !$division_id || !$subject_id || empty($records)) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit();
}

// Validate and sanitize date
$date = $data['date'] ?? '';
$date = trim($date);

// Use DateTime to strictly validate
try {
    $dt = new DateTime($date);
    $date = $dt->format('Y-m-d'); // ensures proper YYYY-MM-DD format
} catch (Exception $e) {
    $date = date('Y-m-d'); // fallback to today if invalid
}

// Check if attendance already submitted
$check = $conn->prepare("
    SELECT COUNT(*) as cnt 
    FROM attendance
    WHERE semester_id = ? AND division_id = ? AND subject_id = ? AND attendance_date = ?
");
$check->bind_param("iiis", $semester_id, $division_id, $subject_id, $date);
$check->execute();
$existing = $check->get_result()->fetch_assoc();

if ($existing['cnt'] > 0) {
    echo json_encode(['success' => false, 'message' => 'Attendance already submitted for this class and date']);
    exit();
}

// Prepare insert statement
$stmt = $conn->prepare("
    INSERT INTO attendance (student_id, semester_id, division_id, subject_id, teacher_id, attendance_date, status)
    VALUES (?, ?, ?, ?, ?, ?, ?)
");

$conn->begin_transaction();

try {
    foreach ($records as $rec) {
        $student_id = (int)($rec['student_id'] ?? 0);
        $status     = ($rec['status'] === 'present') ? 'present' : 'absent';

        if (!$student_id) {
            throw new Exception("Invalid student_id in records");
        }

        $stmt->bind_param("iiiiiss", $student_id, $semester_id, $division_id, $subject_id, $teacher_id, $date, $status);
        $stmt->execute();
    }

    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Attendance submitted successfully', 'date' => $date]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => 'Failed to save attendance: ' . $e->getMessage()]);
}
?>