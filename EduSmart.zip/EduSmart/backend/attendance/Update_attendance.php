<?php
ob_start();
session_start();
include("../config/connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    ob_end_clean(); header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']); exit();
}

$user_id = $_SESSION['user_id'];

// Get teacher_id
$t = $conn->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$t->bind_param("i", $user_id); $t->execute();
$teacher = $t->get_result()->fetch_assoc();
if (!$teacher) {
    ob_end_clean(); header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Teacher not found']); exit();
}
$teacher_id = $teacher['teacher_id'];

$data = json_decode(file_get_contents('php://input'), true);
if (!$data) {
    ob_end_clean(); header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid input']); exit();
}

$student_id  = (int)($data['student_id']  ?? 0);
$subject_id  = (int)($data['subject_id']  ?? 0);
$semester_id = (int)($data['semester_id'] ?? 0);
$division_id = (int)($data['division_id'] ?? 0);
$date        = trim($data['date']         ?? '');
$new_status  = trim($data['status']       ?? '');

if (!$student_id || !$subject_id || !$semester_id || !$division_id || $date === '' || !in_array($new_status, ['present','absent'])) {
    ob_end_clean(); header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Missing or invalid fields']); exit();
}

// Check if record exists
$chk = $conn->prepare("
    SELECT attendance_id FROM attendance
    WHERE student_id=? AND subject_id=? AND semester_id=? AND division_id=? AND teacher_id=? AND attendance_date=?
");
$chk->bind_param("iiiiis", $student_id, $subject_id, $semester_id, $division_id, $teacher_id, $date);
$chk->execute();
$existing = $chk->get_result()->fetch_assoc();
$chk->close();

if ($existing) {
    // UPDATE existing record
    $upd = $conn->prepare("UPDATE attendance SET status=? WHERE attendance_id=?");
    $upd->bind_param("si", $new_status, $existing['attendance_id']);
    $upd->execute();
    $upd->close();
} else {
    // INSERT new record
    $ins = $conn->prepare("
        INSERT INTO attendance (student_id, semester_id, division_id, subject_id, teacher_id, attendance_date, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $ins->bind_param("iiiiiss", $student_id, $semester_id, $division_id, $subject_id, $teacher_id, $date, $new_status);
    $ins->execute();
    $ins->close();
}

ob_end_clean();
header('Content-Type: application/json');
echo json_encode(['success' => true, 'message' => 'Attendance updated.', 'status' => $new_status]);