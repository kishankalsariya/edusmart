<?php
ob_start();
session_start();
include("../config/connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    ob_end_clean(); header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']); exit();
}

$user_id = $_SESSION['user_id'];

// Get teacher_id
$t = $conn->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$t->bind_param("i", $user_id); $t->execute();
$teacher = $t->get_result()->fetch_assoc();
if (!$teacher) {
    ob_end_clean(); header('Content-Type: application/json');
    echo json_encode(['error' => 'Teacher not found']); exit();
}
$teacher_id = $teacher['teacher_id'];

// Inputs
$subject_id  = isset($_GET['subject_id'])  ? (int)$_GET['subject_id']  : 0;
$semester_id = isset($_GET['semester_id']) ? (int)$_GET['semester_id'] : 0;
$division_id = isset($_GET['division_id']) ? (int)$_GET['division_id'] : 0;
$date        = isset($_GET['date']) && $_GET['date'] !== '' ? trim($_GET['date']) : '';
$search      = isset($_GET['search']) ? trim($_GET['search']) : '';

if (!$subject_id || !$semester_id || !$division_id) {
    ob_end_clean(); header('Content-Type: application/json');
    echo json_encode(['error' => 'Please select a class.']); exit();
}
if ($date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    ob_end_clean(); header('Content-Type: application/json');
    echo json_encode(['error' => 'Please select a valid date.']); exit();
}

// ── Step 1: Check if lecture exists for this subject/division on that weekday ─
$day_name = date('l', strtotime($date)); // e.g. "Monday"

$lec = $conn->prepare("
    SELECT COUNT(*) AS cnt
    FROM division_subject_teacher dst
    JOIN timetable t ON dst.dst_id = t.dst_id
    WHERE dst.semester_id = ?
      AND dst.division_id = ?
      AND dst.subject_id  = ?
      AND t.day = ?
");
if (!$lec) {
    ob_end_clean(); header('Content-Type: application/json');
    echo json_encode(['error' => 'Lecture check error: ' . $conn->error]); exit();
}
$lec->bind_param("iiis", $semester_id, $division_id, $subject_id, $day_name);
$lec->execute();
$lec_cnt = (int)$lec->get_result()->fetch_assoc()['cnt'];
$lec->close();

if ($lec_cnt === 0) {
    ob_end_clean(); header('Content-Type: application/json');
    echo json_encode([
        'no_lecture' => true,
        'day'        => $day_name,
        'date'       => $date,
    ]); exit();
}

// ── Step 2: Check if attendance already submitted ─────────────────────────────
$chk = $conn->prepare("
    SELECT COUNT(*) AS cnt FROM attendance
    WHERE teacher_id=? AND subject_id=? AND semester_id=? AND division_id=? AND attendance_date=?
");
$chk->bind_param("iiiis", $teacher_id, $subject_id, $semester_id, $division_id, $date);
$chk->execute();
$attendance_taken = (int)$chk->get_result()->fetch_assoc()['cnt'] > 0;
$chk->close();

// ── Step 3: Fetch students with their attendance status ───────────────────────
$sql    = "
    SELECT
        s.student_id,
        s.roll_no,
        u.name AS student_name,
        s.gender,
        COALESCE(a.status, 'not_taken') AS status,
        a.attendance_id
    FROM students s
    JOIN users u ON s.user_id = u.id
    LEFT JOIN attendance a
        ON  a.student_id     = s.student_id
        AND a.subject_id     = ?
        AND a.semester_id    = ?
        AND a.division_id    = ?
        AND a.teacher_id     = ?
        AND a.attendance_date = ?
    WHERE s.semester_id = ? AND s.division_id = ?
";
$types  = "iiiisii";
$params = [$subject_id, $semester_id, $division_id, $teacher_id, $date, $semester_id, $division_id];

if ($search !== '') {
    $like    = '%' . $search . '%';
    $sql    .= " AND (u.name LIKE ? OR s.roll_no LIKE ?)";
    $types  .= "ss"; $params[] = $like; $params[] = $like;
}
$sql .= " ORDER BY CAST(s.roll_no AS UNSIGNED), s.roll_no";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    ob_end_clean(); header('Content-Type: application/json');
    echo json_encode(['error' => 'Query error: ' . $conn->error]); exit();
}
$stmt->bind_param($types, ...$params);
$stmt->execute();
$students = [];
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) { $students[] = $row; }
$stmt->close();

$present = 0; $absent = 0;
foreach ($students as $s) {
    if ($s['status'] === 'present') $present++;
    if ($s['status'] === 'absent')  $absent++;
}

ob_end_clean();
header('Content-Type: application/json');
echo json_encode([
    'no_lecture'       => false,
    'students'         => $students,
    'attendance_taken' => $attendance_taken,
    'total'            => count($students),
    'present'          => $present,
    'absent'           => $absent,
    'date'             => $date,
    'day'              => $day_name,
]);