<?php
ob_start();
session_start();
include("../config/connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$user_id = $_SESSION['user_id'];

$t = $conn->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$t->bind_param("i", $user_id);
$t->execute();
$teacher = $t->get_result()->fetch_assoc();
if (!$teacher) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Teacher not found']);
    exit();
}
$teacher_id = $teacher['teacher_id'];

$subject_id  = isset($_GET['subject_id'])  ? (int)$_GET['subject_id']  : 0;
$semester_id = isset($_GET['semester_id']) ? (int)$_GET['semester_id'] : 0;
$division_id = isset($_GET['division_id']) ? (int)$_GET['division_id'] : 0;
$search      = isset($_GET['search'])      ? trim($_GET['search'])      : '';
$filter      = isset($_GET['filter'])      ? trim($_GET['filter'])      : 'all';

if (!$subject_id || !$semester_id || !$division_id) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Please select a class.']);
    exit();
}

// Total lectures conducted
$lec = $conn->prepare("
    SELECT COUNT(DISTINCT attendance_date) AS total_lectures
    FROM attendance
    WHERE teacher_id=? AND subject_id=? AND semester_id=? AND division_id=?
");
$lec->bind_param("iiii", $teacher_id, $subject_id, $semester_id, $division_id);
$lec->execute();
$total_lectures = (int)$lec->get_result()->fetch_assoc()['total_lectures'];
$lec->close();

// Per-student query
$sql = "
    SELECT
        s.student_id,
        s.roll_no,
        u.name                    AS student_name,
        s.gender,
        SUM(a.status='present')   AS attended,
        SUM(a.status='absent')    AS absent_count
    FROM students s
    JOIN users u ON s.user_id = u.id
    LEFT JOIN attendance a
        ON  a.student_id  = s.student_id
        AND a.subject_id  = ?
        AND a.semester_id = ?
        AND a.division_id = ?
        AND a.teacher_id  = ?
    WHERE s.semester_id = ? AND s.division_id = ?
";
$types  = "iiiiii";
$params = [$subject_id, $semester_id, $division_id, $teacher_id, $semester_id, $division_id];

if ($search !== '') {
    $like    = '%' . $search . '%';
    $sql    .= " AND (u.name LIKE ? OR s.roll_no LIKE ?)";
    $types  .= "ss";
    $params[] = $like;
    $params[] = $like;
}
$sql .= " GROUP BY s.student_id, s.roll_no, u.name, s.gender
          ORDER BY CAST(s.roll_no AS UNSIGNED), s.roll_no";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Query error: ' . $conn->error]);
    exit();
}
$stmt->bind_param($types, ...$params);
$stmt->execute();

$all_students = [];
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $attended = (int)$row['attended'];
    $pct      = $total_lectures > 0 ? round(($attended / $total_lectures) * 100, 1) : 0;
    $row['attended']       = $attended;
    $row['absent_count']   = (int)$row['absent_count'];
    $row['total_lectures'] = $total_lectures;
    $row['pct']            = $pct;
    $row['grade']          = $pct >= 75 ? 'safe' : ($pct >= 60 ? 'risk' : 'critical');
    $all_students[] = $row;
}
$stmt->close();

// Summary counts from full list
$safe = $risk = $critical = 0;
foreach ($all_students as $s) {
    if ($s['grade'] === 'safe')     $safe++;
    elseif ($s['grade'] === 'risk')     $risk++;
    else                                 $critical++;
}

// Apply filter for returned list
$students = $filter === 'all'
    ? $all_students
    : array_values(array_filter($all_students, fn ($s) => $s['grade'] === $filter));

ob_end_clean();
header('Content-Type: application/json');
echo json_encode([
    'students'       => $students,
    'total_lectures' => $total_lectures,
    'total_students' => count($all_students),
    'safe'           => $safe,
    'risk'           => $risk,
    'critical'       => $critical,
]);
