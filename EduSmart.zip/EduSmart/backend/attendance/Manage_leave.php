<?php
ob_start();
session_start();
include("../config/connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$user_id = $_SESSION['user_id'];

// Get teacher_id
$t = $conn->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$t->bind_param("i", $user_id);
$t->execute();
$teacher = $t->get_result()->fetch_assoc();
if (!$teacher) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Teacher not found']);
    exit();
}
$teacher_id = $teacher['teacher_id'];

$data        = json_decode(file_get_contents('php://input'), true);
$action      = $data['action']      ?? ''; // 'apply' or 'cancel'
$subject_id  = (int)($data['subject_id']  ?? 0);
$semester_id = (int)($data['semester_id'] ?? 0);
$division_id = (int)($data['division_id'] ?? 0);
$leave_date  = trim($data['leave_date']   ?? date('Y-m-d'));
$reason      = trim($data['reason']       ?? '');

if (!$subject_id || !$semester_id || !$division_id) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Missing class info']);
    exit();
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $leave_date)) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid date']);
    exit();
}

if ($action === 'apply') {
    // Check attendance already submitted — can't take leave after attendance
    $chk = $conn->prepare("
        SELECT COUNT(*) AS cnt FROM attendance
        WHERE teacher_id=? AND subject_id=? AND semester_id=? AND division_id=? AND attendance_date=?
    ");
    $chk->bind_param("iiiis", $teacher_id, $subject_id, $semester_id, $division_id, $leave_date);
    $chk->execute();
    $cnt = (int)$chk->get_result()->fetch_assoc()['cnt'];
    $chk->close();
    if ($cnt > 0) {
        ob_end_clean();
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Attendance already submitted for this class. Cannot apply leave.']);
        exit();
    }

    // Insert leave
    $ins = $conn->prepare("
        INSERT INTO teacher_leaves (teacher_id, subject_id, semester_id, division_id, leave_date, reason)
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE reason = VALUES(reason), applied_at = NOW()
    ");
    $ins->bind_param("iiiiss", $teacher_id, $subject_id, $semester_id, $division_id, $leave_date, $reason);
    $ins->execute();
    if ($ins->error) {
        ob_end_clean();
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'DB error: ' . $ins->error]);
        exit();
    }
    $ins->close();

    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => 'Leave applied successfully.']);
} elseif ($action === 'cancel') {
    $del = $conn->prepare("
        DELETE FROM teacher_leaves
        WHERE teacher_id=? AND subject_id=? AND semester_id=? AND division_id=? AND leave_date=?
    ");
    $del->bind_param("iiiis", $teacher_id, $subject_id, $semester_id, $division_id, $leave_date);
    $del->execute();
    $del->close();

    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => 'Leave cancelled.']);
} else {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}


?>