<?php
ob_start();
session_start();
include("../config/connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$semester_id = isset($_GET['semester_id']) ? (int)$_GET['semester_id'] : 0;
$division_id = isset($_GET['division_id']) ? (int)$_GET['division_id'] : 0;
$subject_id  = isset($_GET['subject_id'])  ? (int)$_GET['subject_id']  : 0;
$date        = isset($_GET['date']) && $_GET['date'] !== '' ? trim($_GET['date']) : date('Y-m-d');

if (!$semester_id || !$division_id || !$subject_id) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Missing parameters']);
    exit();
}

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Invalid date']);
    exit();
}

// ── Step 1: Check lecture exists for this subject/division on selected weekday ─
$day_name = date('l', strtotime($date)); // e.g. "Monday"

$lec = $conn->prepare("
    SELECT COUNT(*) AS cnt
    FROM division_subject_teacher dst
    JOIN timetable t ON dst.dst_id = t.dst_id
    WHERE dst.semester_id = ?
      AND dst.division_id = ?
      AND dst.subject_id  = ?
      AND t.day = ?
");
if (!$lec) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'DB error: ' . $conn->error]);
    exit();
}
$lec->bind_param("iiis", $semester_id, $division_id, $subject_id, $day_name);
$lec->execute();
$has_lecture = (int)$lec->get_result()->fetch_assoc()['cnt'] > 0;
$lec->close();

if (!$has_lecture) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode([
        'no_lecture' => true,
        'day'        => $day_name,
        'date'       => $date,
    ]);
    exit();
}

// ── Step 1b: Check teacher is not on leave for this class ─────────────────────
// Get teacher_id from session user
$tu = $conn->prepare("SELECT t.teacher_id FROM teachers t WHERE t.user_id = ?");
$tu->bind_param("i", $_SESSION['user_id']);
$tu->execute();
$tu_row = $tu->get_result()->fetch_assoc();
$tu->close();
$teacher_id_check = $tu_row ? (int)$tu_row['teacher_id'] : 0;

if ($teacher_id_check) {
    $lv = $conn->prepare("
        SELECT reason FROM teacher_leaves
        WHERE teacher_id=? AND subject_id=? AND semester_id=? AND division_id=? AND leave_date=?
    ");
    $lv->bind_param("iiiis", $teacher_id_check, $subject_id, $semester_id, $division_id, $date);
    $lv->execute();
    $lv_row = $lv->get_result()->fetch_assoc();
    $lv->close();

    if ($lv_row !== null) {
        ob_end_clean();
        header('Content-Type: application/json');
        echo json_encode([
            'on_leave' => true,
            'reason'   => $lv_row['reason'],
            'date'     => $date,
        ]);
        exit();
    }
}
$check = $conn->prepare("
    SELECT COUNT(*) AS cnt FROM attendance
    WHERE semester_id=? AND division_id=? AND subject_id=? AND attendance_date=?
");
$check->bind_param("iiis", $semester_id, $division_id, $subject_id, $date);
$check->execute();
$already_submitted = (int)$check->get_result()->fetch_assoc()['cnt'] > 0;
$check->close();

// ── Step 3: Get students ──────────────────────────────────────────────────────
$stmt = $conn->prepare("
    SELECT s.student_id, s.roll_no, u.name, s.gender
    FROM students s
    JOIN users u ON s.user_id = u.id
    WHERE s.semester_id = ? AND s.division_id = ?
    ORDER BY CAST(s.roll_no AS UNSIGNED), s.roll_no
");
$stmt->bind_param("ii", $semester_id, $division_id);
$stmt->execute();
$students = [];
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
    $students[] = $row;
}
$stmt->close();

ob_end_clean();
header('Content-Type: application/json');
echo json_encode([
    'no_lecture'       => false,
    'students'         => $students,
    'already_submitted' => $already_submitted,
    'date'             => $date,
    'day'              => $day_name,
]);


?>