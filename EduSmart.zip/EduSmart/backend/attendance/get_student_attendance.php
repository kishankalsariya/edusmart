<?php
session_start();
include("../config/connection.php");

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$user_id = $_SESSION['user_id'];

// Get student info
$sq = $conn->prepare("SELECT student_id, semester_id, division_id FROM students WHERE user_id = ?");
$sq->bind_param("i", $user_id);
$sq->execute();
$student_result = $sq->get_result();

if (!$student_result) {
    echo json_encode(['error' => 'Database error: ' . $conn->error]);
    exit();
}

$student = $student_result->fetch_assoc();

if (!$student) {
    echo json_encode(['error' => 'Student profile not found']);
    exit();
}

$student_id  = $student['student_id'];
$semester_id = $student['semester_id'];
$division_id = $student['division_id'];

// -------------------- Overall Attendance --------------------
$overall = $conn->prepare("
    SELECT 
        COUNT(*) as total_classes,
        SUM(status = 'present') as present_count,
        SUM(status = 'absent') as absent_count
    FROM attendance
    WHERE student_id = ?
");
$overall->bind_param("i", $student_id);
$overall->execute();
$overall_result = $overall->get_result();

if (!$overall_result) {
    echo json_encode(['error' => 'Database error: ' . $conn->error]);
    exit();
}

$overall_data = $overall_result->fetch_assoc();

// -------------------- Subject-wise Attendance --------------------
$subwise = $conn->prepare("
    SELECT 
        s.subject_name,
        COUNT(*) as total_classes,
        SUM(a.status = 'present') as present_count,
        SUM(a.status = 'absent') as absent_count
    FROM attendance a
    JOIN subjects s ON a.subject_id = s.subject_id
    WHERE a.student_id = ?
    GROUP BY a.subject_id, s.subject_name
    ORDER BY s.subject_name
");
$subwise->bind_param("i", $student_id);
$subwise->execute();

// Fetch results safely
$subjects = [];
if ($subwise_result = $subwise->get_result()) {
    while ($row = $subwise_result->fetch_assoc()) {
        $row['percentage'] = $row['total_classes'] > 0 
            ? round(($row['present_count'] / $row['total_classes']) * 100, 1) 
            : 0;
        $subjects[] = $row;
    }
} else {
    // Fallback if get_result() not available
    $subwise->bind_result($subject_name, $total_classes, $present_count, $absent_count);
    while ($subwise->fetch()) {
        $subjects[] = [
            'subject_name' => $subject_name,
            'total_classes' => $total_classes,
            'present_count' => $present_count,
            'absent_count' => $absent_count,
            'percentage' => $total_classes > 0 ? round(($present_count / $total_classes) * 100, 1) : 0
        ];
    }
}

// -------------------- Recent Attendance Log --------------------
$recent = $conn->prepare("
    SELECT 
        s.subject_name,
        a.attendance_date,
        a.status,
        DAYNAME(a.attendance_date) as day_name
    FROM attendance a
    JOIN subjects s ON a.subject_id = s.subject_id
    WHERE a.student_id = ?
    ORDER BY a.attendance_date DESC, s.subject_name
    LIMIT 30
");
$recent->bind_param("i", $student_id);
$recent->execute();

$recent_log = [];
if ($recent_result = $recent->get_result()) {
    while ($row = $recent_result->fetch_assoc()) {
        $recent_log[] = $row;
    }
} else {
    // Fallback
    $recent->bind_result($subject_name, $attendance_date, $status, $day_name);
    while ($recent->fetch()) {
        $recent_log[] = [
            'subject_name' => $subject_name,
            'attendance_date' => $attendance_date,
            'status' => $status,
            'day_name' => $day_name
        ];
    }
}

// -------------------- Prepare JSON --------------------
$total   = (int)$overall_data['total_classes'];
$present = (int)$overall_data['present_count'];
$absent  = (int)$overall_data['absent_count'];

echo json_encode([
    'overall' => [
        'total'      => $total,
        'present'    => $present,
        'absent'     => $absent,
        'percentage' => $total > 0 ? round(($present / $total) * 100, 1) : 0
    ],
    'subjects'   => $subjects,
    'recent_log' => $recent_log
]);




         // claude

// session_start();
// include("../config/connection.php");

// if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
//     echo json_encode(['error' => 'Unauthorized']);
//     exit();
// }

// $user_id = $_SESSION['user_id'];

// // Get student info
// $sq = $conn->prepare("SELECT student_id, semester_id, division_id FROM students WHERE user_id = ?");
// $sq->bind_param("i", $user_id);
// $sq->execute();
// $student = $sq->get_result()->fetch_assoc();

// if (!$student) {
//     echo json_encode(['error' => 'Student profile not found']);
//     exit();
// }

// $student_id  = $student['student_id'];
// $semester_id = $student['semester_id'];
// $division_id = $student['division_id'];

// // Overall attendance
// $overall = $conn->prepare("
//     SELECT 
//         COUNT(*) as total_classes,
//         SUM(status = 'present') as present_count,
//         SUM(status = 'absent') as absent_count
//     FROM attendance
//     WHERE student_id = ?
// ");
// $overall->bind_param("i", $student_id);
// $overall->execute();
// $overall_data = $overall->get_result()->fetch_assoc();

// // Subject-wise attendance
// $subwise = $conn->prepare("
//     SELECT 
//         s.subject_name,
//         COUNT(*) as total_classes,
//         SUM(a.status = 'present') as present_count,
//         SUM(a.status = 'absent') as absent_count
//     FROM attendance a
//     JOIN subjects s ON a.subject_id = s.subject_id
//     WHERE a.student_id = ?
//     GROUP BY a.subject_id, s.subject_name
//     ORDER BY s.subject_name
// ");
// $subwise->bind_param("i", $student_id);
// $subwise->execute();
// $subjects = [];
// while ($row = $subwise->get_result()->fetch_assoc()) {
//     $row['percentage'] = $row['total_classes'] > 0
//         ? round(($row['present_count'] / $row['total_classes']) * 100, 1)
//         : 0;
//     $subjects[] = $row;
// }

// // Recent attendance log (last 30 records)
// $recent = $conn->prepare("
//     SELECT 
//         s.subject_name,
//         a.attendance_date,
//         a.status,
//         DAYNAME(a.attendance_date) as day_name
//     FROM attendance a
//     JOIN subjects s ON a.subject_id = s.subject_id
//     WHERE a.student_id = ?
//     ORDER BY a.attendance_date DESC, s.subject_name
//     LIMIT 30
// ");
// $recent->bind_param("i", $student_id);
// $recent->execute();
// $recent_log = [];
// while ($row = $recent->get_result()->fetch_assoc()) {
//     $recent_log[] = $row;
// }

// $total = (int)$overall_data['total_classes'];
// $present = (int)$overall_data['present_count'];

// header('Content-Type: application/json');
// echo json_encode([
//     'overall' => [
//         'total'      => $total,
//         'present'    => $present,
//         'absent'     => (int)$overall_data['absent_count'],
//         'percentage' => $total > 0 ? round(($present / $total) * 100, 1) : 0
//     ],
//     'subjects'   => $subjects,
//     'recent_log' => $recent_log
// ]);
?>
