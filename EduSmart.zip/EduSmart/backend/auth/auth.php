<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* Prevent cache */
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");

// Check login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("location:../frontend/login.php?error=login_required");
    exit();
}