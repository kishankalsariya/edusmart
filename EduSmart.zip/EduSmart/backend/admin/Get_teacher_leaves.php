<?php
ob_start();
session_start();
include("../config/connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$teacher_id = isset($_GET['teacher_id']) ? (int)$_GET['teacher_id'] : 0;
$month      = trim($_GET['month'] ?? ''); // format: YYYY-MM

if (!$teacher_id) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Teacher ID required']);
    exit();
}

// Build query with optional month filter
$sql = "
    SELECT
        tl.leave_id,
        tl.leave_date,
        tl.reason,
        tl.applied_at,
        s.subject_name,
        sem.semester_no,
        d.division_name
    FROM teacher_leaves tl
    LEFT JOIN subjects s   ON tl.subject_id  = s.subject_id
    LEFT JOIN semesters sem ON tl.semester_id = sem.semester_id
    LEFT JOIN divisions d  ON tl.division_id  = d.division_id
    WHERE tl.teacher_id = ?
";
$types  = "i";
$params = [$teacher_id];

if ($month && preg_match('/^\d{4}-\d{2}$/', $month)) {
    $sql   .= " AND DATE_FORMAT(tl.leave_date, '%Y-%m') = ?";
    $types .= "s";
    $params[] = $month;
}
$sql .= " ORDER BY tl.leave_date DESC";

$stmt = $conn->prepare($sql);
if (!$stmt) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Query error: ' . $conn->error]);
    exit();
}
$stmt->bind_param($types, ...$params);
$stmt->execute();
$leaves = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Summary counts
$cnt_all = $conn->prepare("SELECT COUNT(*) AS c FROM teacher_leaves WHERE teacher_id=?");
$cnt_all->bind_param("i", $teacher_id);
$cnt_all->execute();
$total_all_time = (int)$cnt_all->get_result()->fetch_assoc()['c'];
$cnt_all->close();

$cnt_month = $conn->prepare("SELECT COUNT(*) AS c FROM teacher_leaves WHERE teacher_id=? AND MONTH(leave_date)=MONTH(CURDATE()) AND YEAR(leave_date)=YEAR(CURDATE())");
$cnt_month->bind_param("i", $teacher_id);
$cnt_month->execute();
$total_this_month = (int)$cnt_month->get_result()->fetch_assoc()['c'];
$cnt_month->close();

$cnt_year = $conn->prepare("SELECT COUNT(*) AS c FROM teacher_leaves WHERE teacher_id=? AND YEAR(leave_date)=YEAR(CURDATE())");
$cnt_year->bind_param("i", $teacher_id);
$cnt_year->execute();
$total_this_year = (int)$cnt_year->get_result()->fetch_assoc()['c'];
$cnt_year->close();

ob_end_clean();
header('Content-Type: application/json');
echo json_encode([
    'leaves'           => $leaves,
    'total_all_time'   => $total_all_time,
    'total_this_month' => $total_this_month,
    'total_this_year'  => $total_this_year,
]);


?>