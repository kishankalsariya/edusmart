<?php
include("../config/connection.php");

if (isset($_POST['semester_id']) && isset($_POST['division_id'])) {
    $semester_id = (int)$_POST['semester_id'];
    $division_id = (int)$_POST['division_id'];
    
    $query = "SELECT s.* FROM subjects s
              WHERE s.semester_id = ?
              ORDER BY s.subject_name";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $semester_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    echo '<option value="">-- Select Subject --</option>';
    while ($row = $result->fetch_assoc()) {
        echo '<option value="' . $row['subject_id'] . '">' . htmlspecialchars($row['subject_name']) . '</option>';
    }
}
?>