<?php
include("../config/connection.php");

if (isset($_POST['semester_id']) && isset($_POST['division_id']) && 
    isset($_POST['subject_id']) && isset($_POST['academic_year'])) {
    
    $semester_id = (int)$_POST['semester_id'];
    $division_id = (int)$_POST['division_id'];
    $subject_id = (int)$_POST['subject_id'];
    $academic_year = $_POST['academic_year'];
    
    $query = "SELECT u.name, t.employee_code 
              FROM subject_teacher_assignment sta
              JOIN teachers t ON sta.teacher_id = t.teacher_id
              JOIN users u ON t.user_id = u.user_id
              WHERE sta.semester_id = ? 
                AND sta.division_id = ?
                AND sta.subject_id = ?
                AND sta.academic_year = ?
              LIMIT 1";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iiis", $semester_id, $division_id, $subject_id, $academic_year);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        echo htmlspecialchars($row['name']) . ' (' . htmlspecialchars($row['employee_code']) . ')';
    }
}
?>