<?php
include("../config/connection.php");
$pass = password_hash("admin123", PASSWORD_DEFAULT);
$role = 'admin';
$conn->query("INSERT INTO users (name,email,uid,password,role)
VALUES ('admin','admin@edusmart.com','admin001','$pass','$role')");
echo "DONE";
?>
