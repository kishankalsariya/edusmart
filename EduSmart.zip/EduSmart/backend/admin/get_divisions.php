<?php
include("../config/connection.php");

if (isset($_POST['semester_id'])) {
    $semester_id = (int)$_POST['semester_id'];
    
    $query = "SELECT d.* FROM divisions d
              ORDER BY d.division_name";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $semester_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    echo '<option value="">-- Select Division --</option>';
    while ($row = $result->fetch_assoc()) {
        echo '<option value="' . $row['division_id'] . '">Division ' . htmlspecialchars($row['division_name']) . '</option>';
    }
}
?>