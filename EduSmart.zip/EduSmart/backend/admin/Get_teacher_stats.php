<?php
ob_start();
session_start();
include("../config/connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$teacher_id = isset($_GET['teacher_id']) ? (int)$_GET['teacher_id'] : 0;
if (!$teacher_id) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Teacher ID required']);
    exit();
}

// Overall totals
$ov = $conn->prepare("
    SELECT
        COUNT(DISTINCT attendance_date) AS total_sessions,
        SUM(status='present')           AS total_present,
        SUM(status='absent')            AS total_absent
    FROM attendance WHERE teacher_id = ?
");
$ov->bind_param("i", $teacher_id);
$ov->execute();
$overall = $ov->get_result()->fetch_assoc();
$ov->close();

// Subject-wise
$sw = $conn->prepare("
    SELECT
        s.subject_name,
        sem.semester_no,
        d.division_name,
        COUNT(DISTINCT a.attendance_date) AS sessions
    FROM attendance a
    JOIN subjects s   ON a.subject_id  = s.subject_id
    JOIN semesters sem ON a.semester_id = sem.semester_id
    JOIN divisions d  ON a.division_id  = d.division_id
    WHERE a.teacher_id = ?
    GROUP BY a.subject_id, a.semester_id, a.division_id, s.subject_name, sem.semester_no, d.division_name
    ORDER BY sessions DESC
");
$sw->bind_param("i", $teacher_id);
$sw->execute();
$subjects = $sw->get_result()->fetch_all(MYSQLI_ASSOC);
$sw->close();

ob_end_clean();
header('Content-Type: application/json');
echo json_encode([
    'total_sessions' => (int)$overall['total_sessions'],
    'total_present'  => (int)$overall['total_present'],
    'total_absent'   => (int)$overall['total_absent'],
    'subjects'       => $subjects,
]);

?>