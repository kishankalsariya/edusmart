<?php
ob_start();
session_start();
include("../config/connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$user_id = $_SESSION['user_id'];
$data    = json_decode(file_get_contents('php://input'), true);
if (!$data) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit();
}

$first_name  = trim($data['first_name']  ?? '');
$last_name   = trim($data['last_name']   ?? '');
$phone       = trim($data['phone']       ?? '');
$dob         = trim($data['dob']         ?? '');
$gender      = trim($data['gender']      ?? '');
$address     = trim($data['address']     ?? '');
$email       = strtolower(trim($data['email'] ?? ''));
$roll_no     = trim($data['roll_no']     ?? '');
$semester_id = (int)($data['semester_id'] ?? 0);
$division_id = (int)($data['division_id'] ?? 0);

// ── Validation ────────────────────────────────────────────────────────────────
if (!$first_name || !$last_name) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'First name and last name are required.']);
    exit();
}
if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Please enter a valid email address.']);
    exit();
}
if (!$roll_no) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Roll number is required.']);
    exit();
}
if (!$semester_id || !$division_id) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Please select semester and division.']);
    exit();
}
if ($phone && !preg_match('/^[0-9]{10}$/', $phone)) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Phone must be a 10-digit number.']);
    exit();
}
if ($dob && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $dob)) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid date of birth.']);
    exit();
}
if (!in_array($gender, ['Male', 'Female', 'Other', ''])) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid gender value.']);
    exit();
}

// ── Check email not taken by another user ─────────────────────────────────────
$ec = $conn->prepare("SELECT id FROM users WHERE email=? AND id != ?");
$ec->bind_param("si", $email, $user_id);
$ec->execute();
$ec->store_result();
if ($ec->num_rows > 0) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'This email is already used by another account.']);
    exit();
}
$ec->close();

// ── Check roll_no not taken by another student ────────────────────────────────
$rc = $conn->prepare("SELECT student_id FROM students WHERE roll_no=? AND user_id != ?");
$rc->bind_param("si", $roll_no, $user_id);
$rc->execute();
$rc->store_result();
if ($rc->num_rows > 0) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'This roll number is already assigned to another student.']);
    exit();
}
$rc->close();

// ── Update users table ────────────────────────────────────────────────────────
$full_name = trim($first_name . ' ' . $last_name);
$uq = $conn->prepare("UPDATE users SET name=?, email=? WHERE id=?");
$uq->bind_param("ssi", $full_name, $email, $user_id);
$uq->execute();
$uq->close();

// ── Update students table ─────────────────────────────────────────────────────
$sq = $conn->prepare("
    UPDATE students
    SET first_name=?, last_name=?, phone=?, dob=?, gender=?,
        address=?, roll_no=?, semester_id=?, division_id=?
    WHERE user_id=?
");
$sq->bind_param(
    "ssssssssii",
    $first_name,
    $last_name,
    $phone,
    $dob,
    $gender,
    $address,
    $roll_no,
    $semester_id,
    $division_id,
    $user_id
);
$sq->execute();

if ($sq->error) {
    ob_end_clean();
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Update failed: ' . $sq->error]);
    exit();
}
$sq->close();

ob_end_clean();
header('Content-Type: application/json');
echo json_encode(['success' => true, 'message' => 'Profile updated successfully!', 'name' => $full_name]);
?>