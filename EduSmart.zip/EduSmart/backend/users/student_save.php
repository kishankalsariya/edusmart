<?php
session_start();
include("../config/connection.php");

$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare(
    "INSERT INTO students 
    (user_id,first_name,last_name, roll_no, gender, dob, phone, address, semester_id, division_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
);

$stmt->bind_param(
    "ississssii",
    $user_id,
    $_POST['first_name'],
    $_POST['last_name'],
    $_POST['roll_no'],
    $_POST['gender'],
    $_POST['dob'],
    $_POST['phone'],
    $_POST['address'],
    $_POST['semester_id'],
    $_POST['division_id']
);

$stmt->execute();

header("location: ../../frontend/student_profile.php?success=1");
exit();
?>
