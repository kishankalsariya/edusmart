<?php
ob_start();
session_start();
date_default_timezone_set('Asia/Kolkata');

include("../config/connection.php");

header('Content-Type: application/json');

$data  = json_decode(file_get_contents('php://input'), true);
$email = strtolower(trim($data['email'] ?? ''));
$otp   = trim($data['otp'] ?? '');

if (!$email || !$otp) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Email and OTP are required.']);
    exit();
}

if (!preg_match('/^\d{6}$/', $otp)) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'OTP must be a 6-digit number.']);
    exit();
}

// Current datetime for expiry check
$current_time = date('Y-m-d H:i:s');

// Prepare statement
$stmt = $conn->prepare("
    SELECT id FROM password_resets
    WHERE email = ? AND otp = ? AND used = 0 AND expires_at > ?
    ORDER BY created_at DESC LIMIT 1
");

if (!$stmt) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Database error (prepare failed).']);
    exit();
}

$stmt->bind_param("sss", $email, $otp, $current_time);

if (!$stmt->execute()) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Database error (execute failed).']);
    $stmt->close();
    exit();
}

$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

if (!$row) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Invalid or expired code. Please request a new one.']);
    exit();
}

// Store verified state in session so reset_password.php knows it's legit
$_SESSION['otp_verified_email'] = $email;
$_SESSION['otp_reset_id']       = $row['id'];

ob_end_clean();

echo json_encode(['success' => true, 'message' => 'Code verified. You can now set a new password.']);


?>