<?php
session_start();
include("../config/connection.php");

// Validate request
if (
    !isset($_POST['name']) ||
    !isset($_POST['email']) ||
    !isset($_POST['uid']) ||
    !isset($_POST['password']) ||
    !isset($_POST['role'])
) {
    die("Invalid Request");
}

$name  = trim($_POST['name']);
$email = trim($_POST['email']);
$uid   = trim($_POST['uid']);
$role  = $_POST['role'];

// Allow only valid roles
$allowed_roles = ['student', 'teacher'];
if (!in_array($role, $allowed_roles)) {
    die("Invalid Role");
}

// Hash password
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

// Check duplicate email or uid
$check = $conn->prepare("SELECT id FROM users WHERE email=? OR uid=?");
$check->bind_param("ss", $email, $uid);
$check->execute();
$check->store_result();

if ($check->num_rows > 0) {
    die("Email or UID already exists");
}

// Insert user
$stmt = $conn->prepare(
    "INSERT INTO users (name, email, uid, password, role) VALUES (?, ?, ?, ?, ?)"
);
$stmt->bind_param("sssss", $name, $email, $uid, $password, $role);

if ($stmt->execute()) {
    header("Location: ../../frontend/login.php");
} else {
    echo "Not Inserted!";
}
?>
