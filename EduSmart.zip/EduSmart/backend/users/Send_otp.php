<?php
ob_start();
session_start();
include("../config/connection.php");
date_default_timezone_set('Asia/Kolkata');


// ── PHPMailer (manual install — no Composer needed) ───────────────────────────
// Download from: https://github.com/PHPMailer/PHPMailer/releases
// Extract and place the src/ folder at: EduSmart/backend/libs/PHPMailer/src/
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once "../libs/PHPMailer/src/Exception.php";
require_once "../libs/PHPMailer/src/PHPMailer.php";
require_once "../libs/PHPMailer/src/SMTP.php";

header('Content-Type: application/json');

$data  = json_decode(file_get_contents('php://input'), true);
$email = strtolower(trim($data['email'] ?? ''));

if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Please enter a valid email address.']);
    exit();
}

// ── Check user exists ─────────────────────────────────────────────────────────
$chk = $conn->prepare("SELECT id, name FROM users WHERE email = ?");
$chk->bind_param("s", $email);
$chk->execute();
$user = $chk->get_result()->fetch_assoc();
$chk->close();

if (!$user) {
    ob_end_clean();
    // Generic response — don't reveal if email exists (security)
    echo json_encode(['success' => true, 'message' => 'If this email is registered, a code has been sent.']);
    exit();
}

// ── Rate Limit (3 per 15 min) ─────────────────────────────
$time_15_min_ago = date('Y-m-d H:i:s', strtotime('-15 minutes'));

$rate = $conn->prepare("
    SELECT COUNT(*) AS cnt FROM password_resets
    WHERE email = ? AND created_at >= ?
");
$rate->bind_param("ss", $email, $time_15_min_ago);
$rate->execute();

$rate_cnt = (int)$rate->get_result()->fetch_assoc()['cnt'];
$rate->close();

if ($rate_cnt >= 3) {
    ob_end_clean();
    echo json_encode([
        'success' => false,
        'message' => 'Too many requests. Please wait 15 minutes.'
    ]);
    exit();
}

// ── Generate OTP ──────────────────────────────────────────────────────────────
$otp        = (string)str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
$expires_at = date('Y-m-d H:i:s', strtotime('+10 minutes'));

// Delete old unused OTPs for this email
$del = $conn->prepare("DELETE FROM password_resets WHERE email = ? AND used = 0");
$del->bind_param("s", $email);
$del->execute();
$del->close();

// Save new OTP
$ins = $conn->prepare("
    INSERT INTO password_resets (email, otp, expires_at, used, created_at)
    VALUES (?, ?, ?, 0, NOW())
");

$ins->bind_param("sss", $email, $otp, $expires_at);

if (!$ins->execute()) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Failed to store OTP.']);
    exit();
}

$ins->close();

// ── Send email via Gmail SMTP ─────────────────────────────────────────────────
$name = htmlspecialchars($user['name']);

$mail = new PHPMailer(true);
try {
    // ── SMTP Settings ─────────────────────────────────────────────────────────
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'kalsariyakishan25@gmail.com';       // ← Your Gmail address
    $mail->Password   = 'nihodcadifvuunkn';     // ← Gmail App Password (16 chars)
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // ── Email Headers ─────────────────────────────────────────────────────────
    $mail->setFrom('kalsariyakishan25@gmail.com', 'EduSmart');
    $mail->addAddress($email, $name);
    $mail->isHTML(true);
    $mail->Subject = 'EduSmart - Your Password Reset Code';

    // ── HTML Email Body ───────────────────────────────────────────────────────
    $mail->Body = '
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width"/>
    </head>
    <body style="margin:0;padding:0;background:#f6f7f8;font-family:Lexend,Arial,sans-serif;">
      <table width="100%" cellpadding="0" cellspacing="0" style="background:#f6f7f8;padding:40px 16px;">
        <tr><td align="center">
          <table width="100%" style="max-width:500px;background:#ffffff;border-radius:16px;border:1px solid #e2e8f0;overflow:hidden;">

            <!-- Header -->
            <tr>
              <td style="background:linear-gradient(135deg,#2b8cee,#06b6d4);padding:32px;text-align:center;">
                <div style="width:56px;height:56px;background:rgba(255,255,255,0.2);border-radius:14px;display:inline-flex;align-items:center;justify-content:center;margin-bottom:12px;">
                  <span style="font-size:28px;">🎓</span>
                </div>
                <h1 style="margin:0;color:#ffffff;font-size:22px;font-weight:800;letter-spacing:-0.5px;">EduSmart</h1>
                <p style="margin:4px 0 0;color:rgba(255,255,255,0.8);font-size:13px;">Student Management System</p>
              </td>
            </tr>

            <!-- Body -->
            <tr>
              <td style="padding:32px;">
                <p style="margin:0 0 8px;color:#64748b;font-size:14px;">Hello,</p>
                <h2 style="margin:0 0 16px;color:#0f172a;font-size:20px;font-weight:700;">Password Reset Request</h2>
                <p style="margin:0 0 24px;color:#475569;font-size:14px;line-height:1.6;">
                  We received a request to reset the password for your EduSmart account associated with <strong>' . $email . '</strong>.
                  Use the verification code below to proceed.
                </p>

                <!-- OTP Box -->
                <div style="background:#f1f5f9;border:2px dashed #2b8cee;border-radius:12px;padding:24px;text-align:center;margin:0 0 24px;">
                  <p style="margin:0 0 8px;color:#64748b;font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:1px;">Your Verification Code</p>
                  <p style="margin:0;font-size:42px;font-weight:900;letter-spacing:12px;color:#2b8cee;font-family:monospace;">' . $otp . '</p>
                </div>

                <!-- Info boxes -->
                <table width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 24px;">
                  <tr>
                    <td style="background:#fef9c3;border-radius:8px;padding:12px 14px;">
                      <p style="margin:0;color:#854d0e;font-size:13px;">
                        ⏱ This code is valid for <strong>10 minutes</strong> only.
                      </p>
                    </td>
                  </tr>
                  <tr><td style="height:8px;"></td></tr>
                  <tr>
                    <td style="background:#fef2f2;border-radius:8px;padding:12px 14px;">
                      <p style="margin:0;color:#991b1b;font-size:13px;">
                        🔒 If you did not request this, please ignore this email. Your account is safe.
                      </p>
                    </td>
                  </tr>
                </table>

                <p style="margin:0;color:#94a3b8;font-size:12px;text-align:center;border-top:1px solid #e2e8f0;padding-top:20px;">
                  This is an automated message from EduSmart. Please do not reply.
                </p>
              </td>
            </tr>

            <!-- Footer -->
            <tr>
              <td style="background:#f8fafc;padding:16px 32px;text-align:center;border-top:1px solid #e2e8f0;">
                <p style="margin:0;color:#94a3b8;font-size:12px;">© ' . date('Y') . ' EduSmart · Veer Narmad South Gujarat University</p>
              </td>
            </tr>

          </table>
        </td></tr>
      </table>
    </body>
    </html>';

    // Plain text fallback
    $mail->AltBody = "Hello,\n\nYour EduSmart password reset code is: {$otp}\n\nThis code is valid for 10 minutes.\n\nIf you did not request this, please ignore this email.\n\nEduSmart Team";

    $mail->send();

    ob_end_clean();
    echo json_encode(['success' => true, 'message' => 'A 6-digit code has been sent to your email.']);

} catch (Exception $e) {
    error_log("MAIL ERROR: " . $mail->ErrorInfo);
    // OTP was saved — but email failed. Log error and inform user.
    ob_end_clean();
    echo json_encode([
        'success' => false,
        'message' => 'Failed to send email. Please check SMTP settings. Error: ' . $mail->ErrorInfo
    ]);
}

?>