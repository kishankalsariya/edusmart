<?php
ob_start();
session_start();
date_default_timezone_set('Asia/Kolkata');

include("../config/connection.php");

header('Content-Type: application/json');

$data     = json_decode(file_get_contents('php://input'), true);
$password = $data['password']  ?? '';
$confirm  = $data['confirm']   ?? '';

// Must have completed OTP verification
if (empty($_SESSION['otp_verified_email']) || empty($_SESSION['otp_reset_id'])) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Session expired. Please start over.']);
    exit();
}

$email    = $_SESSION['otp_verified_email'];
$reset_id = (int)$_SESSION['otp_reset_id'];

// Validate password
if (strlen($password) < 6) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters.']);
    exit();
}
if ($password !== $confirm) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Passwords do not match.']);
    exit();
}

// Double-check OTP record still valid and unused
$chk = $conn->prepare("SELECT id FROM password_resets WHERE id=? AND email=? AND used=0 AND expires_at > NOW()");
$chk->bind_param("is", $reset_id, $email);
$chk->execute();
if (!$chk->get_result()->fetch_assoc()) {
    ob_end_clean();
    echo json_encode(['success' => false, 'message' => 'Session expired. Please start over.']);
    exit();
}
$chk->close();

// Update password
$hashed = password_hash($password, PASSWORD_DEFAULT);
$upd    = $conn->prepare("UPDATE users SET password=? WHERE email=?");
$upd->bind_param("ss", $hashed, $email);
$upd->execute();
$upd->close();

// Mark OTP as used
$mark = $conn->prepare("UPDATE password_resets SET used=1 WHERE id=?");
$mark->bind_param("i", $reset_id);
$mark->execute();
$mark->close();

// Clear session
unset($_SESSION['otp_verified_email'], $_SESSION['otp_reset_id']);

ob_end_clean();
echo json_encode(['success' => true, 'message' => 'Password updated successfully!']);
