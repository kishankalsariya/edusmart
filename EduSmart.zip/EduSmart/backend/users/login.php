<?php
session_start();

include("../config/connection.php");


if ( empty($_POST['email']) || empty($_POST['password']) ) 
{
    header("Location: ../../frontend/login.php?error=empty_fields");
    exit();
}

$email = strtolower(trim($_POST['email']));
$password = $_POST['password'];


//    1. FETCH USER

$stmt = $conn->prepare(
    "SELECT id, name, password, role 
     FROM users 
     WHERE email = ?"
);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();


//    2. USER CHECK

if ($result->num_rows !== 1) {
    header("Location: ../../frontend/login.php?error=user_not_found");
    exit();
}

$user = $result->fetch_assoc();

//    3. PASSWORD VERIFY

if (!password_verify($password, $user['password'])) {
    header("Location: ../../frontend/login.php?error=wrong_password");
    exit();
}


//    4. SESSION SET

$_SESSION['user_id'] = $user['id'];
$_SESSION['role'] = $user['role'];



// echo "<pre>";
// echo "INPUT PASSWORD:\n";
// var_dump($password);

// echo "\nDB HASH:\n";
// var_dump($user['password']);

// echo "\nVERIFY RESULT:\n";
// var_dump(password_verify($password, $user['password']));



//    5. ROLE BASED REDIRECT

switch ($user['role']) {
    case 'admin':
        header("Location: ../../frontend/admin.php");
        break;

    case 'teacher':
        header("Location: ../../frontend/teacher_dashboard.php");
        break;

    case 'student':
        header("Location: ../../frontend/student_dashboard.php");
        break;

    default:
        session_destroy();
        header("Location: ../../frontend/login.php?error=invalid_role");
}



exit();
?>
