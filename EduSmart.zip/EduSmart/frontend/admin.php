<?php
include("../backend/config/connection.php");
include("../backend/auth/auth.php");

if ($_SESSION['role'] !== 'admin') {
  header("Location: login.php?error=unauthorized");
  exit();
}

$today        = date('Y-m-d');
$academic_year = date('Y') . '-' . (date('Y') + 1);

// Real stats
$total_teachers = (int)$conn->query("SELECT COUNT(*) AS c FROM teachers")->fetch_assoc()['c'];
$total_students = (int)$conn->query("SELECT COUNT(*) AS c FROM students")->fetch_assoc()['c'];

$att_today = $conn->query("SELECT COUNT(*) AS total, SUM(status='present') AS present FROM attendance WHERE attendance_date = '$today'")->fetch_assoc();
$att_pct   = $att_today['total'] > 0 ? round(($att_today['present'] / $att_today['total']) * 100, 1) : null;

$on_leave_today = (int)$conn->query("SELECT COUNT(DISTINCT teacher_id) AS c FROM teacher_leaves WHERE leave_date = '$today'")->fetch_assoc()['c'];

// Low attendance students (<75%)
$low_att_q = $conn->query("
    SELECT u.name, s.roll_no, sem.semester_no, d.division_name,
           ROUND(SUM(a.status='present') / COUNT(a.attendance_id) * 100, 1) AS pct
    FROM students s
    JOIN users u      ON s.user_id     = u.id
    JOIN semesters sem ON s.semester_id = sem.semester_id
    JOIN divisions d   ON s.division_id  = d.division_id
    JOIN attendance a  ON a.student_id  = s.student_id
    GROUP BY s.student_id, u.name, s.roll_no, sem.semester_no, d.division_name
    HAVING pct < 75
    ORDER BY pct ASC LIMIT 8
");
$low_att = $low_att_q ? $low_att_q->fetch_all(MYSQLI_ASSOC) : [];
$low_att_count = count($low_att);

// Recent leaves (last 5)
$recent_leaves_q = $conn->query("
    SELECT u.name, s.subject_name, tl.leave_date, tl.reason, sem.semester_no, d.division_name
    FROM teacher_leaves tl
    JOIN teachers t   ON tl.teacher_id  = t.teacher_id
    JOIN users u      ON t.user_id      = u.id
    JOIN subjects s   ON tl.subject_id  = s.subject_id
    JOIN semesters sem ON tl.semester_id = sem.semester_id
    JOIN divisions d  ON tl.division_id  = d.division_id
    ORDER BY tl.applied_at DESC LIMIT 5
");
$recent_leaves = $recent_leaves_q ? $recent_leaves_q->fetch_all(MYSQLI_ASSOC) : [];

$av_colors = ['bg-blue-100 text-blue-700', 'bg-purple-100 text-purple-700', 'bg-emerald-100 text-emerald-700', 'bg-amber-100 text-amber-700', 'bg-rose-100 text-rose-700'];
?>
<!DOCTYPE html>
<html class="light" lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>EduSmart — Admin Dashboard</title>
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
  <script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            primary: "#2b8cee",
            "primary-dark": "#1a6ec0",
            "background-light": "#f6f7f8",
            "background-dark": "#101922",
            "surface-light": "#ffffff",
            "surface-dark": "#1a2632"
          },
          fontFamily: {
            display: ["Lexend", "sans-serif"]
          },
          borderRadius: {
            DEFAULT: "0.25rem",
            lg: "0.5rem",
            xl: "0.75rem",
            "2xl": "1rem",
            full: "9999px"
          }
        }
      }
    };
  </script>
  <style>
    body {
      font-family: "Lexend", sans-serif
    }

    ::-webkit-scrollbar {
      width: 6px;
      height: 6px
    }

    ::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px
    }

    .dark ::-webkit-scrollbar-thumb {
      background: #334155
    }

    .material-symbols-outlined {
      font-variation-settings: "FILL" 0, "wght" 400, "GRAD" 0, "opsz" 24
    }

    .fill {
      font-variation-settings: "FILL" 1, "wght" 400, "GRAD" 0, "opsz" 24
    }
  </style>
</head>

<body class="bg-background-light dark:bg-background-dark text-slate-900 dark:text-white font-display h-screen overflow-hidden flex flex-col">

  <!-- TOP NAV -->
  <header class="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 bg-surface-light dark:bg-surface-dark px-6 py-3 shrink-0 h-16">
    <div class="flex items-center gap-3">
      <div class="size-9 rounded-xl bg-primary/10 flex items-center justify-center">
        <span class="material-symbols-outlined text-primary fill">school</span>
      </div>
      <h2 class="text-xl font-bold tracking-tight">EduSmart</h2>
    </div>
    <div class="flex items-center gap-3">
      <a href="../backend/users/logout.php" class="flex items-center gap-2 h-9 px-4 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors text-sm font-semibold">
        <span class="material-symbols-outlined text-[18px]">logout</span><span class="hidden md:inline">Logout</span>
      </a>
    </div>
  </header>

  <div class="flex flex-1 overflow-hidden">

    <!-- SIDEBAR -->
    <aside class="w-64 bg-surface-light dark:bg-surface-dark border-r border-slate-200 dark:border-slate-700 flex flex-col py-4 overflow-y-auto hidden md:flex shrink-0">
      <nav class="flex flex-col gap-1 px-3">
        <p class="px-3 text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 mt-2">Main Menu</p>
        <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-primary/10 text-primary font-semibold" href="#">
          <span class="material-symbols-outlined fill">dashboard</span><span class="text-sm">Dashboard</span>
        </a>
        <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-primary transition-colors" href="admin_manage_teacher.php">
          <span class="material-symbols-outlined">supervisor_account</span><span class="text-sm font-medium">Manage Teachers</span>
        </a>
        <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-primary transition-colors" href="admin_manage_student.php">
          <span class="material-symbols-outlined">groups</span><span class="text-sm font-medium">Manage Students</span>
        </a>
      </nav>
      <div class="mt-auto px-4 py-4">
        <div class="bg-primary/5 dark:bg-slate-800 rounded-xl p-4 border border-primary/10">
          <div class="flex items-center gap-2 mb-2">
            <span class="material-symbols-outlined text-primary text-[20px]">support_agent</span>
            <p class="font-bold text-sm">Need Help?</p>
          </div>
          <p class="text-xs text-slate-500 dark:text-slate-400 mb-3">Contact the engineering team for system support.</p>
          <button class="w-full py-2 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-xs font-bold text-slate-700 dark:text-slate-200">Contact Support</button>
        </div>
      </div>
    </aside>

    <!-- MAIN CONTENT -->
    <main class="flex-1 overflow-y-auto bg-background-light dark:bg-background-dark p-6 md:p-8">
      <div class="max-w-[1200px] mx-auto flex flex-col gap-6">

        <!-- Heading + Assignment Banner -->
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 class="text-3xl font-black tracking-tight">Dashboard Overview</h1>
            <p class="text-slate-500 dark:text-slate-400 mt-1">Welcome back — <?= date('l, F j, Y') ?></p>
          </div>
          <div class="flex items-center gap-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl px-4 py-3">
            <div class="size-9 rounded-lg bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center">
              <span class="material-symbols-outlined text-blue-600 dark:text-blue-400">assignment_ind</span>
            </div>
            <div class="flex-1 min-w-0">
              <p class="text-sm font-bold text-blue-800 dark:text-blue-300">Teacher Assignment</p>
              <p class="text-xs text-blue-600 dark:text-blue-400">Assign teachers to subjects for <?= $academic_year ?></p>
            </div>
            <a href="admin_assign_teacher.php" class="flex items-center gap-1 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-colors shrink-0">
              <span class="material-symbols-outlined text-[14px]">add</span>Assign Now
            </a>
          </div>
        </div>

        <!-- STAT CARDS -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">

          <a href="admin_manage_teacher.php" class="flex flex-col gap-2 rounded-2xl p-6 bg-surface-light dark:bg-surface-dark border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all hover:-translate-y-0.5 group">
            <div class="flex items-center gap-3 mb-1">
              <div class="size-10 rounded-xl bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center text-primary"><span class="material-symbols-outlined">supervisor_account</span></div>
              <p class="text-slate-500 text-xs font-bold uppercase tracking-wide">Total Teachers</p>
            </div>
            <p class="text-4xl font-black text-slate-900 dark:text-white"><?= $total_teachers ?></p>
            <?php if ($on_leave_today > 0) : ?>
              <p class="text-xs text-amber-600 dark:text-amber-400 font-medium flex items-center gap-1"><span class="material-symbols-outlined text-[13px]">event_busy</span><?= $on_leave_today ?> on leave today</p>
            <?php else : ?>
              <p class="text-xs text-emerald-500 font-medium flex items-center gap-1"><span class="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span>All active today</p>
            <?php endif; ?>
          </a>

          <a href="admin_manage_student.php" class="flex flex-col gap-2 rounded-2xl p-6 bg-surface-light dark:bg-surface-dark border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-all hover:-translate-y-0.5">
            <div class="flex items-center gap-3 mb-1">
              <div class="size-10 rounded-xl bg-indigo-50 dark:bg-indigo-900/20 flex items-center justify-center text-indigo-600"><span class="material-symbols-outlined">school</span></div>
              <p class="text-slate-500 text-xs font-bold uppercase tracking-wide">Total Students</p>
            </div>
            <p class="text-4xl font-black text-slate-900 dark:text-white"><?= $total_students ?></p>
            <p class="text-xs text-slate-400">Enrolled</p>
          </a>

          <div class="flex flex-col gap-2 rounded-2xl p-6 bg-surface-light dark:bg-surface-dark border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="flex items-center gap-3 mb-1">
              <div class="size-10 rounded-xl bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center text-emerald-600"><span class="material-symbols-outlined">fact_check</span></div>
              <p class="text-slate-500 text-xs font-bold uppercase tracking-wide">Today's Att.</p>
            </div>
            <p class="text-4xl font-black <?= $att_pct === null ? 'text-slate-400' : ($att_pct >= 75 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500') ?>">
              <?= $att_pct !== null ? $att_pct . '%' : '--' ?>
            </p>
            <p class="text-xs text-slate-400"><?= $att_today['total'] > 0 ? number_format($att_today['total']) . ' entries' : 'No data yet' ?></p>
          </div>

          <a href="admin_manage_student.php" class="flex flex-col gap-2 rounded-2xl p-6 <?= $low_att_count > 0 ? 'bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-800' : 'bg-surface-light dark:bg-surface-dark border-slate-200 dark:border-slate-700' ?> border shadow-sm hover:shadow-md transition-all hover:-translate-y-0.5">
            <div class="flex items-center gap-3 mb-1">
              <div class="size-10 rounded-xl bg-red-50 dark:bg-red-900/20 flex items-center justify-center text-red-600"><span class="material-symbols-outlined">notification_important</span></div>
              <p class="text-slate-500 text-xs font-bold uppercase tracking-wide">Low Att. Alerts</p>
            </div>
            <p class="text-4xl font-black <?= $low_att_count > 0 ? 'text-red-600 dark:text-red-400' : 'text-slate-400' ?>"><?= $low_att_count ?></p>
            <p class="text-xs <?= $low_att_count > 0 ? 'text-red-500' : 'text-slate-400' ?>">Students below 75%</p>
          </a>
        </div>

        <!-- BOTTOM GRID -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

          <!-- Low Attendance Students -->
          <div class="bg-surface-light dark:bg-surface-dark rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
            <div class="px-6 py-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <div>
                <h3 class="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <span class="material-symbols-outlined text-red-500 text-[18px]">notification_important</span>Low Attendance Alerts
                </h3>
                <p class="text-xs text-slate-500 mt-0.5">Students below 75% threshold</p>
              </div>
              <a href="admin_manage_student.php" class="text-xs font-semibold text-primary hover:underline">View All</a>
            </div>
            <?php if (empty($low_att)) : ?>
              <div class="text-center py-12">
                <span class="material-symbols-outlined text-5xl text-emerald-300 dark:text-emerald-800 block mb-3">verified</span>
                <p class="text-slate-400 text-sm font-medium">All students above 75% — Great!</p>
              </div>
            <?php else : ?>
              <div class="overflow-x-auto">
                <table class="w-full text-sm">
                  <thead class="bg-slate-50 dark:bg-slate-800/50 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
                    <tr>
                      <th class="px-5 py-3 text-left">Student</th>
                      <th class="px-5 py-3 text-left hidden sm:table-cell">Class</th>
                      <th class="px-5 py-3 text-center">Attendance</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                    <?php foreach ($low_att as $i => $s) :
                      $pct   = (float)$s['pct'];
                      $color = $av_colors[$i % count($av_colors)];
                      $init  = strtoupper(substr($s['name'], 0, 2));
                      $pBadge = $pct < 60
                        ? 'text-red-700 dark:text-red-400 bg-red-100 dark:bg-red-900/30 border border-red-200 dark:border-red-800'
                        : 'text-amber-700 dark:text-amber-400 bg-amber-100 dark:bg-amber-900/30 border border-amber-200 dark:border-amber-800';
                    ?>
                      <tr class="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors <?= $pct < 60 ? 'bg-red-50/40 dark:bg-red-900/5' : '' ?>">
                        <td class="px-5 py-3">
                          <div class="flex items-center gap-2.5">
                            <div class="size-8 rounded-full <?= $color ?> flex items-center justify-center font-bold text-xs shrink-0"><?= $init ?></div>
                            <div>
                              <p class="font-semibold text-slate-800 dark:text-white text-xs"><?= htmlspecialchars($s['name']) ?></p>
                              <p class="text-[10px] text-slate-400">Roll <?= htmlspecialchars($s['roll_no']) ?></p>
                            </div>
                          </div>
                        </td>
                        <td class="px-5 py-3 text-xs text-slate-500 hidden sm:table-cell">Sem <?= $s['semester_no'] ?> / Div <?= htmlspecialchars($s['division_name']) ?></td>
                        <td class="px-5 py-3 text-center">
                          <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-black <?= $pBadge ?>">
                            <span class="material-symbols-outlined text-[12px]">warning</span><?= $pct ?>%
                          </span>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>

          <!-- Recent Teacher Leaves -->
          <div class="bg-surface-light dark:bg-surface-dark rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
            <div class="px-6 py-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <div>
                <h3 class="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <span class="material-symbols-outlined text-amber-500 text-[18px]">event_busy</span>Recent Teacher Leaves
                </h3>
                <p class="text-xs text-slate-500 mt-0.5">Latest leave applications</p>
              </div>
              <a href="admin_manage_teacher.php" class="text-xs font-semibold text-primary hover:underline">View All</a>
            </div>
            <?php if (empty($recent_leaves)) : ?>
              <div class="text-center py-12">
                <span class="material-symbols-outlined text-5xl text-slate-300 dark:text-slate-600 block mb-3">event_available</span>
                <p class="text-slate-400 text-sm font-medium">No leaves recorded yet.</p>
              </div>
            <?php else : ?>
              <div class="flex flex-col divide-y divide-slate-100 dark:divide-slate-800">
                <?php foreach ($recent_leaves as $l) :
                  $d       = new DateTime($l['leave_date']);
                  $isToday = $l['leave_date'] === $today;
                ?>
                  <div class="flex items-start gap-3 px-5 py-3.5 <?= $isToday ? 'bg-amber-50/60 dark:bg-amber-900/10' : '' ?>">
                    <div class="size-10 rounded-xl <?= $isToday ? 'bg-amber-100 dark:bg-amber-900/30' : 'bg-slate-100 dark:bg-slate-800' ?> flex flex-col items-center justify-center text-center shrink-0">
                      <span class="text-[9px] font-semibold <?= $isToday ? 'text-amber-600' : 'text-slate-500' ?>"><?= $d->format('M') ?></span>
                      <span class="text-sm font-black <?= $isToday ? 'text-amber-700' : 'text-slate-700 dark:text-white' ?>"><?= $d->format('d') ?></span>
                    </div>
                    <div class="flex-1 min-w-0">
                      <div class="flex items-center justify-between gap-2">
                        <p class="text-sm font-semibold text-slate-800 dark:text-white truncate"><?= htmlspecialchars($l['name']) ?></p>
                        <?php if ($isToday) : ?>
                          <span class="text-[10px] font-bold text-amber-700 bg-amber-100 dark:bg-amber-900/30 dark:text-amber-400 px-2 py-0.5 rounded-full shrink-0">Today</span>
                        <?php endif; ?>
                      </div>
                      <p class="text-xs text-slate-500"><?= htmlspecialchars($l['subject_name']) ?> · Sem <?= $l['semester_no'] ?> Div <?= htmlspecialchars($l['division_name']) ?></p>
                      <?php if ($l['reason']) : ?>
                        <p class="text-[10px] text-slate-400 italic mt-0.5 truncate">"<?= htmlspecialchars($l['reason']) ?>"</p>
                      <?php endif; ?>
                    </div>
                  </div>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <footer class="text-center text-xs text-slate-400 py-2">&copy; <?= date('Y') ?> EduSmart Systems. All rights reserved.</footer>
      </div>
    </main>
  </div>
</body>

</html>