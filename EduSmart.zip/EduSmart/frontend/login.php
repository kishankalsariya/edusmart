<!DOCTYPE html>
<html class="light" lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>EduSmart Login</title>
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect" />
  <link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;display=swap" rel="stylesheet" />
  <!-- Material Symbols -->
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet" />
  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <!-- Tailwind Config -->
  <script id="tailwind-config">
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            primary: "#2b8cee",
            "primary-dark": "#1a6bb5",
            "background-light": "#f6f7f8",
            "background-dark": "#101922",
          },
          fontFamily: {
            display: ["Inter", "sans-serif"],
          },
          borderRadius: {
            DEFAULT: "0.25rem",
            lg: "0.5rem",
            xl: "0.75rem",
            full: "9999px",
          },
        },
      },
    };
  </script>
  <style>
    /* Custom scrollbar for cleaner look if needed */
    ::-webkit-scrollbar {
      width: 8px;
    }

    ::-webkit-scrollbar-track {
      background: transparent;
    }

    ::-webkit-scrollbar-thumb {
      background-color: #cbd5e1;
      border-radius: 20px;
    }

    /* Custom error message animation and styles */
    .error-message {
      animation: fadeInDown 0.2s ease-out;
      font-size: 0.75rem;
      margin-top: 0.25rem;
      display: flex;
      align-items: center;
      gap: 0.25rem;
    }

    @keyframes fadeInDown {
      from {
        opacity: 0;
        transform: translateY(-4px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes slideInRight {
      from {
        opacity: 0;
        transform: translateX(20px);
      }

      to {
        opacity: 1;
        transform: translateX(0);
      }
    }

    .input-error {
      border-color: #ef4444 !important;
      background-color: #fef2f2 !important;
      transition: all 0.2s ease;
    }

    .input-error:focus {
      border-color: #ef4444 !important;
    }

    /* Alert banner animation */
    .alert-banner {
      animation: slideInRight 0.3s ease-out;
    }

    /* Close button hover effect */
    .alert-close-btn:hover {
      background-color: rgba(0, 0, 0, 0.05);
      transform: scale(1.1);
    }
  </style>
</head>

<body class="font-display bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 antialiased min-h-screen flex flex-col">
  <div class="flex-grow flex items-center justify-center p-4 sm:p-6 lg:p-8">
    <!-- Main Card Container -->
    <div class="w-full max-w-md bg-white dark:bg-slate-800 rounded-2xl shadow-xl overflow-hidden border border-slate-200 dark:border-slate-700">
      <div class="p-8 sm:p-10">
        <!-- Header Section -->
        <div class="flex flex-col items-center mb-8">
          <div class="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4 text-primary">
            <span class="material-symbols-outlined text-3xl">school</span>
          </div>
          <h1 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            EduSmart
          </h1>
          <p class="text-sm text-slate-500 dark:text-slate-400 mt-2 text-center">
            Welcome back! Please login to your account.
          </p>
        </div>

        <!-- Dynamic Alert Banner Container for URL Errors -->
        <div id="alertContainer" class="mb-6"></div>

        <!-- Login Form - matches backend action -->
        <form action="../backend/users/login.php" method="post" class="space-y-5" id="loginForm" novalidate>
          <!-- Email Field -->
          <div class="space-y-2" id="emailField">
            <label class="text-sm font-medium text-slate-700 dark:text-slate-300" for="email">Email Address</label>
            <div class="relative">
              <input class="w-full h-12 px-4 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors" id="email" type="email" name="email" autocomplete="off" placeholder="your@email.com" />
              <div class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                <span class="material-symbols-outlined text-[20px]">mail</span>
              </div>
            </div>
            <div class="error-container min-h-[20px]"></div>
          </div>

          <!-- Password Field -->
          <div class="space-y-2" id="passwordField">
            <div class="flex items-center justify-between">
              <label class="text-sm font-medium text-slate-700 dark:text-slate-300" for="password">Password</label>
              <a class="text-xs font-medium text-primary hover:text-primary-dark hover:underline" href="Forget_password.php">Forgot Password?</a>
            </div>
            <div class="relative">
              <input class="w-full h-12 px-4 pr-10 rounded-lg bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors" id="password" name="password" autocomplete="current-password" type="password" placeholder="••••••••" />
              <button class="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 focus:outline-none" type="button" id="togglePassword">
                <span class="material-symbols-outlined text-[20px]" id="passwordIcon">visibility</span>
              </button>
            </div>
            <div class="error-container min-h-[20px]"></div>
          </div>

          <!-- Submit Button -->
          <button type="submit" class="w-full h-12 bg-primary hover:bg-primary-dark text-white font-semibold rounded-lg shadow-md shadow-primary/30 transition-all duration-200 flex items-center justify-center gap-2" id="submitBtn">
            <span>Sign In</span>
            <span class="material-symbols-outlined text-[20px]">login</span>
          </button>
        </form>

        <!-- Footer Links -->
        <div class="mt-6 text-center">
          <p class="text-sm text-slate-500 dark:text-slate-400">
            Don't have an account?
            <a class="font-medium text-primary hover:text-primary-dark hover:underline" href="register.php">Register</a>
          </p>
        </div>
      </div>
    </div>
  </div>

  <!-- Page Footer -->
  <footer class="py-6 text-center">
    <p class="text-xs text-slate-400 dark:text-slate-500">
      &copy; <?php echo date('Y'); ?> EduSmart Systems.
    </p>
  </footer>

  <script>
    // ============================================
    // COMPLETE CLIENT-SIDE VALIDATION
    // Matches backend error parameters exactly
    // Backend errors handled: user_not_found, wrong_password, empty_fields, invalid_role, database_error
    // ============================================

    (function() {
      // DOM elements
      const form = document.getElementById('loginForm');
      const emailInput = document.getElementById('email');
      const passwordInput = document.getElementById('password');
      const togglePasswordBtn = document.getElementById('togglePassword');
      const passwordIcon = document.getElementById('passwordIcon');
      const submitBtn = document.getElementById('submitBtn');
      const alertContainer = document.getElementById('alertContainer');

      // ============================================
      // URL Error Handler - Matches backend error codes
      // ============================================
      function getUrlErrorMessages() {
        const urlParams = new URLSearchParams(window.location.search);
        const error = urlParams.get('error');

        let errorMessage = null;
        let errorType = null;

        // Match backend error codes exactly
        switch (error) {
          case 'user_not_found':
            errorMessage = 'We couldn\'t find an account with these credentials. Please check your email or register for a new account.';
            errorType = 'user_not_found';
            break;

          case 'wrong_password':
            errorMessage = 'Incorrect password. Please try again or click "Forgot Password" to reset it.';
            errorType = 'wrong_password';
            break;

          case 'empty_fields':
            errorMessage = 'Both email and password are required. Please fill in all fields.';
            errorType = 'empty_fields';
            break;

          case 'email_required':
            errorMessage = 'Email address is required. Please enter your email.';
            errorType = 'email_required';
            break;

          case 'password_required':
            errorMessage = 'Password is required. Please enter your password.';
            errorType = 'password_required';
            break;

          case 'both_fields_required':
            errorMessage = 'Email and password are both required to login.';
            errorType = 'both_fields_required';
            break;

          case 'invalid_email_format':
            errorMessage = 'The email address format is invalid. Please use a valid email (e.g., name@domain.com).';
            errorType = 'invalid_email_format';
            break;

          case 'invalid_role':
            errorMessage = 'Your account role is invalid. Please contact system administrator.';
            errorType = 'invalid_role';
            break;

          default:
            if (error && error.length > 0) {
              // Generic error message for any other error parameter
              errorMessage = error.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()) + '. Please try again.';
              errorType = 'generic';
            }
            break;
        }

        return {
          errorMessage,
          errorType,
          errorParam: error
        };
      }

      // Function to create beautiful alert banner based on error type
      function createAlertBanner(errorMessage, errorType) {
        if (!errorMessage) return null;

        // Determine icon and color scheme based on error type
        let iconName = 'error_outline';
        let bgColor = 'bg-red-50 dark:bg-red-900/30';
        let borderColor = 'border-red-200 dark:border-red-800';
        let textColor = 'text-red-700 dark:text-red-300';
        let iconBgColor = 'bg-red-100 dark:bg-red-800/50';

        if (errorType === 'user_not_found') {
          iconName = 'person_off';
          bgColor = 'bg-amber-50 dark:bg-amber-900/30';
          borderColor = 'border-amber-200 dark:border-amber-800';
          textColor = 'text-amber-700 dark:text-amber-300';
          iconBgColor = 'bg-amber-100 dark:bg-amber-800/50';
        } else if (errorType === 'wrong_password') {
          iconName = 'lock_open';
          bgColor = 'bg-orange-50 dark:bg-orange-900/30';
          borderColor = 'border-orange-200 dark:border-orange-800';
          textColor = 'text-orange-700 dark:text-orange-300';
          iconBgColor = 'bg-orange-100 dark:bg-orange-800/50';
        } else if (errorType === 'invalid_role') {
          iconName = 'warning';
          bgColor = 'bg-red-50 dark:bg-red-900/30';
          borderColor = 'border-red-200 dark:border-red-800';
          textColor = 'text-red-700 dark:text-red-300';
          iconBgColor = 'bg-red-100 dark:bg-red-800/50';
        } 

        // Create banner element
        const banner = document.createElement('div');
        banner.className = `alert-banner ${bgColor} ${borderColor} border rounded-xl p-4 flex items-start gap-3 shadow-sm`;
        banner.setAttribute('role', 'alert');
        banner.setAttribute('aria-live', 'polite');

        banner.innerHTML = `
          <div class="flex-shrink-0">
            <div class="${iconBgColor} rounded-full p-1.5">
              <span class="material-symbols-outlined text-[20px] ${textColor}">${iconName}</span>
            </div>
          </div>
          <div class="flex-1">
            <p class="text-sm font-medium ${textColor} leading-relaxed">${escapeHtml(errorMessage)}</p>
            ${errorType === 'user_not_found' ? '<p class="text-xs mt-1 text-amber-600 dark:text-amber-400">New to EduSmart? <a href="register.php" class="font-semibold underline hover:no-underline">Create an account</a></p>' : ''}
            ${errorType === 'wrong_password' ? '<p class="text-xs mt-1 text-orange-600 dark:text-orange-400"><a href="Forget_password.php" class="font-semibold underline hover:no-underline">Reset your password</a></p>' : ''}
          </div>
          <button class="alert-close-btn flex-shrink-0 text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300 transition-all rounded-full p-1 focus:outline-none focus:ring-2 focus:ring-primary/50" aria-label="Close">
            <span class="material-symbols-outlined text-[18px]">close</span>
          </button>
        `;

        // Add close functionality
        const closeBtn = banner.querySelector('.alert-close-btn');
        if (closeBtn) {
          closeBtn.addEventListener('click', function() {
            banner.style.animation = 'fadeInDown 0.2s ease-out reverse';
            setTimeout(() => {
              if (banner && banner.remove) banner.remove();
              // Clean URL without reloading page (remove error parameters)
              const url = new URL(window.location.href);
              url.searchParams.delete('error');
              window.history.replaceState({}, document.title, url.pathname + url.search);
            }, 200);
          });
        }

        // Auto-dismiss after 8 seconds for better UX (except for critical errors)
        if (errorType !== 'account_locked' && errorType !== 'database_error' && errorType !== 'account_suspended') {
          setTimeout(() => {
            if (banner && banner.remove && document.body.contains(banner)) {
              banner.style.animation = 'fadeInDown 0.2s ease-out reverse';
              setTimeout(() => {
                if (banner && banner.remove) banner.remove();
              }, 200);
            }
          }, 8000);
        }

        return banner;
      }

      // Helper: Escape HTML to prevent XSS
      function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/[&<>]/g, function(m) {
          if (m === '&') return '&amp;';
          if (m === '<') return '&lt;';
          if (m === '>') return '&gt;';
          return m;
        });
      }

      // Display URL errors if present
      function displayUrlErrors() {
        const {
          errorMessage,
          errorType
        } = getUrlErrorMessages();

        if (errorMessage && alertContainer) {
          const alertBanner = createAlertBanner(errorMessage, errorType);
          if (alertBanner) {
            alertContainer.innerHTML = ''; // Clear any previous alerts
            alertContainer.appendChild(alertBanner);

            // Scroll to alert for visibility
            alertContainer.scrollIntoView({
              behavior: 'smooth',
              block: 'nearest'
            });

            // If error is related to email/password, highlight the respective field
            if (errorType === 'user_not_found' || errorType === 'invalid_email_format' || errorType === 'email_required' || errorType === 'email_too_long') {
              showFieldError('emailField', errorMessage);
            } else if (errorType === 'wrong_password' || errorType === 'password_required' || errorType === 'password_too_short' || errorType === 'password_too_long') {
              showFieldError('passwordField', errorMessage);
            } else if (errorType === 'empty_fields' || errorType === 'both_fields_required') {
              showFieldError('emailField', 'Email is required');
              showFieldError('passwordField', 'Password is required');
            }
          }
        }
      }

      // Helper: Clear all errors for a specific field
      function clearFieldErrors(fieldId) {
        const fieldContainer = document.getElementById(fieldId);
        if (fieldContainer) {
          const errorContainer = fieldContainer.querySelector('.error-container');
          if (errorContainer) {
            errorContainer.innerHTML = '';
          }
          const input = fieldContainer.querySelector('input');
          if (input) {
            input.classList.remove('input-error');
          }
        }
      }

      // Helper: Show error for a specific field
      function showFieldError(fieldId, errorMessage) {
        const fieldContainer = document.getElementById(fieldId);
        if (!fieldContainer) return;

        clearFieldErrors(fieldId);

        const input = fieldContainer.querySelector('input');
        if (input) {
          input.classList.add('input-error');
        }

        const errorContainer = fieldContainer.querySelector('.error-container');
        if (errorContainer) {
          const errorDiv = document.createElement('div');
          errorDiv.className = 'error-message text-red-500 dark:text-red-400';
          errorDiv.innerHTML = `
            <span class="material-symbols-outlined text-[14px]">error</span>
            <span>${escapeHtml(errorMessage)}</span>
          `;
          errorContainer.appendChild(errorDiv);
        }
      }

      // Helper: Show field valid (remove error)
      function showFieldValid(fieldId) {
        const fieldContainer = document.getElementById(fieldId);
        if (!fieldContainer) return;
        const input = fieldContainer.querySelector('input');
        if (input) {
          input.classList.remove('input-error');
        }
      }

      // Email validation function
      function validateEmail() {
        const email = emailInput.value.trim();
        clearFieldErrors('emailField');

        if (!email) {
          showFieldError('emailField', 'Email address is required');
          return false;
        }

        const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;

        if (!emailPattern.test(email)) {
          showFieldError('emailField', 'Please enter a valid email address (e.g., name@domain.com)');
          return false;
        }

        if (email.includes('..')) {
          showFieldError('emailField', 'Email address cannot contain consecutive dots');
          return false;
        }

        if (email.length > 254) {
          showFieldError('emailField', 'Email address is too long (max 254 characters)');
          return false;
        }

        showFieldValid('emailField');
        return true;
      }

      // Password validation function
      function validatePassword() {
        const password = passwordInput.value;
        clearFieldErrors('passwordField');

        if (!password) {
          showFieldError('passwordField', 'Password is required');
          return false;
        }

        if (password.length < 6) {
          showFieldError('passwordField', 'Password must be at least 6 characters long');
          return false;
        }

        if (password.length > 128) {
          showFieldError('passwordField', 'Password is too long (maximum 128 characters)');
          return false;
        }

        if (password.trim().length === 0) {
          showFieldError('passwordField', 'Password cannot be only spaces');
          return false;
        }

        showFieldValid('passwordField');
        return true;
      }

      // Full form validation
      function validateForm() {
        const isEmailValid = validateEmail();
        const isPasswordValid = validatePassword();

        if (!isEmailValid) {
          emailInput.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
          });
          emailInput.focus();
          return false;
        }

        if (!isPasswordValid) {
          passwordInput.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
          });
          passwordInput.focus();
          return false;
        }

        return true;
      }

      // Event listeners
      emailInput.addEventListener('blur', validateEmail);
      passwordInput.addEventListener('blur', validatePassword);

      emailInput.addEventListener('input', function() {
        const fieldContainer = document.getElementById('emailField');
        if (fieldContainer) {
          const errorContainer = fieldContainer.querySelector('.error-container');
          if (errorContainer && errorContainer.children.length > 0) {
            clearFieldErrors('emailField');
          }
          const input = fieldContainer.querySelector('input');
          if (input && input.classList.contains('input-error')) {
            input.classList.remove('input-error');
          }
        }
      });

      passwordInput.addEventListener('input', function() {
        const fieldContainer = document.getElementById('passwordField');
        if (fieldContainer) {
          const errorContainer = fieldContainer.querySelector('.error-container');
          if (errorContainer && errorContainer.children.length > 0) {
            clearFieldErrors('passwordField');
          }
          const input = fieldContainer.querySelector('input');
          if (input && input.classList.contains('input-error')) {
            input.classList.remove('input-error');
          }
        }
      });

      // Toggle password visibility
      if (togglePasswordBtn) {
        togglePasswordBtn.addEventListener('click', function() {
          const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
          passwordInput.setAttribute('type', type);
          if (passwordIcon) {
            passwordIcon.textContent = type === 'password' ? 'visibility' : 'visibility_off';
          }
        });
      }

      // Form submit handler
      form.addEventListener('submit', function(event) {
        const isValid = validateForm();
        if (!isValid) {
          event.preventDefault();
          submitBtn.style.transform = 'scale(0.98)';
          setTimeout(() => {
            submitBtn.style.transform = '';
          }, 150);
        } else {
          const originalText = submitBtn.innerHTML;
          submitBtn.innerHTML = '<span class="material-symbols-outlined animate-spin text-[20px]">progress_activity</span><span>Signing in...</span>';
          submitBtn.disabled = true;
          setTimeout(() => {
            if (submitBtn.disabled) {
              submitBtn.innerHTML = originalText;
              submitBtn.disabled = false;
            }
          }, 5000);
        }
      });

      // Initialize: Display URL errors on page load
      displayUrlErrors();

      // Also handle if fields have prefilled values
      window.addEventListener('DOMContentLoaded', function() {
        if (emailInput.value.trim() !== '') validateEmail();
        if (passwordInput.value !== '') validatePassword();
      });

    })();
  </script>
</body>

</html>