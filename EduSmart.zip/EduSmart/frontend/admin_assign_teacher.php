<?php
session_start();
include("../backend/config/connection.php");
include("../backend/auth/auth.php");

// Admin check
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php?error=unauthorized");
    exit();
}

$academic_year = date('Y') . '-' . (date('Y') + 1);
$message = '';
$message_type = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate inputs
    $errors = [];
    
    $semester_id = isset($_POST['semester_id']) ? (int)$_POST['semester_id'] : 0;
    $division_id = isset($_POST['division_id']) ? (int)$_POST['division_id'] : 0;
    $subject_id = isset($_POST['subject_id']) ? (int)$_POST['subject_id'] : 0;
    $teacher_id = isset($_POST['teacher_id']) ? (int)$_POST['teacher_id'] : 0;
    
    if ($semester_id <= 0) $errors[] = "Invalid semester";
    if ($division_id <= 0) $errors[] = "Invalid division";
    if ($subject_id <= 0) $errors[] = "Invalid subject";
    if ($teacher_id <= 0) $errors[] = "Invalid teacher";
    
    if (empty($errors)) {
        // Check if already assigned
        $check_query = "SELECT assignment_id FROM subject_teacher_assignment 
                        WHERE semester_id = ? AND division_id = ? 
                        AND subject_id = ? AND academic_year = ?";
        $check_stmt = $conn->prepare($check_query);
        
        if ($check_stmt) {
            $check_stmt->bind_param("iiis", $semester_id, $division_id, $subject_id, $academic_year);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows > 0) {
                // Update existing
                $update_query = "UPDATE subject_teacher_assignment 
                                 SET teacher_id = ?, assigned_date = CURDATE() 
                                 WHERE semester_id = ? AND division_id = ? 
                                 AND subject_id = ? AND academic_year = ?";
                $update_stmt = $conn->prepare($update_query);
                
                if ($update_stmt) {
                    $update_stmt->bind_param("iiiis", $teacher_id, $semester_id, $division_id, $subject_id, $academic_year);
                    
                    if ($update_stmt->execute()) {
                        $message = "Teacher updated successfully!";
                        $message_type = "success";
                    } else {
                        $message = "Update failed: " . $update_stmt->error;
                        $message_type = "error";
                    }
                    $update_stmt->close();
                } else {
                    $message = "Update prepare failed: " . $conn->error;
                    $message_type = "error";
                }
            } else {
                // Insert new
                $insert_query = "INSERT INTO subject_teacher_assignment 
                                 (semester_id, division_id, subject_id, teacher_id, academic_year) 
                                 VALUES (?, ?, ?, ?, ?)";
                $insert_stmt = $conn->prepare($insert_query);
                
                if ($insert_stmt) {
                    $insert_stmt->bind_param("iiiis", $semester_id, $division_id, $subject_id, $teacher_id, $academic_year);
                    
                    if ($insert_stmt->execute()) {
                        $message = "Teacher assigned successfully!";
                        $message_type = "success";
                    } else {
                        $message = "Insert failed: " . $insert_stmt->error;
                        $message_type = "error";
                    }
                    $insert_stmt->close();
                } else {
                    $message = "Insert prepare failed: " . $conn->error;
                    $message_type = "error";
                }
            }
            $check_stmt->close();
        } else {
            $message = "Check query failed: " . $conn->error;
            $message_type = "error";
        }
    } else {
        $message = implode("<br>", $errors);
        $message_type = "error";
    }
}

// Get all semesters
$semesters_result = $conn->query("SELECT * FROM semesters ORDER BY semester_no");
if (!$semesters_result) {
    die("Error fetching semesters: " . $conn->error);
}

// Get all teachers for dropdown
$teachers_result = $conn->query("
    SELECT t.teacher_id, u.name, t.status
    FROM teachers t
    JOIN users u ON t.user_id = u.id
    WHERE t.status = 'active'
    ORDER BY u.name
");
if (!$teachers_result) {
    die("Error fetching teachers: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assign Teachers to Subjects - EduSmart</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
    <style>
        .loading {
            opacity: 0.5;
            pointer-events: none;
        }
        .error-border {
            border-color: #ef4444 !important;
        }
        .success-message {
            animation: slideDown 0.3s ease;
        }
        @keyframes slideDown {
            from { transform: translateY(-10px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body class="bg-gray-100 p-6">
    <div class="max-w-4xl mx-auto">
        <!-- Header with back button -->
        <div class="flex items-center justify-between mb-6">
            <h1 class="text-2xl font-bold">Assign Teacher to Subject</h1>
            <a href="admin.php" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600">
                ← Back to Dashboard
            </a>
        </div>
        
        <!-- Main Card -->
        <div class="bg-white rounded-lg shadow p-6">
            
            <!-- Academic Year Info -->
            <div class="mb-6 p-3 bg-blue-50 text-blue-700 rounded flex items-center gap-2">
                <span class="material-symbols-outlined">calendar_month</span>
                <span class="font-medium">Academic Year: <?= htmlspecialchars($academic_year) ?></span>
            </div>
            
            <!-- Message Display -->
            <?php if ($message): ?>
                <div class="mb-4 p-3 rounded success-message <?= $message_type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700' ?>">
                    <?= $message ?>
                </div>
            <?php endif; ?>
            
            <!-- Step 1: Select Semester -->
            <div class="mb-4">
                <label class="block font-medium mb-2">
                    <span class="inline-flex items-center gap-1">
                        <span class="material-symbols-outlined text-sm">looks_one</span>
                        1. Select Semester:
                    </span>
                </label>
                <select id="semester_select" class="w-full p-2 border rounded focus:ring-2 focus:ring-blue-200" required>
                    <option value="">-- Choose Semester --</option>
                    <?php while ($sem = $semesters_result->fetch_assoc()): ?>
                        <option value="<?= $sem['semester_id'] ?>">
                            Semester <?= $sem['semester_no'] ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <!-- Step 2: Select Division (AJAX loaded) -->
            <div class="mb-4">
                <label class="block font-medium mb-2">
                    <span class="inline-flex items-center gap-1">
                        <span class="material-symbols-outlined text-sm">looks_two</span>
                        2. Select Division:
                    </span>
                </label>
                <select id="division_select" class="w-full p-2 border rounded focus:ring-2 focus:ring-blue-200" disabled required>
                    <option value="">-- First select semester --</option>
                </select>
                <div id="division_loading" class="hidden text-sm text-gray-500 mt-1">Loading divisions...</div>
            </div>
            
            <!-- Step 3: Select Subject (AJAX loaded) -->
            <div class="mb-4">
                <label class="block font-medium mb-2">
                    <span class="inline-flex items-center gap-1">
                        <span class="material-symbols-outlined text-sm">looks_3</span>
                        3. Select Subject:
                    </span>
                </label>
                <select id="subject_select" class="w-full p-2 border rounded focus:ring-2 focus:ring-blue-200" disabled required>
                    <option value="">-- First select division --</option>
                </select>
                <div id="subject_loading" class="hidden text-sm text-gray-500 mt-1">Loading subjects...</div>
            </div>
            
            <!-- Step 4: Select Teacher -->
            <div class="mb-4">
                <label class="block font-medium mb-2">
                    <span class="inline-flex items-center gap-1">
                        <span class="material-symbols-outlined text-sm">looks_4</span>
                        4. Select Teacher:
                    </span>
                </label>
                <select id="teacher_select" class="w-full p-2 border rounded focus:ring-2 focus:ring-blue-200" required>
                    <option value="">-- Choose Teacher --</option>
                    <?php 
                    $teachers_result->data_seek(0); // Reset pointer
                    while ($teacher = $teachers_result->fetch_assoc()): 
                    ?>
                        <option value="<?= $teacher['teacher_id'] ?>">
                            <?= htmlspecialchars($teacher['name']) ?> 
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <!-- Show Current Assignment -->
            <!-- <div id="current_teacher_info" class="mt-4 p-4 bg-gray-50 rounded hidden">
                <div class="flex items-center gap-2 mb-2">
                    <span class="material-symbols-outlined text-blue-600">info</span>
                    <p class="font-medium">Current Assignment:</p>
                </div>
                <p id="current_teacher_name" class="text-gray-700 pl-7"></p>
            </div> -->
            
            <!-- Validation Summary -->
            <div id="validation_summary" class="hidden mt-4 p-3 bg-red-100 text-red-700 rounded">
            </div>
            
            <!-- Submit Button -->
            <button onclick="assignTeacher()" 
                    class="mt-6 w-full bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2">
                <span class="material-symbols-outlined">assignment</span>
                Assign Teacher
            </button>
        </div>
    </div>
    
    <script>
    // Show loading states
    function showLoading(elementId) {
        $('#' + elementId).removeClass('hidden');
    }
    
    function hideLoading(elementId) {
        $('#' + elementId).addClass('hidden');
    }
    
    // Load divisions when semester selected
    $('#semester_select').change(function() {
        var semester_id = $(this).val();
        
        if (semester_id) {
            $('#division_select').prop('disabled', true).html('<option value="">Loading...</option>');
            showLoading('division_loading');
            
            $.ajax({
                url: '../backend/admin/get_divisions.php',
                method: 'POST',
                data: {semester_id: semester_id},
                dataType: 'html',
                success: function(data) {
                    $('#division_select').html(data).prop('disabled', false);
                    $('#subject_select').html('<option value="">-- Select division first --</option>').prop('disabled', true);
                    $('#current_teacher_info').addClass('hidden');
                    hideLoading('division_loading');
                },
                error: function(xhr, status, error) {
                    $('#division_select').html('<option value="">Error loading divisions</option>');
                    hideLoading('division_loading');
                    console.error(error);
                }
            });
        } else {
            $('#division_select').html('<option value="">-- First select semester --</option>').prop('disabled', true);
            $('#subject_select').html('<option value="">-- First select division --</option>').prop('disabled', true);
        }
    });
    
    // Load subjects when division selected
    $('#division_select').change(function() {
        var semester_id = $('#semester_select').val();
        var division_id = $(this).val();
        
        if (semester_id && division_id) {
            $('#subject_select').prop('disabled', true).html('<option value="">Loading...</option>');
            showLoading('subject_loading');
            
            $.ajax({
                url: '../backend/admin/get_subjects_for_division.php',
                method: 'POST',
                data: {semester_id: semester_id, division_id: division_id},
                dataType: 'html',
                success: function(data) {
                    $('#subject_select').html(data).prop('disabled', false);
                    hideLoading('subject_loading');
                },
                error: function(xhr, status, error) {
                    $('#subject_select').html('<option value="">Error loading subjects</option>');
                    hideLoading('subject_loading');
                    console.error(error);
                }
            });
        }
    });
    
    // Check current teacher when subject selected
    $('#subject_select').change(function() {
        var semester_id = $('#semester_select').val();
        var division_id = $('#division_select').val();
        var subject_id = $(this).val();
        var academic_year = '<?= $academic_year ?>';
        
        if (subject_id) {
            $.ajax({
                url: '../backend/admin/get_current_teacher.php',
                method: 'POST',
                data: {
                    semester_id: semester_id,
                    division_id: division_id,
                    subject_id: subject_id,
                    academic_year: academic_year
                },
                dataType: 'html',
                success: function(data) {
                    if (data && data.trim() !== '') {
                        $('#current_teacher_info').removeClass('hidden');
                        $('#current_teacher_name').html(data);
                    } else {
                        $('#current_teacher_info').addClass('hidden');
                    }
                },
                error: function() {
                    $('#current_teacher_info').addClass('hidden');
                }
            });
        }
    });
    
    // Validate form before submit
    function validateForm() {
        var errors = [];
        var semester = $('#semester_select').val();
        var division = $('#division_select').val();
        var subject = $('#subject_select').val();
        var teacher = $('#teacher_select').val();
        
        if (!semester) errors.push("Please select a semester");
        if (!division) errors.push("Please select a division");
        if (!subject) errors.push("Please select a subject");
        if (!teacher) errors.push("Please select a teacher");
        
        if (errors.length > 0) {
            $('#validation_summary').html(errors.join('<br>')).removeClass('hidden');
            return false;
        }
        
        $('#validation_summary').addClass('hidden');
        return true;
    }
    
    // Assign teacher
    function assignTeacher() {
        if (!validateForm()) {
            return;
        }
        
        var semester_id = $('#semester_select').val();
        var division_id = $('#division_select').val();
        var subject_id = $('#subject_select').val();
        var teacher_id = $('#teacher_select').val();
        
        // Confirm action
        if (!confirm('Are you sure you want to assign this teacher?')) {
            return;
        }
        
        // Submit form
        var form = $('<form method="POST" style="display:none"></form>');
        form.append('<input name="semester_id" value="' + semester_id + '">');
        form.append('<input name="division_id" value="' + division_id + '">');
        form.append('<input name="subject_id" value="' + subject_id + '">');
        form.append('<input name="teacher_id" value="' + teacher_id + '">');
        $('body').append(form);
        form.submit();
    }
    
    // Reset selections
    function resetForm() {
        $('#semester_select').val('').trigger('change');
        $('#teacher_select').val('');
        $('#current_teacher_info').addClass('hidden');
        $('#validation_summary').addClass('hidden');
    }
    </script>
</body>
</html>