<?php
include("../backend/config/connection.php");
include("../backend/auth/auth.php");

if ($_SESSION['role'] !== 'teacher') {
  header("Location: login.php?error=unauthorized");
  exit();
}

$user_id = $_SESSION['user_id'];
date_default_timezone_set('Asia/Kolkata');

$uq = $conn->prepare("SELECT name FROM users WHERE id = ?");
$uq->bind_param("i", $user_id);
$uq->execute();
$teacher_user = $uq->get_result()->fetch_assoc();

// Get teacher_id
$tq = $conn->prepare("SELECT teacher_id FROM teachers WHERE user_id = ?");
$tq->bind_param("i", $user_id);
$tq->execute();
$teacher_data = $tq->get_result()->fetch_assoc();
if (!$teacher_data) die("Teacher record not found");
$teacher_id   = $teacher_data['teacher_id'];
$academic_year = date('Y') . '-' . (date('Y') + 1);
$today_date    = date('Y-m-d');
$initials      = strtoupper(substr($teacher_user['name'], 0, 1));

// Today's lectures
$today_result = $conn->prepare("
    SELECT
        s.subject_id,
        s.subject_name,
        sta.semester_id,
        sta.division_id,
        sem.semester_no,
        d.division_name,
        TIME_FORMAT(t.start_time, '%h:%i %p') AS start_time,
        TIME_FORMAT(t.end_time,   '%h:%i %p') AS end_time,
        t.start_time AS raw_start,
        t.end_time   AS raw_end,
        COUNT(DISTINCT stu.student_id) AS total_students
    FROM subject_teacher_assignment sta
    JOIN subjects s   ON sta.subject_id  = s.subject_id
    JOIN semesters sem ON sta.semester_id = sem.semester_id
    JOIN divisions d  ON sta.division_id  = d.division_id
    JOIN division_subject_teacher dst
        ON  dst.semester_id = sta.semester_id
        AND dst.division_id = sta.division_id
        AND dst.subject_id  = sta.subject_id
    JOIN timetable t ON dst.dst_id = t.dst_id
    LEFT JOIN students stu
        ON  stu.semester_id = sta.semester_id
        AND stu.division_id = sta.division_id
    WHERE sta.teacher_id   = ?
      AND sta.academic_year = ?
      AND sta.status        = 'active'
      AND t.day             = DAYNAME(CURDATE())
    GROUP BY t.timetable_id
    ORDER BY t.start_time
");

$today_result->bind_param("is", $teacher_id, $academic_year);
$today_result->execute();
$lectures     = $today_result->get_result()->fetch_all(MYSQLI_ASSOC);
$lecture_count = count($lectures);

// Fetch today's leaves for this teacher in one query
$leave_map = [];
if ($lecture_count > 0) {
  $lv = $conn->prepare("
        SELECT subject_id, semester_id, division_id, reason
        FROM teacher_leaves
        WHERE teacher_id = ? AND leave_date = ?
    ");
  $lv->bind_param("is", $teacher_id, $today_date);
  $lv->execute();
  $lv_res = $lv->get_result();
  while ($row = $lv_res->fetch_assoc()) {
    $key = $row['subject_id'] . '_' . $row['semester_id'] . '_' . $row['division_id'];
    $leave_map[$key] = $row['reason'];
  }
  $lv->close();
}

// Fetch attendance submitted map
$att_map = [];
if ($lecture_count > 0) {
  $av = $conn->prepare("
        SELECT subject_id, semester_id, division_id
        FROM attendance
        WHERE teacher_id = ? AND attendance_date = ?
        GROUP BY subject_id, semester_id, division_id
    ");
  $av->bind_param("is", $teacher_id, $today_date);
  $av->execute();
  $av_res = $av->get_result();
  while ($row = $av_res->fetch_assoc()) {
    $key = $row['subject_id'] . '_' . $row['semester_id'] . '_' . $row['division_id'];
    $att_map[$key] = true;
  }
  $av->close();
}

// Stats
$total_students_all = array_sum(array_column($lectures, 'total_students'));
$total_leaves_today = count($leave_map);
?>
<!DOCTYPE html>
<html class="light" lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>EduSmart — Teacher Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            primary: "#2b8cee",
            "primary-dark": "#1a6ec0",
            "background-light": "#f6f7f8",
            "background-dark": "#101922"
          },
          fontFamily: {
            display: ["Lexend", "sans-serif"]
          },
          borderRadius: {
            DEFAULT: "0.25rem",
            lg: "0.5rem",
            xl: "0.75rem",
            "2xl": "1rem",
            full: "9999px"
          },
        }
      },
    };
  </script>
  <style>
    body {
      font-family: "Lexend", sans-serif;
    }

    ::-webkit-scrollbar {
      width: 6px;
      height: 6px
    }

    ::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 3px
    }

    .dark ::-webkit-scrollbar-thumb {
      background: #334155
    }

    .material-symbols-outlined {
      font-variation-settings: "FILL" 0, "wght" 400, "GRAD" 0, "opsz" 24
    }

    .fill {
      font-variation-settings: "FILL" 1, "wght" 400, "GRAD" 0, "opsz" 24
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(6px)
      }

      to {
        opacity: 1;
        transform: translateY(0)
      }
    }

    .fade-in {
      animation: fadeIn .25s ease forwards
    }
  </style>
</head>

<body class="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-white antialiased overflow-hidden">
  <div class="flex h-screen w-full overflow-hidden">

    <!-- ═══════════ SIDEBAR ═══════════ -->
    <aside class="hidden md:flex flex-col w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 h-full flex-shrink-0">
      <div class="flex flex-col h-full p-4">
        <div class="flex items-center gap-3 px-2 py-4 mb-6">
          <div class="size-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
            <span class="material-symbols-outlined fill">school</span>
          </div>
          <div>
            <h1 class="text-lg font-bold leading-tight">EduSmart</h1>
            <p class="text-slate-500 text-xs">Teacher Portal</p>
          </div>
        </div>
        <nav class="flex flex-col gap-1 flex-1">
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-primary/10 text-primary font-semibold" href="#">
            <span class="material-symbols-outlined fill">dashboard</span><span class="text-sm">Dashboard</span>
          </a>
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors" href="teacher_take_attendance.php">
            <span class="material-symbols-outlined">edit_square</span><span class="text-sm font-medium">Take Attendance</span>
          </a>
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors" href="teacher_attendance_records.php">
            <span class="material-symbols-outlined">receipt_long</span><span class="text-sm font-medium">Attendance Records</span>
          </a>
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors" href="student_doubts.php">
            <span class="material-symbols-outlined">chat_bubble</span><span class="text-sm font-medium">Student Doubts</span>
          </a>
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors" href="teacher_reports.php">
            <span class="material-symbols-outlined">bar_chart</span><span class="text-sm font-medium">Reports</span>
          </a>
        </nav>
        <div class="mt-auto pt-4 border-t border-slate-100 dark:border-slate-800">
          <div class="flex items-center gap-3 px-3 py-3 mb-2">
            <div class="size-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm"><?= $initials ?></div>
            <div class="overflow-hidden">
              <p class="text-sm font-semibold truncate"><?= htmlspecialchars($teacher_user['name']) ?></p>
              <p class="text-xs text-slate-500">Teacher</p>
            </div>
          </div>
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors" href="../backend/users/logout.php">
            <span class="material-symbols-outlined">logout</span><span class="text-sm font-medium">Logout</span>
          </a>
        </div>
      </div>
    </aside>

    <!-- ═══════════ MAIN ═══════════ -->
    <div class="flex-1 flex flex-col h-full overflow-hidden bg-background-light dark:bg-background-dark">

      <!-- Top bar -->
      <header class="flex items-center justify-between px-6 py-4 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 z-10 shrink-0">
        <div class="flex items-center gap-4">
          <button class="md:hidden p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg">
            <span class="material-symbols-outlined">menu</span>
          </button>
          <div>
            <h2 class="text-xl font-bold tracking-tight">Dashboard Overview</h2>
            <p class="text-xs text-slate-500 hidden sm:block"><?= date('l, F j, Y') ?></p>
          </div>
        </div>
        <div class="flex items-center gap-3">
          <!-- <button onclick="document.documentElement.classList.toggle('dark')" class="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <span class="material-symbols-outlined text-[20px]">dark_mode</span>
          </button> -->
          <div class="size-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm hidden md:flex"><?= $initials ?></div>
          <span class="hidden md:block text-sm font-medium"><?= htmlspecialchars($teacher_user['name']) ?></span>
        </div>
      </header>

      <!-- Scrollable content -->
      <main class="flex-1 overflow-y-auto p-4 md:p-8">
        <div class="max-w-6xl mx-auto space-y-6">

          <!-- ── Quick Stat Cards ── -->
          <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">

            <div class="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 shadow-sm relative overflow-hidden">
              <div class="absolute right-2 top-2 opacity-[0.07] pointer-events-none"><span class="material-symbols-outlined text-7xl text-indigo-500">calendar_today</span></div>
              <p class="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">Today's Lectures</p>
              <h3 class="text-4xl font-black text-slate-900 dark:text-white"><?= $lecture_count ?></h3>
              <p class="text-xs text-slate-400 mt-2"><?= date('l') ?></p>
            </div>

            <div class="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 shadow-sm relative overflow-hidden">
              <div class="absolute right-2 top-2 opacity-[0.07] pointer-events-none"><span class="material-symbols-outlined text-7xl text-blue-500">groups</span></div>
              <p class="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">Total Students</p>
              <h3 class="text-4xl font-black text-slate-900 dark:text-white"><?= $total_students_all ?: '--' ?></h3>
              <p class="text-xs text-slate-400 mt-2">Across today's classes</p>
            </div>

            <div class="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 shadow-sm relative overflow-hidden">
              <div class="absolute right-2 top-2 opacity-[0.07] pointer-events-none"><span class="material-symbols-outlined text-7xl text-emerald-500">how_to_reg</span></div>
              <p class="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">Attendance Done</p>
              <h3 class="text-4xl font-black text-emerald-600 dark:text-emerald-400"><?= count($att_map) ?></h3>
              <p class="text-xs text-slate-400 mt-2">of <?= $lecture_count ?> lectures</p>
            </div>

            <div class="<?= $total_leaves_today > 0 ? 'bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800' : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700' ?> rounded-2xl p-5 border shadow-sm relative overflow-hidden">
              <div class="absolute right-2 top-2 opacity-[0.1] pointer-events-none"><span class="material-symbols-outlined text-7xl text-amber-500">event_busy</span></div>
              <p class="text-xs font-semibold uppercase tracking-wider <?= $total_leaves_today > 0 ? 'text-amber-600' : 'text-slate-500' ?> mb-2">Leaves Today</p>
              <h3 class="text-4xl font-black <?= $total_leaves_today > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-900 dark:text-white' ?>"><?= $total_leaves_today ?></h3>
              <p class="text-xs <?= $total_leaves_today > 0 ? 'text-amber-500' : 'text-slate-400' ?> mt-2">Applied for today</p>
            </div>
          </div>

          <!-- ── Today's Lectures Table ── -->
          <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
            <div class="flex items-center justify-between px-6 py-5 border-b border-slate-100 dark:border-slate-800">
              <h3 class="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <span class="material-symbols-outlined text-primary">today</span>
                Today's Lectures
                <span class="text-sm font-normal text-slate-400">(<?= date('l, F j') ?>)</span>
              </h3>
              <a href="teacher_take_attendance.php" class="text-sm font-semibold text-primary hover:text-primary-dark flex items-center gap-1 transition-colors">
                Take Attendance <span class="material-symbols-outlined text-[16px]">arrow_forward</span>
              </a>
            </div>

            <?php if ($lecture_count > 0) : ?>
              <div class="overflow-x-auto">
                <table class="w-full text-sm">
                  <thead>
                    <tr class="bg-slate-50 dark:bg-slate-800 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
                      <th class="px-6 py-3 text-left">Subject</th>
                      <th class="px-6 py-3 text-left hidden sm:table-cell">Sem / Div</th>
                      <th class="px-6 py-3 text-left">Time</th>
                      <th class="px-6 py-3 text-center hidden md:table-cell">Students</th>
                      <th class="px-6 py-3 text-center">Status</th>
                      <th class="px-6 py-3 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                    <?php foreach ($lectures as $row) :
                      $key        = $row['subject_id'] . '_' . $row['semester_id'] . '_' . $row['division_id'];
                      $on_leave   = isset($leave_map[$key]);
                      $att_done   = isset($att_map[$key]);
                      $now        = date('H:i:s');
                      $raw_start  = date('H:i:s', strtotime($row['raw_start']));
                      $raw_end    = date('H:i:s', strtotime($row['raw_end']));

                      if ($on_leave) {
                        $status_label = 'On Leave';
                        $status_class = 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400';
                      } elseif ($now >= $raw_start && $now <= $raw_end) {
                        $status_label = 'Ongoing';
                        $status_class = 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400';
                      } elseif ($now < $raw_start) {
                        $diff = (int)floor((strtotime($row['raw_start']) - time()) / 60);
                        $status_label = $diff < 60 ? 'In ' . $diff . ' min' : 'Upcoming';
                        $status_class = 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400';
                      } else {
                        $status_label = $att_done ? 'Completed ✓' : 'Completed';
                        $status_class = $att_done
                          ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400'
                          : 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400';
                      }

                      $row_class = $on_leave ? 'bg-amber-50/50 dark:bg-amber-900/5' : 'hover:bg-slate-50 dark:hover:bg-slate-800/50';
                    ?>
                      <tr class="transition-colors <?= $row_class ?>" id="row-<?= $key ?>">
                        <td class="px-6 py-4">
                          <div class="font-semibold text-slate-900 dark:text-white"><?= htmlspecialchars($row['subject_name']) ?></div>
                          <?php if ($on_leave) : ?>
                            <div class="text-xs text-amber-600 dark:text-amber-400 mt-0.5 flex items-center gap-1">
                              <span class="material-symbols-outlined text-[13px]">info</span>
                              <?= $leave_map[$key] ? htmlspecialchars($leave_map[$key]) : 'Leave applied' ?>
                            </div>
                          <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-slate-500 dark:text-slate-400 hidden sm:table-cell">
                          Sem <?= $row['semester_no'] ?> / Div <?= htmlspecialchars($row['division_name']) ?>
                        </td>
                        <td class="px-6 py-4 text-slate-500 dark:text-slate-400 text-xs">
                          <?= $row['start_time'] ?> – <?= $row['end_time'] ?>
                        </td>
                        <td class="px-6 py-4 text-center text-slate-500 dark:text-slate-400 hidden md:table-cell">
                          <span class="font-semibold text-slate-700 dark:text-slate-200"><?= $row['total_students'] ?></span> students
                        </td>
                        <td class="px-6 py-4 text-center">
                          <span class="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-lg <?= $status_class ?>">
                            <?php if ($status_label === 'Ongoing') : ?>
                              <span class="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse"></span>
                            <?php elseif ($on_leave) : ?>
                              <span class="material-symbols-outlined text-[13px]">event_busy</span>
                            <?php endif; ?>
                            <?= $status_label ?>
                          </span>
                        </td>
                        <td class="px-6 py-4 text-right">
                          <div class="flex items-center justify-end gap-2">
                            <?php if ($on_leave) : ?>
                              <!-- Cancel Leave button -->
                              <button onclick="cancelLeave('<?= $key ?>', <?= $row['subject_id'] ?>, <?= $row['semester_id'] ?>, <?= $row['division_id'] ?>)" class="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs font-semibold hover:bg-slate-200 dark:hover:bg-slate-600 transition-colors">
                                <span class="material-symbols-outlined text-[14px]">close</span>Cancel Leave
                              </button>
                            <?php elseif ($att_done) : ?>
                              <!-- Attendance already done -->
                              <a href="teacher_attendance_records.php" class="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 text-xs font-semibold hover:bg-emerald-100 transition-colors">
                                <span class="material-symbols-outlined text-[14px]">visibility</span>View Records
                              </a>
                            <?php else : ?>
                              <!-- Take Attendance button -->
                              <a href="teacher_take_attendance.php" class="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-primary/10 text-primary text-xs font-semibold hover:bg-primary/20 transition-colors">
                                <span class="material-symbols-outlined text-[14px]">how_to_reg</span>Attendance
                              </a>
                              <!-- Apply Leave button -->
                              <button onclick="openLeaveModal('<?= $key ?>', <?= $row['subject_id'] ?>, <?= $row['semester_id'] ?>, <?= $row['division_id'] ?>, '<?= addslashes($row['subject_name']) ?>', 'Sem <?= $row['semester_no'] ?> Div <?= addslashes($row['division_name']) ?>')" class="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-800 text-xs font-semibold hover:bg-amber-100 dark:hover:bg-amber-900/40 transition-colors">
                                <span class="material-symbols-outlined text-[14px]">event_busy</span>Apply Leave
                              </button>
                            <?php endif; ?>
                          </div>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>

              <!-- Legend -->
              <div class="px-6 py-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
                <p class="text-sm text-slate-500"><?= $lecture_count ?> lecture<?= $lecture_count > 1 ? 's' : '' ?> scheduled today</p>
                <div class="flex flex-wrap gap-4 text-xs text-slate-500">
                  <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-blue-500"></span>Ongoing</span>
                  <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-slate-400"></span>Upcoming / Completed</span>
                  <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-emerald-500"></span>Attendance Done</span>
                  <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-amber-500"></span>On Leave</span>
                </div>
              </div>

            <?php else : ?>
              <div class="text-center py-16">
                <div class="w-16 h-16 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span class="material-symbols-outlined text-3xl text-slate-400">celebration</span>
                </div>
                <h4 class="text-base font-bold text-slate-700 dark:text-white mb-1">No Lectures Today!</h4>
                <p class="text-slate-400 text-sm max-w-sm mx-auto">You have no lectures scheduled for today. Enjoy your free day!</p>
              </div>
            <?php endif; ?>
          </div>

          <!-- Footer -->
          <div class="border-t border-slate-200 dark:border-slate-800 pt-4 pb-2 flex flex-col md:flex-row justify-between items-center gap-3 text-xs text-slate-400">
            <p>&copy; <?= date('Y') ?> EduSmart Systems. All rights reserved.</p>
            <div class="flex gap-5">
              <a class="hover:text-primary transition-colors" href="#">Help Center</a>
              <a class="hover:text-primary transition-colors" href="#">Privacy Policy</a>
            </div>
          </div>

        </div><!-- /max-w -->
      </main>
    </div><!-- /main wrapper -->
  </div><!-- /flex -->

  <!-- ═══════════ LEAVE MODAL ═══════════ -->
  <div id="leave-modal" class="hidden fixed inset-0 bg-black/50 dark:bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl w-full max-w-md fade-in">

      <!-- Modal Header -->
      <div class="flex items-center justify-between px-6 py-5 border-b border-slate-100 dark:border-slate-800">
        <div class="flex items-center gap-3">
          <div class="size-10 rounded-xl bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
            <span class="material-symbols-outlined text-amber-600 dark:text-amber-400">event_busy</span>
          </div>
          <div>
            <h3 class="font-bold text-slate-900 dark:text-white">Apply for Leave</h3>
            <p class="text-xs text-slate-500" id="modal-class-label"></p>
          </div>
        </div>
        <button onclick="closeLeaveModal()" class="p-2 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-600 transition-colors">
          <span class="material-symbols-outlined text-[20px]">close</span>
        </button>
      </div>

      <!-- Modal Body -->
      <div class="px-6 py-5 flex flex-col gap-4">

        <!-- Date (read-only today) -->
        <div class="flex flex-col gap-1.5">
          <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Leave Date</label>
          <div class="flex items-center gap-2 h-11 px-4 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-sm">
            <span class="material-symbols-outlined text-[16px] text-slate-400">calendar_today</span>
            <?= date('l, F j, Y') ?> (Today)
          </div>
        </div>

        <!-- Reason -->
        <div class="flex flex-col gap-1.5">
          <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Reason <span class="text-slate-400 font-normal normal-case">(optional)</span></label>
          <textarea id="leave-reason" rows="3" placeholder="e.g. Personal emergency, Health issue, Conference..." class="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-4 py-3 text-sm focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 outline-none resize-none transition-all placeholder:text-slate-400"></textarea>
        </div>

        <!-- Warning -->
        <div class="flex items-start gap-2 p-3 rounded-xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400 text-sm">
          <span class="material-symbols-outlined text-[16px] mt-0.5 shrink-0">warning</span>
          <p>Students will see this class as <strong>cancelled</strong> and attendance <strong>cannot be taken</strong> on this date for this class.</p>
        </div>
      </div>

      <!-- Modal Footer -->
      <div class="px-6 py-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-3">
        <button onclick="closeLeaveModal()" class="px-5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
          Cancel
        </button>
        <button onclick="submitLeave()" id="submit-leave-btn" class="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold text-sm transition-all active:scale-95 shadow-md shadow-amber-500/20">
          <span class="material-symbols-outlined text-[18px]">event_busy</span>Apply Leave
        </button>
      </div>
    </div>
  </div>

  <!-- Toast -->
  <div id="toast" class="hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold flex items-center gap-2"></div>

  <script>
    const TODAY = '<?= $today_date ?>';
    let modalKey = '',
      modalSubjectId = 0,
      modalSemesterId = 0,
      modalDivisionId = 0;

    // ── Leave Modal ───────────────────────────────────────────────────────────────
    function openLeaveModal(key, subjectId, semesterId, divisionId, subjectName, classLabel) {
      modalKey = key;
      modalSubjectId = subjectId;
      modalSemesterId = semesterId;
      modalDivisionId = divisionId;
      document.getElementById('modal-class-label').textContent = subjectName + ' · ' + classLabel;
      document.getElementById('leave-reason').value = '';
      document.getElementById('leave-modal').classList.remove('hidden');
      setTimeout(() => document.getElementById('leave-reason').focus(), 100);
    }

    function closeLeaveModal() {
      document.getElementById('leave-modal').classList.add('hidden');
    }

    // Close on backdrop click
    document.getElementById('leave-modal').addEventListener('click', function(e) {
      if (e.target === this) closeLeaveModal();
    });

    // ── Submit Leave ──────────────────────────────────────────────────────────────
    async function submitLeave() {
      const reason = document.getElementById('leave-reason').value.trim();
      const btn = document.getElementById('submit-leave-btn');

      btn.disabled = true;
      btn.innerHTML = '<div class="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>';

      try {
        const res = await fetch('../backend/attendance/manage_leave.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            action: 'apply',
            subject_id: modalSubjectId,
            semester_id: modalSemesterId,
            division_id: modalDivisionId,
            leave_date: TODAY,
            reason: reason
          })
        });
        const data = await res.json();

        if (!data.success) {
          toast(data.message, 'error');
          return;
        }

        closeLeaveModal();
        toast('Leave applied successfully.', 'success');

        // Reload after short delay to refresh row UI
        setTimeout(() => location.reload(), 1000);

      } catch (e) {
        toast('Network error: ' + e.message, 'error');
        console.error(e);
      }

      btn.disabled = false;
      btn.innerHTML = '<span class="material-symbols-outlined text-[18px]">event_busy</span>Apply Leave';
    }

    // ── Cancel Leave ──────────────────────────────────────────────────────────────
    async function cancelLeave(key, subjectId, semesterId, divisionId) {
      if (!confirm('Cancel leave for this class? You will be able to take attendance again.')) return;

      try {
        const res = await fetch('../backend/attendance/manage_leave.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            action: 'cancel',
            subject_id: subjectId,
            semester_id: semesterId,
            division_id: divisionId,
            leave_date: TODAY
          })
        });
        const data = await res.json();

        if (!data.success) {
          toast(data.message, 'error');
          return;
        }

        toast('Leave cancelled.', 'success');
        setTimeout(() => location.reload(), 800);

      } catch (e) {
        toast('Network error: ' + e.message, 'error');
      }
    }

    // ── Toast ─────────────────────────────────────────────────────────────────────
    function toast(msg, type) {
      const t = document.getElementById('toast');
      t.innerHTML = `<span class="material-symbols-outlined text-[18px]">${type==='success'?'check_circle':'error'}</span>${msg}`;
      t.className = `fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold flex items-center gap-2 ${type==='success'?'bg-green-600':'bg-red-500'}`;
      t.classList.remove('hidden');
      setTimeout(() => t.classList.add('hidden'), 3500);
    }
  </script>
</body>

</html>