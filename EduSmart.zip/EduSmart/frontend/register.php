<!DOCTYPE html>
<html class="light" lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>EduSmart - Create Account</title>
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&amp;display=swap" rel="stylesheet" />
  <!-- Material Symbols -->
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet" />
  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <!-- Theme Configuration -->
  <script id="tailwind-config">
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            primary: "#2b8cee",
            "primary-dark": "#1a73c9",
            "background-light": "#f6f7f8",
            "background-dark": "#101922",
          },
          fontFamily: {
            display: ["Inter", "sans-serif"],
          },
          borderRadius: {
            DEFAULT: "0.25rem",
            lg: "0.5rem",
            xl: "0.75rem",
            full: "9999px",
          },
        },
      },
    };
  </script>
</head>

<body class="font-display bg-background-light dark:bg-background-dark text-slate-900 dark:text-white antialiased min-h-screen flex flex-col relative overflow-x-hidden selection:bg-primary/30 selection:text-primary-dark">
  <!-- Decorative Background Elements -->
  <div aria-hidden="true" class="fixed inset-0 z-0 pointer-events-none overflow-hidden">
    <div class="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-primary/5 blur-[100px]"></div>
    <div class="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-blue-400/5 blur-[100px]"></div>
  </div>
  <!-- Main Content Container -->
  <div class="relative z-10 flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8">
    <!-- Registration Card -->
    <div class="w-full max-w-[520px] bg-white dark:bg-slate-800 rounded-xl shadow-xl dark:shadow-slate-900/20 border border-slate-100 dark:border-slate-700 overflow-hidden flex flex-col">
      <!-- Header Section -->
      <div class="px-8 pt-8 pb-4 text-center">
        <div class="mx-auto w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mb-4 text-primary">
          <span class="material-symbols-outlined text-[32px]">school</span>
        </div>
        <h1 class="text-[#0d141b] dark:text-white tracking-tight text-[28px] font-bold leading-tight mb-2">
          Create Your EduSmart Account
        </h1>
        <p class="text-[#4c739a] dark:text-slate-400 text-sm font-normal leading-normal">
          Join your smart learning community today.
        </p>
      </div>
      <!-- Role Selection (Segmented Buttons) -->
      <form id="registerForm" class="flex flex-col gap-5 px-8 pb-8 pt-4" method="POST" action="../backend/users/register.php">
        <div class="px-8 py-2">
          <div class="flex h-12 w-full items-center justify-center rounded-lg bg-[#e7edf3] dark:bg-slate-700 p-1">
            <label class="flex cursor-pointer h-full flex-1 items-center justify-center overflow-hidden rounded-md px-2 has-[:checked]:bg-white dark:has-[:checked]:bg-slate-600 has-[:checked]:shadow-sm has-[:checked]:text-primary dark:has-[:checked]:text-white text-[#4c739a] dark:text-slate-400 transition-all duration-200">
              <span class="material-symbols-outlined text-[20px] mr-2">person</span>
              <span class="truncate text-sm font-medium">Student</span>
              <input checked="" class="hidden" name="role" type="radio" value="student" />
            </label>
            <label class="flex cursor-pointer h-full flex-1 items-center justify-center overflow-hidden rounded-md px-2 has-[:checked]:bg-white dark:has-[:checked]:bg-slate-600 has-[:checked]:shadow-sm has-[:checked]:text-primary dark:has-[:checked]:text-white text-[#4c739a] dark:text-slate-400 transition-all duration-200">
              <span class="material-symbols-outlined text-[20px] mr-2">school</span>
              <span class="truncate text-sm font-medium">Teacher</span>
              <input class="hidden" name="role" type="radio" value="teacher" />
            </label>
          </div>
        </div>
        <!-- Registration Form -->
        <!-- Full Name -->
        <div class="flex flex-col gap-1.5">
          <label class="text-[#0d141b] dark:text-slate-200 text-sm font-medium leading-normal">Full Name</label>
          <div class="relative">
            <input id="name" class="form-input w-full rounded-lg border border-[#cfdbe7] dark:border-slate-600 bg-slate-50 dark:bg-slate-700/50 text-[#0d141b] dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/20 focus:border-primary h-12 px-4 placeholder:text-[#4c739a] dark:placeholder:text-slate-500 text-base transition-all" type="text" autocomplete="off" name="name" />
            <span class="material-symbols-outlined absolute right-4 top-3 text-[#4c739a] dark:text-slate-500 text-[20px]">person</span>
          </div>
          <p id="nameError" class="text-red-500 text-xs mt-1"></p>
        </div>
        <!-- Email -->
        <div class="flex flex-col gap-1.5">
          <label class="text-[#0d141b] dark:text-slate-200 text-sm font-medium leading-normal">Email Address</label>
          <div class="relative">
            <input id="email" class="form-input w-full rounded-lg border border-[#cfdbe7] dark:border-slate-600 bg-slate-50 dark:bg-slate-700/50 text-[#0d141b] dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/20 focus:border-primary h-12 px-4 placeholder:text-[#4c739a] dark:placeholder:text-slate-500 text-base transition-all" type="email" autocomplete="off" name="email" />
            <span class="material-symbols-outlined absolute right-4 top-3 text-[#4c739a] dark:text-slate-500 text-[20px]">mail</span>
          </div>
          <p id="emailError" class="text-red-500 text-xs mt-1"></p>
        </div>
        <!-- Conditional Field (Defaulting to Student View) -->
        <!-- Ideally this label and placeholder change based on the Role Selection above via React state -->
        <div class="flex flex-col gap-1.5">
          <label class="text-[#0d141b] dark:text-slate-200 text-sm font-medium leading-normal">Enrollment Number</label>
          <div class="relative">
            <input id="uid" class="form-input w-full rounded-lg border border-[#cfdbe7] dark:border-slate-600 bg-slate-50 dark:bg-slate-700/50 text-[#0d141b] dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/20 focus:border-primary h-12 px-4 placeholder:text-[#4c739a] dark:placeholder:text-slate-500 text-base transition-all" type="text" autocomplete="off" name="uid" />
            <span class="material-symbols-outlined absolute right-4 top-3 text-[#4c739a] dark:text-slate-500 text-[20px]">badge</span>
          </div>
          <p id="uidError" class="text-red-500 text-xs mt-1"></p>
          <p class="text-xs text-[#4c739a] dark:text-slate-500 mt-0.5">
            Use Employee ID if registering as a Teacher
          </p>
        </div>

        <!-- Password Fields Row -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div class="flex flex-col gap-1.5">
            <label class="text-[#0d141b] dark:text-slate-200 text-sm font-medium leading-normal">Password</label>
            <div class="relative">
              <input id="password" class="form-input w-full rounded-lg border border-[#cfdbe7] dark:border-slate-600 bg-slate-50 dark:bg-slate-700/50 text-[#0d141b] dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/20 focus:border-primary h-12 px-4 placeholder:text-[#4c739a] dark:placeholder:text-slate-500 text-base transition-all" type="password" autocomplete="off" name="password" />
              <button class="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 focus:outline-none" type="button" id="togglePassword1">
                <span class="material-symbols-outlined text-[20px]" id="passwordIcon1">visibility</span>
              </button>
            </div>
            <p id="passwordError" class="text-red-500 text-xs mt-1"></p>
          </div>
          <div class="flex flex-col gap-1.5">
            <label class="text-[#0d141b] dark:text-slate-200 text-sm font-medium leading-normal">Confirm Password</label>
            <div class="relative">
              <input id="confirmPassword" class="form-input w-full rounded-lg border border-[#cfdbe7] dark:border-slate-600 bg-slate-50 dark:bg-slate-700/50 text-[#0d141b] dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/20 focus:border-primary h-12 px-4 placeholder:text-[#4c739a] dark:placeholder:text-slate-500 text-base transition-all" type="password" autocomplete="off" />
              <button class="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 focus:outline-none" type="button" id="togglePassword2">
                <span class="material-symbols-outlined text-[20px]" id="passwordIcon2">visibility</span>
              </button>
            </div>
            <p id="confirmPasswordError" class="text-red-500 text-xs mt-1"></p>

          </div>
        </div>
        <!-- Terms Checkbox -->
        <div class="flex items-start gap-3 mt-1">
          <div class="flex items-center h-5">
            <input id="terms" class="w-4 h-4 rounded border-[#cfdbe7] dark:border-slate-600 text-primary focus:ring-primary bg-white dark:bg-slate-700" id="terms" type="checkbox" />
          </div>
          <label class="text-sm text-[#4c739a] dark:text-slate-400 leading-tight" for="terms">
            I agree to the
            <a class="text-primary hover:text-primary-dark hover:underline font-medium transition-colors" href="#">Terms &amp; Conditions</a>
            and
            <a class="text-primary hover:text-primary-dark hover:underline font-medium transition-colors" href="#">Privacy Policy</a>.
          </label>
          <p id="termsError" class="text-red-500 text-xs mt-1"></p>
        </div>
        <!-- Submit Button -->
        <button class="mt-2 w-full h-12 bg-primary hover:bg-primary-dark text-white text-base font-bold rounded-lg shadow-md shadow-primary/20 dark:shadow-none transition-all duration-200 flex items-center justify-center gap-2" type="submit">
          Create Account
          <span class="material-symbols-outlined text-[20px]">arrow_forward</span>
        </button>
        <!-- Login Link -->
        <div class="flex justify-center items-center mt-2">
          <p class="text-[#4c739a] dark:text-slate-400 text-sm">
            Already have an account?
            <a class="text-primary hover:text-primary-dark font-semibold hover:underline transition-colors ml-1" href="login.php">Log In</a>
          </p>
        </div>
      </form>
    </div>
    <!-- Footer Info -->
    <div class="absolute bottom-4 text-center w-full pointer-events-none">
      <p class="text-xs text-[#4c739a]/60 dark:text-slate-500">
        EduSmart &copy; <?php echo date('Y'); ?>. All Rights Reserved.
      </p>
    </div>
  </div>


  <script>
    function sendRole(role) {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "", true);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

      // xhr.onload = function () {
      //     document.getElementById("result").innerHTML = this.responseText;
      // };

      xhr.send("role=" + role);
    }


    document.addEventListener('DOMContentLoaded', function() {
      // Get form elements
      const form = document.getElementById('registerForm');
      const nameInput = document.getElementById('name');
      const emailInput = document.getElementById('email');
      const uidInput = document.getElementById('uid');
      const passwordInput = document.getElementById('password');
      const confirmPasswordInput = document.getElementById('confirmPassword');
      const termsCheckbox = document.getElementById('terms');
      const roleRadios = document.querySelectorAll('input[name="role"]');

      // Get error message elements
      const nameError = document.getElementById('nameError');
      const emailError = document.getElementById('emailError');
      const uidError = document.getElementById('uidError');
      const passwordError = document.getElementById('passwordError');
      const confirmPasswordError = document.getElementById('confirmPasswordError');
      const termsError = document.getElementById('termsError');

      // Get the label text for UID field (Enrollment Number / Employee ID)
      const uidLabel = document.querySelector('label[for="uid"]');
      const uidHelperText = document.querySelector('.flex.flex-col.gap-1\\[13px\\] .text-xs.text-\\[\\#4c739a\\]');

      // Helper function to show error
      function showError(errorElement, message) {
        if (errorElement) {
          errorElement.textContent = message;
          errorElement.classList.add('text-red-500');
        }
      }

      // Helper function to clear error
      function clearError(errorElement) {
        if (errorElement) {
          errorElement.textContent = '';
        }
      }

      // Helper function to add/remove error styling on input
      function setInputErrorStyle(input, isValid) {
        if (isValid) {
          input.classList.remove('border-red-500', 'focus:ring-red-500/20');
          input.classList.add('border-[#cfdbe7]', 'dark:border-slate-600');
        } else {
          input.classList.remove('border-[#cfdbe7]', 'dark:border-slate-600');
          input.classList.add('border-red-500', 'focus:ring-red-500/20');
        }
      }

      // Update UID field label based on selected role
      function updateUidField() {
        let selectedRole = 'student';
        for (const radio of roleRadios) {
          if (radio.checked) {
            selectedRole = radio.value;
            break;
          }
        }

        if (selectedRole === 'student') {
          if (uidLabel) uidLabel.textContent = 'Enrollment Number';
          if (uidHelperText) uidHelperText.textContent = 'Enter your valid college enrollment number';
          uidInput.placeholder = 'e.g., 2024CS101';
        } else {
          if (uidLabel) uidLabel.textContent = 'Employee ID';
          if (uidHelperText) uidHelperText.textContent = 'Enter your valid employee ID';
          uidInput.placeholder = 'e.g., TCH2024001';
        }
        // Clear any existing error when role changes
        clearError(uidError);
        setInputErrorStyle(uidInput, true);
      }

      // Add event listeners to role radios
      roleRadios.forEach(radio => {
        radio.addEventListener('change', updateUidField);
      });

      // Initialize UID field on page load
      updateUidField();

      // Validation functions
      function validateName() {
        const name = nameInput.value.trim();

        if (name === '') {
          showError(nameError, 'Full name is required');
          setInputErrorStyle(nameInput, false);
          return false;
        }

        if (name.length < 3) {
          showError(nameError, 'Full name must be at least 3 characters');
          setInputErrorStyle(nameInput, false);
          return false;
        }

        if (name.length > 100) {
          showError(nameError, 'Full name must not exceed 100 characters');
          setInputErrorStyle(nameInput, false);
          return false;
        }

        // Allow letters, spaces, dots, hyphens, and apostrophes
        if (!/^[a-zA-Z\s\.\-']+$/.test(name)) {
          showError(nameError, 'Name can only contain letters, spaces, dots, hyphens, and apostrophes');
          setInputErrorStyle(nameInput, false);
          return false;
        }

        clearError(nameError);
        setInputErrorStyle(nameInput, true);
        return true;
      }

      function validateEmail() {
        const email = emailInput.value.trim();

        if (email === '') {
          showError(emailError, 'Email address is required');
          setInputErrorStyle(emailInput, false);
          return false;
        }

        // Comprehensive email validation regex
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailRegex.test(email)) {
          showError(emailError, 'Please enter a valid email address (e.g., name@example.com)');
          setInputErrorStyle(emailInput, false);
          return false;
        }

        // Check for common typos or suspicious patterns
        if (email.includes('..')) {
          showError(emailError, 'Email address cannot contain consecutive dots');
          setInputErrorStyle(emailInput, false);
          return false;
        }

        if (email.length > 254) {
          showError(emailError, 'Email address is too long');
          setInputErrorStyle(emailInput, false);
          return false;
        }

        clearError(emailError);
        setInputErrorStyle(emailInput, true);
        return true;
      }

      function validateUid() {
        const uid = uidInput.value.trim();
        let selectedRole = 'student';

        for (const radio of roleRadios) {
          if (radio.checked) {
            selectedRole = radio.value;
            break;
          }
        }

        if (uid === '') {
          const fieldName = selectedRole === 'student' ? 'Enrollment number' : 'Employee ID';
          showError(uidError, `${fieldName} is required`);
          setInputErrorStyle(uidInput, false);
          return false;
        }

        if (uid.length < 4) {
          const fieldName = selectedRole === 'student' ? 'Enrollment number' : 'Employee ID';
          showError(uidError, `${fieldName} must be at least 4 characters`);
          setInputErrorStyle(uidInput, false);
          return false;
        }

        if (uid.length > 50) {
          const fieldName = selectedRole === 'student' ? 'Enrollment number' : 'Employee ID';
          showError(uidError, `${fieldName} must not exceed 50 characters`);
          setInputErrorStyle(uidInput, false);
          return false;
        }

        // Allow alphanumeric, hyphens, underscores, and slashes
        if (!/^[a-zA-Z0-9\-_\/]+$/.test(uid)) {
          const fieldName = selectedRole === 'student' ? 'Enrollment number' : 'Employee ID';
          showError(uidError, `${fieldName} can only contain letters, numbers, hyphens, underscores, and slashes`);
          setInputErrorStyle(uidInput, false);
          return false;
        }

        clearError(uidError);
        setInputErrorStyle(uidInput, true);
        return true;
      }

      function validatePassword() {
        const password = passwordInput.value;

        if (password === '') {
          showError(passwordError, 'Password is required');
          setInputErrorStyle(passwordInput, false);
          return false;
        }

        if (password.length < 8) {
          showError(passwordError, 'Password must be at least 8 characters long');
          setInputErrorStyle(passwordInput, false);
          return false;
        }

        if (password.length > 64) {
          showError(passwordError, 'Password must not exceed 64 characters');
          setInputErrorStyle(passwordInput, false);
          return false;
        }

        // Check for at least one uppercase letter
        if (!/[A-Z]/.test(password)) {
          showError(passwordError, 'Password must contain at least one uppercase letter');
          setInputErrorStyle(passwordInput, false);
          return false;
        }

        // Check for at least one lowercase letter
        if (!/[a-z]/.test(password)) {
          showError(passwordError, 'Password must contain at least one lowercase letter');
          setInputErrorStyle(passwordInput, false);
          return false;
        }

        // Check for at least one number
        if (!/[0-9]/.test(password)) {
          showError(passwordError, 'Password must contain at least one number');
          setInputErrorStyle(passwordInput, false);
          return false;
        }

        // Check for at least one special character
        if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
          showError(passwordError, 'Password must contain at least one special character (!@#$%^&*(),.?":{}|<>)');
          setInputErrorStyle(passwordInput, false);
          return false;
        }

        clearError(passwordError);
        setInputErrorStyle(passwordInput, true);
        return true;
      }

      function validateConfirmPassword() {
        const password = passwordInput.value;
        const confirmPassword = confirmPasswordInput.value;

        if (confirmPassword === '') {
          showError(confirmPasswordError, 'Please confirm your password');
          setInputErrorStyle(confirmPasswordInput, false);
          return false;
        }

        if (password !== confirmPassword) {
          showError(confirmPasswordError, 'Passwords do not match');
          setInputErrorStyle(confirmPasswordInput, false);
          return false;
        }

        clearError(confirmPasswordError);
        setInputErrorStyle(confirmPasswordInput, true);
        return true;
      }

      function validateTerms() {
        if (!termsCheckbox.checked) {
          showError(termsError, 'You must agree to the Terms & Conditions and Privacy Policy');
          return false;
        }

        clearError(termsError);
        return true;
      }

      // Real-time validation on input/blur
      nameInput.addEventListener('input', validateName);
      nameInput.addEventListener('blur', validateName);

      emailInput.addEventListener('input', validateEmail);
      emailInput.addEventListener('blur', validateEmail);

      uidInput.addEventListener('input', validateUid);
      uidInput.addEventListener('blur', validateUid);

      passwordInput.addEventListener('input', function() {
        validatePassword();
        if (confirmPasswordInput.value) {
          validateConfirmPassword();
        }
      });
      passwordInput.addEventListener('blur', validatePassword);

      confirmPasswordInput.addEventListener('input', validateConfirmPassword);
      confirmPasswordInput.addEventListener('blur', validateConfirmPassword);

      termsCheckbox.addEventListener('change', validateTerms);

      // Password visibility toggle
      const togglePassword1 = document.getElementById('togglePassword1');
      const togglePassword2 = document.getElementById('togglePassword2');
      const passwordIcon1 = document.getElementById('passwordIcon1');
      const passwordIcon2 = document.getElementById('passwordIcon2');

      if (togglePassword1) {
        togglePassword1.addEventListener('click', function() {
          const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
          passwordInput.setAttribute('type', type);
          passwordIcon1.textContent = type === 'password' ? 'visibility' : 'visibility_off';
        });
      }

      if (togglePassword2) {
        togglePassword2.addEventListener('click', function() {
          const type = confirmPasswordInput.getAttribute('type') === 'password' ? 'text' : 'password';
          confirmPasswordInput.setAttribute('type', type);
          passwordIcon2.textContent = type === 'password' ? 'visibility' : 'visibility_off';
        });
      }

      // Form submission validation
      if (form) {
        form.addEventListener('submit', function(e) {
          // Run all validations
          const isNameValid = validateName();
          const isEmailValid = validateEmail();
          const isUidValid = validateUid();
          const isPasswordValid = validatePassword();
          const isConfirmPasswordValid = validateConfirmPassword();
          const isTermsValid = validateTerms();

          // Check if all validations passed
          const isValid = isNameValid && isEmailValid && isUidValid &&
            isPasswordValid && isConfirmPasswordValid && isTermsValid;

          if (!isValid) {
            e.preventDefault();

            // Scroll to first error
            const firstErrorInput = document.querySelector('.border-red-500');
            if (firstErrorInput) {
              firstErrorInput.scrollIntoView({
                behavior: 'smooth',
                block: 'center'
              });
              firstErrorInput.focus();
            }

            // Show error summary toast
            showErrorToast('Please fix the errors before submitting the form.');
          }
        });
      }

      // Function to show error toast
      function showErrorToast(message) {
        // Remove existing toast if any
        const existingToast = document.querySelector('.error-toast');
        if (existingToast) {
          existingToast.remove();
        }

        const toast = document.createElement('div');
        toast.className = 'error-toast fixed bottom-4 right-4 bg-red-500 text-white px-4 py-3 rounded-lg shadow-lg z-50 flex items-center gap-2 animate-slide-in';
        toast.innerHTML = `
                <span class="material-symbols-outlined text-white">error</span>
                <span class="text-sm font-medium">${message}</span>
            `;
        document.body.appendChild(toast);

        // Add animation styles if not present
        if (!document.querySelector('#toast-styles')) {
          const style = document.createElement('style');
          style.id = 'toast-styles';
          style.textContent = `
                    @keyframes slideIn {
                        from {
                            transform: translateX(100%);
                            opacity: 0;
                        }
                        to {
                            transform: translateX(0);
                            opacity: 1;
                        }
                    }
                    .animate-slide-in {
                        animation: slideIn 0.3s ease-out;
                    }
                `;
          document.head.appendChild(style);
        }

        // Remove toast after 3 seconds
        setTimeout(() => {
          toast.style.opacity = '0';
          toast.style.transition = 'opacity 0.3s ease-out';
          setTimeout(() => {
            if (toast.parentNode) toast.remove();
          }, 300);
        }, 3000);
      }

      // Real-time password strength indicator (optional enhancement)
      function updatePasswordStrength() {
        const password = passwordInput.value;
        const strengthIndicator = document.getElementById('passwordStrength');

        if (!strengthIndicator && password.length > 0) {
          // Create strength indicator if it doesn't exist
          const strengthDiv = document.createElement('div');
          strengthDiv.id = 'passwordStrength';
          strengthDiv.className = 'text-xs mt-1 flex items-center gap-1';
          passwordInput.parentNode.parentNode.appendChild(strengthDiv);
        }

        const strengthDiv = document.getElementById('passwordStrength');
        if (strengthDiv && password.length > 0) {
          let strength = 0;
          let strengthText = '';
          let strengthColor = '';

          if (password.length >= 8) strength++;
          if (/[A-Z]/.test(password)) strength++;
          if (/[a-z]/.test(password)) strength++;
          if (/[0-9]/.test(password)) strength++;
          if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength++;

          switch (strength) {
            case 0:
            case 1:
              strengthText = 'Weak';
              strengthColor = 'text-red-500';
              break;
            case 2:
            case 3:
              strengthText = 'Medium';
              strengthColor = 'text-yellow-500';
              break;
            case 4:
            case 5:
              strengthText = 'Strong';
              strengthColor = 'text-green-500';
              break;
          }

          strengthDiv.innerHTML = `<span class="material-symbols-outlined text-[14px] ${strengthColor}">lock</span> <span class="${strengthColor}">Password strength: ${strengthText}</span>`;

          if (strength >= 4) {
            strengthDiv.innerHTML += ' <span class="text-green-500">✓</span>';
          }
        } else if (strengthDiv && password.length === 0) {
          strengthDiv.remove();
        }
      }

      // Add password strength indicator on input
      passwordInput.addEventListener('input', function() {
        validatePassword();
        updatePasswordStrength();
        if (confirmPasswordInput.value) {
          validateConfirmPassword();
        }
      });
    });
  </script>

  </script>

</body>

</html>