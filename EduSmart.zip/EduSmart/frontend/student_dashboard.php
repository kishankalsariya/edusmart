<?php

include("../backend/config/connection.php");
include("../backend/auth/auth.php");

if ($_SESSION['role'] !== 'student') {
  header("Location: login.php?error=unauthorized");
  exit();
}

$user_id = $_SESSION['user_id'];
date_default_timezone_set('Asia/Kolkata');

// ─── USER INFO ───────────────────────────────────────────────
$uq = $conn->prepare("SELECT * FROM users WHERE id = ?");
$uq->bind_param("i", $user_id);
$uq->execute();
$user = $uq->get_result()->fetch_assoc();

// ─── STUDENT PROFILE ─────────────────────────────────────────
$sq = $conn->prepare("
  SELECT s.*, sem.semester_no, d.division_name
  FROM students s
  JOIN semesters sem ON s.semester_id = sem.semester_id
  JOIN divisions d   ON s.division_id = d.division_id
  WHERE s.user_id = ?
");
$sq->bind_param("i", $user_id);
$sq->execute();
$student = $sq->get_result()->fetch_assoc();

// ─── ATTENDANCE STATS (Overall) ───────────────────────────────
$total_classes  = 0;
$attended       = 0;
$missed         = 0;
$overall_pct    = 0;
$subject_stats  = [];

if ($student) {
  $student_id = $student['student_id'];

  // Overall
  $aq = $conn->prepare("
    SELECT
      COUNT(*)                  AS total_classes,
      SUM(status = 'present')   AS attended,
      SUM(status = 'absent')    AS missed
    FROM attendance
    WHERE student_id = ?
  ");
  $aq->bind_param("i", $student_id);
  $aq->execute();
  $att = $aq->get_result()->fetch_assoc();

  $total_classes = (int)$att['total_classes'];
  $attended      = (int)$att['attended'];
  $missed        = (int)$att['missed'];
  $overall_pct   = $total_classes > 0 ? round(($attended / $total_classes) * 100, 1) : 0;

  // Subject-wise (for analytics section)
  $subq = $conn->prepare("
    SELECT
      s.subject_name,
      COUNT(*)                AS total,
      SUM(a.status='present') AS present,
      SUM(a.status='absent')  AS absent
    FROM attendance a
    JOIN subjects s ON a.subject_id = s.subject_id
    WHERE a.student_id = ?
    GROUP BY a.subject_id, s.subject_name
    ORDER BY s.subject_name
  ");
  $subq->bind_param("i", $student_id);
  $subq->execute();
  $subres = $subq->get_result();
  while ($row = $subres->fetch_assoc()) {
    $row['pct'] = $row['total'] > 0 ? round(($row['present'] / $row['total']) * 100, 1) : 0;
    $subject_stats[] = $row;
  }
}

// ─── TODAY'S LECTURES ────────────────────────────────────────
$lectures       = [];
$lecture_count  = 0;
$academic_year  = date('Y') . '-' . (date('Y') + 1);

if ($student) {
  $lq = $conn->prepare("
    SELECT
      s.subject_id,
      s.subject_name,
      stu.semester_id,
      stu.division_id,
      TIME_FORMAT(t.start_time, '%h:%i %p') AS start_time,
      TIME_FORMAT(t.end_time,   '%h:%i %p') AS end_time,
      t.start_time AS raw_start,
      t.end_time   AS raw_end,
      COALESCE(
        (SELECT u.name
         FROM subject_teacher_assignment sta
         JOIN teachers tch ON sta.teacher_id = tch.teacher_id
         JOIN users u       ON tch.user_id   = u.id
         WHERE sta.semester_id = stu.semester_id
           AND sta.division_id = stu.division_id
           AND sta.subject_id  = s.subject_id
           AND sta.academic_year = ?
           AND sta.status = 'active'
         LIMIT 1),
        'TBA'
      ) AS teacher_name,
      (SELECT tl.reason
       FROM subject_teacher_assignment sta2
       JOIN teacher_leaves tl
         ON tl.teacher_id  = sta2.teacher_id
        AND tl.subject_id  = sta2.subject_id
        AND tl.semester_id = sta2.semester_id
        AND tl.division_id = sta2.division_id
       WHERE sta2.semester_id   = stu.semester_id
         AND sta2.division_id   = stu.division_id
         AND sta2.subject_id    = s.subject_id
         AND sta2.academic_year = ?
         AND sta2.status        = 'active'
         AND tl.leave_date      = CURDATE()
       LIMIT 1
      ) AS leave_reason
    FROM students stu
    JOIN division_subject_teacher dst
      ON dst.semester_id = stu.semester_id
     AND dst.division_id = stu.division_id
    JOIN timetable t ON dst.dst_id    = t.dst_id
    JOIN subjects  s ON dst.subject_id = s.subject_id
    WHERE stu.user_id = ?
      AND t.day = DAYNAME(CURDATE())
    ORDER BY t.start_time
  ");

  $lq->bind_param("ssi", $academic_year, $academic_year, $user_id);
  $lq->execute();
  $lres = $lq->get_result();
  while ($row = $lres->fetch_assoc()) {
    $lectures[] = $row;
  }
  $lecture_count = count($lectures);
}

// ─── HELPERS ─────────────────────────────────────────────────
function pct_color_class($pct)
{
  if ($pct >= 75) return ['text' => 'text-emerald-600 dark:text-emerald-400', 'bar' => 'bg-emerald-500', 'badge' => 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300', 'label' => 'Safe Zone', 'icon' => 'check_circle'];
  if ($pct >= 60) return ['text' => 'text-amber-600 dark:text-amber-400',   'bar' => 'bg-amber-500',   'badge' => 'bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300',   'label' => 'At Risk',   'icon' => 'warning'];
  return             ['text' => 'text-rose-600 dark:text-rose-400',     'bar' => 'bg-rose-500',    'badge' => 'bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300',       'label' => 'Critical',  'icon' => 'error'];
}

$clr = pct_color_class($overall_pct);

function lecture_status($raw_start, $raw_end, $leave_reason = null)
{
  // Teacher on leave — highest priority
  if ($leave_reason !== null) {
    return [
      'label'    => 'Teacher on Leave',
      'class'    => 'bg-rose-100 dark:bg-rose-900/30 text-rose-700 dark:text-rose-400',
      'on_leave' => true,
      'reason'   => $leave_reason,
    ];
  }
  $now = date('H:i:s');
  $s   = date('H:i:s', strtotime($raw_start));
  $e   = date('H:i:s', strtotime($raw_end));
  if ($now >= $s && $now <= $e) return ['label' => 'Ongoing',   'class' => 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400',   'on_leave' => false, 'reason' => ''];
  if ($now < $s)               return ['label' => 'Upcoming',  'class' => 'bg-amber-50 dark:bg-amber-900/30 text-amber-600 dark:text-amber-400', 'on_leave' => false, 'reason' => ''];
  return                              ['label' => 'Completed', 'class' => 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400',   'on_leave' => false, 'reason' => ''];
}

$initials = strtoupper(substr($user['name'], 0, 1));
?>
<!DOCTYPE html>
<html class="light" lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>EduSmart — Student Dashboard</title>
  <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            primary: "#2b8cee",
            "primary-dark": "#1a6ec0",
            "background-light": "#f6f7f8",
            "background-dark": "#101922",
          },
          fontFamily: {
            display: ["Lexend", "sans-serif"]
          },
          borderRadius: {
            DEFAULT: "0.25rem",
            lg: "0.5rem",
            xl: "0.75rem",
            "2xl": "1rem",
            full: "9999px"
          },
        },
      },
    };
  </script>
  <style>
    body {
      font-family: "Lexend", sans-serif;
    }

    ::-webkit-scrollbar {
      width: 6px;
      height: 6px;
    }

    ::-webkit-scrollbar-track {
      background: transparent;
    }

    ::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px;
    }

    ::-webkit-scrollbar-thumb:hover {
      background: #94a3b8;
    }

    .dark ::-webkit-scrollbar-thumb {
      background: #334155;
    }

    .material-symbols-outlined {
      font-variation-settings: "FILL" 0, "wght" 400, "GRAD" 0, "opsz" 24;
    }

    .icon-fill {
      font-variation-settings: "FILL" 1, "wght" 400, "GRAD" 0, "opsz" 24;
    }

    /* Animated progress bar */
    .bar-fill {
      width: 0%;
      transition: width 1.2s cubic-bezier(.4, 0, .2, 1);
    }

    /* Circle SVG */
    .circle-track {
      fill: none;
      stroke: #e2e8f0;
      stroke-width: 10;
    }

    .dark .circle-track {
      stroke: #1e293b;
    }

    .circle-prog {
      fill: none;
      stroke-width: 10;
      stroke-linecap: round;
      transform: rotate(-90deg);
      transform-origin: 50% 50%;
      transition: stroke-dashoffset 1.4s cubic-bezier(.4, 0, .2, 1);
    }
  </style>
</head>

<body class="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 antialiased overflow-hidden">
  <div class="flex h-screen w-full">

    <!-- ═══════════════════════════════ SIDEBAR ═══════════════════════════════ -->
    <aside class="hidden md:flex flex-col w-64 h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 shrink-0 z-20">
      <!-- Logo -->
      <div class="h-16 flex items-center px-6 border-b border-slate-100 dark:border-slate-800">
        <div class="flex items-center gap-3 mt-6 mb-6">
          <div class="bg-primary/10 p-2 rounded-xl">
            <span class="material-symbols-outlined text-primary text-2xl">school</span>
          </div>
          <div>
            <h1 class="text-lg font-bold leading-tight">EduSmart</h1>
            <p class="text-slate-500 text-xs">Student Portal</p>
          </div>
        </div>
      </div>

      <!-- Nav -->
      <nav class="flex-1 overflow-y-auto py-4 px-3 flex flex-col gap-1">
        <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-primary/10 text-primary font-semibold text-sm" href="#">
          <span class="material-symbols-outlined icon-fill">dashboard</span> Dashboard
        </a>
        <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors text-sm font-medium" href="student_attendance_details.php">
          <span class="material-symbols-outlined">calendar_month</span> Attendance
        </a>
        <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors text-sm font-medium" href="student_schedule.php">
          <span class="material-symbols-outlined">calendar_today</span> Schedule
        </a>
        <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors text-sm font-medium" href="student_doubts.php">
          <span class="material-symbols-outlined">chat_bubble</span> Doubts
        </a>
      </nav>

      <!-- Profile -->
      <div class="p-4 border-t border-slate-100 dark:border-slate-800">
        <a href="student_profile.php" class="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
          <div class="size-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm shrink-0">
            <?= $initials ?>
          </div>
          <div class="overflow-hidden">
            <p class="text-sm font-semibold truncate"><?= htmlspecialchars($user['name']) ?></p>
          </div>
        </a>
      </div>
    </aside>

    <!-- ═══════════════════════════ MAIN CONTENT ══════════════════════════════ -->
    <main class="flex-1 flex flex-col h-full relative overflow-hidden">

      <!-- Top Bar -->
      <header class="h-16 flex items-center justify-between px-4 md:px-8 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shrink-0 z-10">
        <div class="flex items-center gap-4">
          <button class="md:hidden p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
            <span class="material-symbols-outlined">menu</span>
          </button>
          <h1 class="text-lg font-bold hidden sm:block">Overview</h1>
        </div>
        <div class="flex items-center gap-3">
          <a href="../backend/users/logout.php">
            <button class="flex items-center gap-2 h-9 px-4 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors text-sm font-semibold">
              <span class="material-symbols-outlined text-[18px]">logout</span>
              <span class="hidden md:inline">Logout</span>
            </button>
          </a>
          <div class="md:hidden size-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs">
            <?= $initials ?>
          </div>
        </div>
      </header>

      <!-- Scrollable Content -->
      <div class="flex-1 overflow-y-auto p-4 md:p-8 scroll-smooth">
        <div class="max-w-6xl mx-auto flex flex-col gap-6">

          <!-- ── Profile Incomplete Banner ── -->
          <?php if (!$student) : ?>
            <div class="bg-amber-50 dark:bg-amber-900/20 border-l-4 border-amber-400 p-4 rounded-r-xl flex items-start gap-3">
              <span class="material-symbols-outlined text-amber-500 mt-0.5">warning</span>
              <div class="flex-1">
                <p class="text-sm font-bold text-amber-700 dark:text-amber-400">Your profile is incomplete!</p>
                <p class="text-sm text-amber-600 dark:text-amber-500 mt-0.5">
                  Please <a href="profile_completion_form.php" class="underline font-semibold hover:text-amber-800">complete your profile</a> to access all features including attendance tracking.
                </p>
              </div>
            </div>
          <?php endif; ?>

          <!-- ── Welcome + Sem/Div ── -->
          <div class="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
            <div>
              <h2 class="text-3xl md:text-4xl font-black tracking-tight">
                Welcome back, <?= htmlspecialchars(explode(' ', $user['name'])[0]) ?>! 👋
              </h2>
              <p class="text-slate-500 dark:text-slate-400 mt-1">Here's your academic overview for today, <?= date('l, F j') ?>.</p>
            </div>
            <?php if ($student) : ?>
              <div class="flex gap-2 shrink-0">
                <span class="text-sm font-semibold px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800">
                  Sem <?= htmlspecialchars($student['semester_no']) ?>
                </span>
                <span class="text-sm font-semibold px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 border border-blue-100 dark:border-blue-800">
                  Division <?= htmlspecialchars($student['division_name']) ?>
                </span>
                <span class="text-sm font-semibold px-3 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
                  Roll <?= htmlspecialchars($student['roll_no']) ?>
                </span>
              </div>
            <?php endif; ?>
          </div>

          <!-- ══════════════════════════════════════════════════════════════════
             STAT CARDS — Real data from DB
        ═══════════════════════════════════════════════════════════════════ -->
          <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">

            <!-- Card 1: Attendance % -->
            <div class="col-span-2 sm:col-span-1 bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700 relative overflow-hidden group">
              <div class="absolute right-0 top-0 p-3 opacity-[0.07] group-hover:opacity-[0.12] transition-opacity pointer-events-none">
                <span class="material-symbols-outlined text-8xl text-primary">pie_chart</span>
              </div>
              <p class="text-slate-500 dark:text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">Attendance Score</p>
              <div class="flex items-baseline gap-1">
                <h3 class="text-4xl font-black tracking-tight <?= $clr['text'] ?>">
                  <?= $total_classes > 0 ? $overall_pct . '%' : '--' ?>
                </h3>
              </div>
              <div class="mt-4">
                <?php if ($total_classes > 0) : ?>
                  <span class="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-lg <?= $clr['badge'] ?>">
                    <span class="material-symbols-outlined text-[14px]"><?= $clr['icon'] ?></span>
                    <?= $clr['label'] ?>
                  </span>
                <?php else : ?>
                  <span class="text-xs text-slate-400">No records yet</span>
                <?php endif; ?>
              </div>
            </div>

            <!-- Card 2: Total Classes -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700 relative overflow-hidden group">
              <div class="absolute right-0 top-0 p-3 opacity-[0.07] group-hover:opacity-[0.12] transition-opacity pointer-events-none">
                <span class="material-symbols-outlined text-8xl text-indigo-500">class</span>
              </div>
              <p class="text-slate-500 dark:text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">Total Classes</p>
              <h3 class="text-4xl font-black tracking-tight text-slate-900 dark:text-white"><?= $total_classes ?: '--' ?></h3>
              <p class="mt-4 text-xs text-slate-400"><?= $total_classes > 0 ? 'Held so far' : 'No records yet' ?></p>
            </div>

            <!-- Card 3: Attended -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700 relative overflow-hidden group">
              <div class="absolute right-0 top-0 p-3 opacity-[0.07] group-hover:opacity-[0.12] transition-opacity pointer-events-none">
                <span class="material-symbols-outlined text-8xl text-emerald-500">done_all</span>
              </div>
              <p class="text-slate-500 dark:text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">Classes Attended</p>
              <h3 class="text-4xl font-black tracking-tight text-emerald-600 dark:text-emerald-400"><?= $total_classes > 0 ? $attended : '--' ?></h3>
              <p class="mt-4 text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                <?= $total_classes > 0 ? 'out of ' . $total_classes . ' classes' : 'No records yet' ?>
              </p>
            </div>

            <!-- Card 4: Missed -->
            <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700 relative overflow-hidden group">
              <div class="absolute right-0 top-0 p-3 opacity-[0.07] group-hover:opacity-[0.12] transition-opacity pointer-events-none">
                <span class="material-symbols-outlined text-8xl text-rose-500">event_busy</span>
              </div>
              <p class="text-slate-500 dark:text-slate-400 text-xs font-semibold uppercase tracking-wider mb-2">Classes Missed</p>
              <h3 class="text-4xl font-black tracking-tight text-rose-600 dark:text-rose-400"><?= $total_classes > 0 ? $missed : '--' ?></h3>
              <p class="mt-4 text-xs font-medium <?= $missed > 0 ? 'text-rose-500 dark:text-rose-400' : 'text-slate-400' ?>">
                <?= $missed > 0 ? 'Keep it low!' : ($total_classes > 0 ? 'Perfect so far!' : 'No records yet') ?>
              </p>
            </div>
          </div>

          <!-- ════════════════════════════════════════════════════════════════
             ATTENDANCE ANALYTICS — Circle + Subject Bars
        ═══════════════════════════════════════════════════════════════════ -->
          <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700">
            <div class="flex justify-between items-center mb-6">
              <h3 class="text-lg font-bold">Attendance Analytics</h3>
              <a href="student_attendance_details.php" class="text-sm font-semibold text-primary hover:text-primary-dark transition-colors flex items-center gap-1">
                Full Details <span class="material-symbols-outlined text-[16px]">arrow_forward</span>
              </a>
            </div>

            <?php if ($total_classes > 0) : ?>
              <div class="flex flex-col lg:flex-row gap-8 items-center lg:items-start">

                <!-- Circular Progress -->
                <div class="shrink-0 flex flex-col items-center gap-3">
                  <div class="relative">
                    <?php
                    $radius = 72;
                    $circ   = 2 * M_PI * $radius;
                    $offset = $circ - ($circ * $overall_pct / 100);
                    $stroke_color = $overall_pct >= 75 ? '#22c55e' : ($overall_pct >= 60 ? '#f59e0b' : '#ef4444');
                    ?>
                    <svg width="180" height="180" viewBox="0 0 180 180">
                      <circle class="circle-track" cx="90" cy="90" r="<?= $radius ?>" />
                      <circle class="circle-prog" cx="90" cy="90" r="<?= $radius ?>" stroke="<?= $stroke_color ?>" stroke-dasharray="<?= round($circ, 2) ?>" stroke-dashoffset="<?= round($circ, 2) ?>" id="overall-circle" data-offset="<?= round($offset, 2) ?>" />
                    </svg>
                    <div class="absolute inset-0 flex flex-col items-center justify-center">
                      <span class="text-4xl font-black" style="color: <?= $stroke_color ?>"><?= $overall_pct ?>%</span>
                      <span class="text-xs text-slate-500 font-medium mt-0.5">Overall</span>
                    </div>
                  </div>
                </div>

                <!-- Subject-wise bars -->
                <div class="flex-1 w-full flex flex-col gap-4">
                  <!-- Overall bar first -->
                  <div>
                    <div class="flex justify-between text-sm font-semibold mb-1.5">
                      <span class="text-slate-700 dark:text-slate-200">Overall Attendance</span>
                      <span class="<?= $clr['text'] ?>"><?= $overall_pct ?>%</span>
                    </div>
                    <div class="h-3 w-full bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                      <div class="bar-fill h-full <?= $clr['bar'] ?> rounded-full" data-w="<?= $overall_pct ?>"></div>
                    </div>
                    <?php
                    $diff = round($overall_pct - 75, 1);
                    if ($diff >= 0) : ?>
                      <p class="text-xs text-emerald-600 dark:text-emerald-400 mt-1">
                        You are <strong><?= $diff ?>%</strong> above the minimum requirement (75%).
                      </p>
                    <?php else : ?>
                      <p class="text-xs text-rose-500 dark:text-rose-400 mt-1">
                        You are <strong><?= abs($diff) ?>%</strong> below the minimum requirement (75%). Attend more classes!
                      </p>
                    <?php endif; ?>
                  </div>
                </div>
              </div>

            <?php else : ?>
              <!-- No attendance data yet -->
              <div class="text-center py-12">
                <span class="material-symbols-outlined text-6xl text-slate-300 dark:text-slate-600 block mb-3">event_busy</span>
                <h4 class="text-base font-bold text-slate-600 dark:text-slate-300 mb-1">No Attendance Records Yet</h4>
                <p class="text-slate-400 text-sm max-w-sm mx-auto">Your attendance will show here once your teachers start marking it.</p>
              </div>
            <?php endif; ?>
          </div>

          <!-- ════════════════════════════════════════════════════════════════
             TODAY'S LECTURES
        ═══════════════════════════════════════════════════════════════════ -->
          <div class="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700">
            <div class="flex justify-between items-center mb-5">
              <h3 class="text-lg font-bold flex items-center gap-2">
                <span class="material-symbols-outlined text-primary">today</span>
                Today's Lectures
                <span class="text-sm font-normal text-slate-400">(<?= date('l') ?>)</span>
              </h3>
              <a href="student_schedule.php" class="text-sm font-semibold text-primary hover:text-primary-dark flex items-center gap-1">
                Full Schedule <span class="material-symbols-outlined text-[16px]">arrow_forward</span>
              </a>
            </div>

            <?php if ($lecture_count > 0) : ?>
              <div class="overflow-x-auto">
                <table class="w-full text-left text-sm">
                  <thead>
                    <tr class="border-b border-slate-100 dark:border-slate-700 text-xs text-slate-500 uppercase tracking-wider">
                      <th class="pb-3 pl-2 font-semibold">Subject</th>
                      <th class="pb-3 font-semibold">Time</th>
                      <th class="pb-3 font-semibold hidden sm:table-cell">Faculty</th>
                      <th class="pb-3 font-semibold text-right pr-2">Status</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-100 dark:divide-slate-700">
                    <?php foreach ($lectures as $lec) :
                      $leave = isset($lec['leave_reason']) ? $lec['leave_reason'] : null;
                      // leave_reason is NULL when no leave, empty string or text when on leave
                      $is_on_leave = array_key_exists('leave_reason', $lec) && $lec['leave_reason'] !== null;
                      $st = lecture_status($lec['raw_start'], $lec['raw_end'], $is_on_leave ? $lec['leave_reason'] : null);
                      $row_class = $is_on_leave
                        ? 'bg-rose-50/50 dark:bg-rose-900/10 border-l-4 border-l-rose-400'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-700/40 transition-colors';
                    ?>
                      <tr class="<?= $row_class ?>">
                        <td class="py-3 pl-2">
                          <div class="font-semibold text-slate-900 dark:text-white"><?= htmlspecialchars($lec['subject_name']) ?></div>
                        </td>
                        <td class="py-3 text-slate-500 dark:text-slate-400 text-xs"><?= $lec['start_time'] ?> – <?= $lec['end_time'] ?></td>
                        <td class="py-3 text-slate-500 dark:text-slate-400 hidden sm:table-cell text-xs">
                          <?php if ($is_on_leave) : ?>
                            <span class="line-through opacity-50"><?= htmlspecialchars($lec['teacher_name']) ?></span>
                            <span class="ml-1 text-rose-400 not-italic">(On Leave)</span>
                          <?php else : ?>
                            <?= htmlspecialchars($lec['teacher_name']) ?>
                          <?php endif; ?>
                        </td>
                        <td class="py-3 text-right pr-2">
                          <span class="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-lg <?= $st['class'] ?>">
                            <?php if ($st['label'] === 'Ongoing') : ?>
                              <span class="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse"></span>
                            <?php elseif ($is_on_leave) : ?>
                              <span class="material-symbols-outlined text-[13px]">person_off</span>
                            <?php endif; ?>
                            <?= $st['label'] ?>
                          </span>
                        </td>
                      </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
              <div class="mt-4 pt-4 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between gap-2 flex-wrap">
                <div class="flex items-center gap-2">
                  <span class="material-symbols-outlined text-primary text-[18px]">info</span>
                  <p class="text-xs text-slate-500"><?= $lecture_count ?> lecture<?= $lecture_count > 1 ? 's' : '' ?> scheduled today.</p>
                </div>
                <?php
                $leave_count = count(array_filter($lectures, fn ($l) => $l['leave_reason'] !== null));
                if ($leave_count > 0) :
                ?>
                  <div class="flex items-center gap-1.5 text-xs font-semibold text-rose-500 dark:text-rose-400 bg-rose-50 dark:bg-rose-900/20 px-2.5 py-1 rounded-lg">
                    <span class="material-symbols-outlined text-[14px]">person_off</span>
                    <?= $leave_count ?> lecture<?= $leave_count > 1 ? 's' : '' ?> cancelled (Teacher on Leave)
                  </div>
                <?php endif; ?>
              </div>

            <?php else : ?>
              <div class="text-center py-12">
                <div class="mx-auto w-16 h-16 bg-slate-100 dark:bg-slate-700 rounded-full flex items-center justify-center mb-4">
                  <span class="material-symbols-outlined text-slate-400 text-3xl">celebration</span>
                </div>
                <h4 class="text-base font-bold text-slate-700 dark:text-white mb-1">No Lectures Today!</h4>
                <p class="text-slate-400 text-sm max-w-sm mx-auto">Enjoy your free day. You have no lectures scheduled for <?= date('l, F j') ?>.</p>
              </div>
            <?php endif; ?>
          </div>

        </div><!-- /max-w -->
      </div><!-- /scroll -->
    </main>
  </div>

  <script>
    // Animate progress bars
    window.addEventListener('load', () => {
      document.querySelectorAll('.bar-fill[data-w]').forEach(el => {
        setTimeout(() => {
          el.style.width = el.dataset.w + '%';
        }, 100);
      });
      // Animate SVG circle
      const circle = document.getElementById('overall-circle');
      if (circle) {
        setTimeout(() => {
          circle.style.strokeDashoffset = circle.dataset.offset;
        }, 150);
      }
    });
  </script>
</body>

</html>