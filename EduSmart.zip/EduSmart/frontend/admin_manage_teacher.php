<?php
include("../backend/config/connection.php");
include("../backend/auth/auth.php");

if ($_SESSION['role'] !== 'admin') {
  header("Location: login.php?error=unauthorized");
  exit();
}

$today = date('Y-m-d');
$academic_year = date('Y') . '-' . (date('Y') + 1);

// ── 1. All teachers with stats ────────────────────────────────────────────────
$teachers_query = $conn->prepare("
    SELECT
        t.teacher_id,
        u.uid,
        u.id AS user_id,
        u.name,
        u.email,
        GROUP_CONCAT(DISTINCT s.subject_name ORDER BY s.subject_name SEPARATOR ', ') AS subjects,
        COUNT(DISTINCT sta.subject_id) AS total_assignments,
        COUNT(DISTINCT CONCAT(a.subject_id,'-',a.attendance_date)) AS total_lectures,
        (SELECT COUNT(*) FROM teacher_leaves tl WHERE tl.teacher_id = t.teacher_id) AS total_leaves,
        (SELECT COUNT(*) FROM teacher_leaves tl
        WHERE tl.teacher_id = t.teacher_id AND tl.leave_date = ?) AS on_leave_today
    FROM teachers t
    JOIN users u ON t.user_id = u.id
    LEFT JOIN subject_teacher_assignment sta ON sta.teacher_id = t.teacher_id AND sta.academic_year = ? AND sta.status = 'active'
    LEFT JOIN subjects s ON sta.subject_id = s.subject_id
    LEFT JOIN attendance a ON a.teacher_id = t.teacher_id
    GROUP BY t.teacher_id, u.uid, u.id, u.name, u.email
    ORDER BY u.name
");
if (!$teachers_query) {
  die("Prepare failed: " . $conn->error);
}
$teachers_query->bind_param("ss", $today, $academic_year);
$teachers_query->execute();
$teachers_result = $teachers_query->get_result();
$teachers = [];
while ($row = $teachers_result->fetch_assoc()) {
  $teachers[] = $row;
}
$teachers_query->close();

// ── 2. Today's leave subjects per teacher ─────────────────────────────────────
// Result: [ teacher_id => [ subject_name, subject_name, ... ] ]
$leave_subjects_today = [];
$lsq = $conn->query("
    SELECT tl.teacher_id, s.subject_name
    FROM teacher_leaves tl
    JOIN subjects s ON tl.subject_id = s.subject_id
    WHERE tl.leave_date = '{$today}'
");
if ($lsq) {
  while ($row = $lsq->fetch_assoc()) {
    $leave_subjects_today[$row['teacher_id']][] = $row['subject_name'];
  }
}

// ── 3. Summary stats ──────────────────────────────────────────────────────────
$total_teachers  = count($teachers);
$on_leave_today  = count(array_filter($teachers, fn ($t) => $t['on_leave_today'] > 0));
$total_leaves_month = 0;
$lm = $conn->query("SELECT COUNT(*) AS cnt FROM teacher_leaves WHERE MONTH(leave_date)=MONTH(CURDATE()) AND YEAR(leave_date)=YEAR(CURDATE())");
if ($lm) $total_leaves_month = (int)$lm->fetch_assoc()['cnt'];

// ── 3. Search / filter from GET ───────────────────────────────────────────────
$search       = trim($_GET['search'] ?? '');
$filter_status = trim($_GET['status'] ?? '');  // all | on_leave | active

// Apply filter on PHP side
$filtered = $teachers;
if ($search) {
  $s = strtolower($search);
  $filtered = array_values(array_filter(
    $filtered,
    fn ($t) =>
    str_contains(strtolower($t['name']), $s) ||
      str_contains(strtolower($t['email']), $s) ||
      str_contains(strtolower($t['employee_code'] ?? ''), $s)
  ));
}
if ($filter_status === 'on_leave') {
  $filtered = array_values(array_filter($filtered, fn ($t) => $t['on_leave_today'] > 0));
} elseif ($filter_status === 'active') {
  $filtered = array_values(array_filter($filtered, fn ($t) => $t['on_leave_today'] == 0));
}

$avatar_colors = [
  'bg-blue-100 text-blue-700',
  'bg-purple-100 text-purple-700',
  'bg-emerald-100 text-emerald-700',
  'bg-amber-100 text-amber-700',
  'bg-rose-100 text-rose-700',
  'bg-teal-100 text-teal-700',
  'bg-indigo-100 text-indigo-700',
];
?>
<!DOCTYPE html>
<html class="light" lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>EduSmart — Manage Teachers</title>
  <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            primary: "#2b8cee",
            "primary-dark": "#1a6ec0",
            "background-light": "#f3f4f6",
            "background-dark": "#101922",
            "surface-light": "#ffffff",
            "surface-dark": "#1a2632"
          },
          fontFamily: {
            display: ["Lexend", "sans-serif"]
          },
          borderRadius: {
            DEFAULT: "0.25rem",
            lg: "0.5rem",
            xl: "0.75rem",
            "2xl": "1rem",
            full: "9999px"
          },
        }
      },
    };
  </script>
  <style>
    body {
      font-family: "Lexend", sans-serif;
    }

    ::-webkit-scrollbar {
      width: 6px;
      height: 6px
    }

    ::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px
    }

    .dark ::-webkit-scrollbar-thumb {
      background: #334155
    }

    .material-symbols-outlined {
      font-variation-settings: "FILL" 0, "wght" 400, "GRAD" 0, "opsz" 24
    }

    .fill {
      font-variation-settings: "FILL" 1, "wght" 400, "GRAD" 0, "opsz" 24
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(6px)
      }

      to {
        opacity: 1;
        transform: translateY(0)
      }
    }

    .fade-in {
      animation: fadeIn .25s ease forwards
    }
  </style>
</head>

<body class="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-slate-100 h-screen overflow-hidden flex">

  <!-- ═══════════ SIDEBAR ═══════════ -->
  <aside class="w-64 bg-surface-light dark:bg-surface-dark border-r border-slate-200 dark:border-slate-800 flex flex-col h-full shrink-0">
    <div class="p-6 flex items-center gap-3 border-b border-slate-100 dark:border-slate-800">
      <div class="bg-primary/10 rounded-xl p-2">
        <span class="material-symbols-outlined text-primary text-3xl fill">school</span>
      </div>
      <div>
        <h1 class="text-xl font-bold tracking-tight">EduSmart</h1>
        <p class="text-xs text-slate-500 font-medium">Admin Panel</p>
      </div>
    </div>
    <nav class="flex-1 px-4 py-4 flex flex-col gap-1 overflow-y-auto">
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-primary transition-colors" href="admin.php">
        <span class="material-symbols-outlined">dashboard</span><span class="font-medium text-sm">Dashboard</span>
      </a>
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-primary/10 text-primary font-semibold" href="#">
        <span class="material-symbols-outlined fill">person_search</span><span class="text-sm">Manage Teachers</span>
      </a>
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-primary transition-colors" href="admin_manage_student.php">
        <span class="material-symbols-outlined">groups</span><span class="font-medium text-sm">Manage Students</span>
      </a>
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-primary transition-colors" href="admin_assign_teacher.php">
        <span class="material-symbols-outlined">assignment_ind</span><span class="font-medium text-sm">Assign Teachers</span>
      </a>
    </nav>
    <div class="px-4 py-4 border-t border-slate-100 dark:border-slate-800">
      <a href="../backend/users/logout.php" class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors">
        <span class="material-symbols-outlined">logout</span><span class="text-sm font-medium">Logout</span>
      </a>
    </div>
  </aside>

  <!-- ═══════════ MAIN ═══════════ -->
  <main class="flex-1 flex flex-col h-full overflow-hidden">

    <!-- Top Header -->
    <header class="flex items-center justify-between px-8 py-5 bg-surface-light dark:bg-surface-dark border-b border-slate-200 dark:border-slate-800 shrink-0">
      <div>
        <h2 class="text-2xl font-bold">Manage Teachers</h2>
        <p class="text-xs text-slate-500 mt-0.5"><?= date('l, F j, Y') ?></p>
      </div>
      <div class="flex items-center gap-3">
        <!-- <button onclick="document.documentElement.classList.toggle('dark')" class="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
          <span class="material-symbols-outlined">dark_mode</span>
        </button> -->
        <a href="../frontend/register.php" target="_blank" class="flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-5 py-2.5 rounded-xl font-semibold text-sm transition-all shadow-md shadow-primary/20 active:scale-95">
          <span class="material-symbols-outlined text-[20px]">add</span>Add Teacher
        </a>
      </div>
    </header>

    <!-- Scrollable Content -->
    <div class="flex-1 overflow-y-auto p-8">
      <div class="max-w-[1300px] mx-auto flex flex-col gap-6">

        <!-- ── STAT CARDS ── -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">

          <!-- Total Teachers -->
          <div class="bg-surface-light dark:bg-surface-dark rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm relative overflow-hidden">
            <div class="absolute right-2 top-2 opacity-[0.07] pointer-events-none"><span class="material-symbols-outlined text-7xl text-blue-500">school</span></div>
            <p class="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">Total Teachers</p>
            <h3 class="text-4xl font-black text-slate-900 dark:text-white"><?= $total_teachers ?></h3>
            <p class="text-xs text-slate-400 mt-2">Registered in system</p>
          </div>

          <!-- On Leave Today -->
          <div class="<?= $on_leave_today > 0 ? 'bg-amber-50 dark:bg-amber-900/20 border-amber-200 dark:border-amber-800' : 'bg-surface-light dark:bg-surface-dark border-slate-200 dark:border-slate-800' ?> rounded-2xl border p-5 shadow-sm relative overflow-hidden cursor-pointer" onclick="setFilter('on_leave')">
            <div class="absolute right-2 top-2 opacity-[0.1] pointer-events-none"><span class="material-symbols-outlined text-7xl text-amber-500">event_busy</span></div>
            <p class="text-xs font-semibold uppercase tracking-wider <?= $on_leave_today > 0 ? 'text-amber-600' : 'text-slate-500' ?> mb-2">On Leave Today</p>
            <h3 class="text-4xl font-black <?= $on_leave_today > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-900 dark:text-white' ?>"><?= $on_leave_today ?></h3>
            <p class="text-xs <?= $on_leave_today > 0 ? 'text-amber-500' : 'text-slate-400' ?> mt-2">Click to filter</p>
          </div>

          <!-- Active Today -->
          <div class="bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-100 dark:border-emerald-800 rounded-2xl p-5 shadow-sm relative overflow-hidden cursor-pointer" onclick="setFilter('active')">
            <div class="absolute right-2 top-2 opacity-[0.1] pointer-events-none"><span class="material-symbols-outlined text-7xl text-emerald-500">person_check</span></div>
            <p class="text-xs font-semibold uppercase tracking-wider text-emerald-600 mb-2">Active Today</p>
            <h3 class="text-4xl font-black text-emerald-700 dark:text-emerald-400"><?= $total_teachers - $on_leave_today ?></h3>
            <p class="text-xs text-emerald-500 mt-2">Click to filter</p>
          </div>

          <!-- Leaves This Month -->
          <div class="bg-surface-light dark:bg-surface-dark border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm relative overflow-hidden">
            <div class="absolute right-2 top-2 opacity-[0.07] pointer-events-none"><span class="material-symbols-outlined text-7xl text-rose-500">calendar_month</span></div>
            <p class="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">Leaves This Month</p>
            <h3 class="text-4xl font-black text-slate-900 dark:text-white"><?= $total_leaves_month ?></h3>
            <p class="text-xs text-slate-400 mt-2"><?= date('F Y') ?></p>
          </div>
        </div>

        <!-- ── FILTER & SEARCH BAR ── -->
        <div class="bg-surface-light dark:bg-surface-dark p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <form method="GET" class="flex flex-col md:flex-row gap-4 items-end">
            <!-- Search -->
            <div class="flex flex-col flex-1 gap-1.5">
              <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Search</label>
              <div class="relative">
                <span class="material-symbols-outlined absolute left-3 top-2.5 text-slate-400 text-[20px]">search</span>
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Name, email or employee code..." autocomplete="off" class="w-full pl-10 pr-4 h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all" id="search-input" />
              </div>
            </div>
            <!-- Status filter -->
            <div class="flex flex-col w-full md:w-52 gap-1.5">
              <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Status</label>
              <div class="relative">
                <select name="status" id="status-filter" class="w-full h-11 px-4 pr-10 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none appearance-none transition-all">
                  <option value="" <?= $filter_status === ''         ? 'selected' : '' ?>>All Teachers</option>
                  <option value="active" <?= $filter_status === 'active'    ? 'selected' : '' ?>>Active Today</option>
                  <option value="on_leave" <?= $filter_status === 'on_leave'  ? 'selected' : '' ?>>On Leave Today</option>
                </select>
              </div>
            </div>
            <!-- Buttons -->
            <div class="flex items-end gap-2">
              <button type="submit" class="h-11 px-6 rounded-xl bg-primary hover:bg-primary-dark text-white font-semibold text-sm flex items-center gap-2 transition-all active:scale-95">
                <span class="material-symbols-outlined text-[18px]">filter_list</span>Filter
              </button>
              <a href="admin_manage_teacher.php" class="h-11 px-4 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-sm flex items-center gap-1.5 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                <span class="material-symbols-outlined text-[18px]">refresh</span>Clear
              </a>
            </div>
          </form>
        </div>

        <!-- ── TEACHER TABLE ── -->
        <div class="bg-surface-light dark:bg-surface-dark rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">

          <!-- Table Header Bar -->
          <div class="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40">
            <div class="flex items-center gap-2">
              <span class="text-sm font-semibold text-slate-700 dark:text-slate-200">
                <?= count($filtered) ?> teacher<?= count($filtered) !== 1 ? 's' : '' ?>
              </span>
              <?php if ($filter_status || $search) : ?>
                <span class="text-xs text-slate-400">(filtered from <?= $total_teachers ?>)</span>
              <?php endif; ?>
            </div>
            <?php if ($on_leave_today > 0) : ?>
              <span class="flex items-center gap-1.5 text-xs font-semibold text-amber-700 dark:text-amber-400 bg-amber-100 dark:bg-amber-900/30 px-3 py-1.5 rounded-lg">
                <span class="material-symbols-outlined text-[14px]">event_busy</span>
                <?= $on_leave_today ?> on leave today
              </span>
            <?php endif; ?>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse text-sm">
              <thead>
                <tr class="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-500 uppercase tracking-wider">
                  <th class="px-6 py-4">Teacher</th>
                  <th class="px-6 py-4 hidden sm:table-cell">Employee Code</th>
                  <th class="px-6 py-4 hidden lg:table-cell">Subjects Assigned</th>
                  <th class="px-6 py-4 text-center">Total Lectures</th>
                  <th class="px-6 py-4 text-center">Total Leaves</th>
                  <th class="px-6 py-4 text-center">Today's Status</th>
                  <th class="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                <?php if (empty($filtered)) : ?>
                  <tr>
                    <td colspan="7" class="px-6 py-16 text-center">
                      <span class="material-symbols-outlined text-5xl text-slate-300 dark:text-slate-600 block mb-3">search_off</span>
                      <p class="text-slate-400 font-medium">No teachers found matching your filters.</p>
                    </td>
                  </tr>
                <?php else : ?>
                  <?php foreach ($filtered as $i => $t) :
                    $initials  = strtoupper(substr($t['name'], 0, 1));
                    $avColor   = $avatar_colors[$i % count($avatar_colors)];
                    $on_leave  = $t['on_leave_today'] > 0;
                    $row_class = $on_leave ? 'bg-amber-50/50 dark:bg-amber-900/5 border-l-4 border-l-amber-400' : 'hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors';
                  ?>
                    <tr class="<?= $row_class ?>">

                      <!-- Teacher Name + Email -->
                      <td class="px-6 py-4">
                        <div class="flex items-center gap-3">
                          <div class="size-10 rounded-full <?= $avColor ?> flex items-center justify-center font-bold text-sm shrink-0"><?= $initials ?></div>
                          <div>
                            <p class="font-semibold text-slate-900 dark:text-white"><?= htmlspecialchars($t['name']) ?></p>
                            <p class="text-xs text-slate-400"><?= htmlspecialchars($t['email']) ?></p>
                          </div>
                        </div>
                      </td>

                      <!-- Employee Code -->
                      <td class="px-6 py-4 hidden sm:table-cell">
                        <span class="font-mono text-xs bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded text-slate-600 dark:text-slate-300">
                          <?= $t['uid'] ? htmlspecialchars($t['uid']) : 'N/A' ?>
                        </span>
                      </td>

                      <!-- Subjects -->
                      <td class="px-6 py-4 hidden lg:table-cell">
                        <?php
                        // Subjects this teacher is on leave for today
                        $leave_subs = $leave_subjects_today[$t['teacher_id']] ?? [];
                        ?>
                        <?php if ($t['subjects']) : ?>
                          <div class="flex flex-wrap gap-1 max-w-xs">
                            <?php foreach (explode(', ', $t['subjects']) as $sub) :
                              $sub = trim($sub);
                              $is_on_leave = in_array($sub, $leave_subs);
                            ?>
                              <?php if ($is_on_leave) : ?>
                                <!-- Amber highlight = teacher on leave for this subject today -->
                                <span class="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full
                                  bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400
                                  border border-amber-300 dark:border-amber-700" title="Teacher on leave today for <?= htmlspecialchars($sub) ?>">
                                  <span class="material-symbols-outlined text-[11px]">event_busy</span>
                                  <?= htmlspecialchars($sub) ?>
                                </span>
                              <?php else : ?>
                                <!-- Normal blue pill -->
                                <span class="text-[11px] font-medium px-2 py-0.5 rounded-full
                                  bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300
                                  border border-blue-100 dark:border-blue-800">
                                  <?= htmlspecialchars($sub) ?>
                                </span>
                              <?php endif; ?>
                            <?php endforeach; ?>
                          </div>
                          <?php if (!empty($leave_subs)) : ?>
                            <p class="text-[10px] text-amber-600 dark:text-amber-400 mt-1.5 flex items-center gap-1">
                              <span class="material-symbols-outlined text-[11px]">info</span>
                              <?= count($leave_subs) ?> subject<?= count($leave_subs) > 1 ? 's' : '' ?> on leave today
                            </p>
                          <?php endif; ?>
                        <?php else : ?>
                          <span class="text-xs text-slate-400 italic">Not assigned</span>
                        <?php endif; ?>
                      </td>

                      <!-- Total Lectures -->
                      <td class="px-6 py-4 text-center">
                        <div class="flex flex-col items-center">
                          <span class="text-xl font-black text-slate-800 dark:text-white"><?= (int)$t['total_lectures'] ?></span>
                          <span class="text-[10px] text-slate-400 font-medium">conducted</span>
                        </div>
                      </td>

                      <!-- Total Leaves -->
                      <td class="px-6 py-4 text-center">
                        <div class="flex flex-col items-center">
                          <span class="text-xl font-black <?= $t['total_leaves'] > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-400' ?>">
                            <?= (int)$t['total_leaves'] ?>
                          </span>
                          <span class="text-[10px] text-slate-400 font-medium">all time</span>
                        </div>
                      </td>

                      <!-- Today's Status -->
                      <td class="px-6 py-4 text-center">
                        <?php if ($on_leave) : ?>
                          <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                            <span class="material-symbols-outlined text-[13px]">event_busy</span>On Leave
                          </span>
                        <?php else : ?>
                          <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>Active
                          </span>
                        <?php endif; ?>
                      </td>

                      <!-- Actions -->
                      <td class="px-6 py-4 text-right">
                        <div class="flex items-center justify-end gap-1">
                          <!-- View Leave History -->
                          <button onclick="openLeaveModal(<?= $t['teacher_id'] ?>, '<?= addslashes(htmlspecialchars($t['name'])) ?>')" title="Leave History" class="p-2 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-900/20 transition-colors">
                            <span class="material-symbols-outlined text-[20px]">event_note</span>
                          </button>
                          <!-- View Attendance Summary -->
                          <button onclick="openStatsModal(<?= $t['teacher_id'] ?>, '<?= addslashes(htmlspecialchars($t['name'])) ?>')" title="Attendance Summary" class="p-2 rounded-lg text-slate-400 hover:text-primary hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors">
                            <span class="material-symbols-outlined text-[20px]">bar_chart</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>

          <!-- Table Footer -->
          <div class="px-6 py-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/40 dark:bg-slate-800/20">
            <p class="text-sm text-slate-500">Total <span class="font-bold text-slate-800 dark:text-white"><?= count($filtered) ?></span> teachers shown</p>
            <div class="flex items-center gap-4 text-xs text-slate-500">
              <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-emerald-500"></span>Active</span>
              <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-amber-500"></span>On Leave</span>
              <span class="flex items-center gap-1.5">
                <span class="inline-flex items-center gap-0.5 text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400 border border-amber-300 dark:border-amber-700">
                  <span class="material-symbols-outlined text-[10px]">event_busy</span> Subject
                </span>
                Leave today
              </span>
            </div>
          </div>
        </div>

      </div><!-- /max-w -->
    </div><!-- /scroll -->
  </main>

  <!-- ═══════════════════════════════════════════════════
     MODAL: Leave History
════════════════════════════════════════════════════ -->
  <div id="leave-modal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl w-full max-w-lg fade-in max-h-[90vh] flex flex-col">
      <div class="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
        <div class="flex items-center gap-3">
          <div class="size-10 rounded-xl bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
            <span class="material-symbols-outlined text-amber-600 dark:text-amber-400">event_note</span>
          </div>
          <div>
            <h3 class="font-bold text-slate-900 dark:text-white">Leave History</h3>
            <p class="text-xs text-slate-500" id="leave-modal-name"></p>
          </div>
        </div>
        <button onclick="closeModal('leave-modal')" class="p-2 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
          <span class="material-symbols-outlined text-[20px]">close</span>
        </button>
      </div>
      <!-- Filter row inside modal -->
      <div class="px-6 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3 shrink-0 bg-slate-50/50 dark:bg-slate-800/30">
        <input type="month" id="leave-month-filter" onchange="loadLeaves()" class="h-9 px-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:border-primary outline-none" />
        <button onclick="document.getElementById('leave-month-filter').value=''; loadLeaves();" class="text-xs text-slate-500 hover:text-primary transition-colors">Clear</button>
        <span id="leave-count-label" class="ml-auto text-xs text-slate-400"></span>
      </div>
      <div id="leave-modal-body" class="overflow-y-auto flex-1 p-6">
        <div class="text-center py-10 text-slate-400">
          <div class="inline-block w-7 h-7 border-3 border-primary/30 border-t-primary rounded-full animate-spin mb-3"></div>
          <p class="text-sm">Loading...</p>
        </div>
      </div>
    </div>
  </div>

  <!-- ═══════════════════════════════════════════════════
     MODAL: Attendance Stats
════════════════════════════════════════════════════ -->
  <div id="stats-modal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl w-full max-w-lg fade-in max-h-[90vh] flex flex-col">
      <div class="flex items-center justify-between px-6 py-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
        <div class="flex items-center gap-3">
          <div class="size-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <span class="material-symbols-outlined text-primary">bar_chart</span>
          </div>
          <div>
            <h3 class="font-bold text-slate-900 dark:text-white">Attendance Summary</h3>
            <p class="text-xs text-slate-500" id="stats-modal-name"></p>
          </div>
        </div>
        <button onclick="closeModal('stats-modal')" class="p-2 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
          <span class="material-symbols-outlined text-[20px]">close</span>
        </button>
      </div>
      <div id="stats-modal-body" class="overflow-y-auto flex-1 p-6">
        <div class="text-center py-10 text-slate-400">
          <div class="inline-block w-7 h-7 border-3 border-primary/30 border-t-primary rounded-full animate-spin mb-3"></div>
          <p class="text-sm">Loading...</p>
        </div>
      </div>
    </div>
  </div>

  <!-- Delete Confirm Modal -->
  <div id="delete-modal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl w-full max-w-sm fade-in p-6 text-center">
      <div class="size-16 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center mx-auto mb-4">
        <span class="material-symbols-outlined text-4xl text-red-600 dark:text-red-400">delete_forever</span>
      </div>
      <h3 class="text-lg font-bold mb-2">Delete Teacher?</h3>
      <p class="text-sm text-slate-500 mb-6">Are you sure you want to delete <strong id="delete-teacher-name"></strong>? This action cannot be undone.</p>
      <div class="flex gap-3">
        <button onclick="closeModal('delete-modal')" class="flex-1 h-11 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-sm hover:bg-slate-50 transition-colors">Cancel</button>
        <button id="delete-confirm-btn" class="flex-1 h-11 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-sm transition-all active:scale-95 flex items-center justify-center gap-2">
          <span class="material-symbols-outlined text-[18px]">delete</span>Delete
        </button>
      </div>
    </div>
  </div>

  <!-- Toast -->
  <div id="toast" class="hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold flex items-center gap-2"></div>

  <script>
    let currentTeacherId = 0;
    let deleteUserId = 0;

    // ── Status filter quick-click from stat cards ─────────────────────────────────
    function setFilter(status) {
      document.getElementById('status-filter').value = status;
      document.querySelector('form').submit();
    }

    // ── Close any modal ───────────────────────────────────────────────────────────
    function closeModal(id) {
      document.getElementById(id).classList.add('hidden');
    }
    document.querySelectorAll('[id$="-modal"]').forEach(m => {
      m.addEventListener('click', e => {
        if (e.target === m) closeModal(m.id);
      });
    });

    // ── Leave History Modal ───────────────────────────────────────────────────────
    function openLeaveModal(teacherId, name) {
      currentTeacherId = teacherId;
      document.getElementById('leave-modal-name').textContent = name;
      document.getElementById('leave-month-filter').value = '';
      document.getElementById('leave-modal').classList.remove('hidden');
      loadLeaves();
    }

    async function loadLeaves() {
      const month = document.getElementById('leave-month-filter').value;
      const body = document.getElementById('leave-modal-body');
      body.innerHTML = '<div class="text-center py-10 text-slate-400"><div class="inline-block w-7 h-7 border-4 border-primary/30 border-t-primary rounded-full animate-spin mb-3 mx-auto"></div><p class="text-sm">Loading...</p></div>';

      try {
        const params = new URLSearchParams({
          teacher_id: currentTeacherId,
          month
        });
        const res = await fetch('../backend/admin/get_teacher_leaves.php?' + params);
        const data = await res.json();

        if (data.error) {
          body.innerHTML = `<p class="text-center text-rose-500 py-8">${data.error}</p>`;
          return;
        }

        document.getElementById('leave-count-label').textContent = `${data.leaves.length} record${data.leaves.length !== 1 ? 's' : ''}`;

        if (!data.leaves.length) {
          body.innerHTML = `<div class="text-center py-10"><span class="material-symbols-outlined text-5xl text-slate-300 dark:text-slate-600 block mb-3">event_available</span><p class="text-slate-400 font-medium">No leave records found.</p></div>`;
          return;
        }

        body.innerHTML = `
    <div class="flex flex-col gap-3">
      <!-- Summary mini cards -->
      <div class="grid grid-cols-3 gap-3 mb-2">
        <div class="bg-slate-50 dark:bg-slate-800 rounded-xl p-3 text-center">
          <p class="text-2xl font-black text-slate-800 dark:text-white">${data.total_all_time}</p>
          <p class="text-xs text-slate-400 mt-0.5">All Time</p>
        </div>
        <div class="bg-amber-50 dark:bg-amber-900/20 rounded-xl p-3 text-center">
          <p class="text-2xl font-black text-amber-600 dark:text-amber-400">${data.total_this_month}</p>
          <p class="text-xs text-amber-500 mt-0.5">This Month</p>
        </div>
        <div class="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-3 text-center">
          <p class="text-2xl font-black text-blue-600 dark:text-blue-400">${data.total_this_year}</p>
          <p class="text-xs text-blue-400 mt-0.5">This Year</p>
        </div>
      </div>
      <!-- Leave list -->
      ${data.leaves.map(l => {
        const d   = new Date(l.leave_date + 'T00:00:00');
        const day = d.toLocaleDateString('en-IN', { weekday:'short' });
        const dt  = d.toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' });
        const isToday = l.leave_date === '<?= $today ?>';
        return ` <div class = "flex items-start gap-3 p-3.5 rounded-xl border ${isToday ? 'border-amber-200 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-900/10' : 'border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30'}">
          <div class = "size-10 rounded-lg ${isToday ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-600' : 'bg-slate-100 dark:bg-slate-700 text-slate-500'} flex flex-col items-center justify-center text-center shrink-0">
          <span class = "text-[10px] font-semibold" > ${day}</span> 
          <span class = "text-sm font-black" > ${d.getDate()} </span>  
          </div>  
          <div class = "flex-1 min-w-0" >
          <div class = "flex items-center justify-between gap-2" >
          <p class = "text-sm font-semibold text-slate-800 dark:text-white" > ${dt}
        ${isToday ? ' <span class="text-amber-600 text-xs font-bold">(Today)</span>' : ''} </p>  
        <span class = "text-xs text-slate-400" > ${l.subject_name || 'N/A'} </span>  
        </div>  
        <p class = "text-xs text-slate-500 mt-0.5" > ${l.semester_no ? 'Sem ' + l.semester_no + ' Div ' + l.division_name : ''} </p>
        ${l.reason ? `<p class="text-xs text-slate-400 italic mt-0.5 truncate">${esc(l.reason)}</p> ` : ''}
        </div> 
        </div>`;
      }).join('')
    } </div>`;
    }
    catch (e) {
      body.innerHTML = `<p class="text-center text-rose-500 py-8">Error loading data.</p>`;
      console.error(e);
    }
    }

    // ── Attendance Stats Modal ────────────────────────────────────────────────────
    async function openStatsModal(teacherId, name) {
      document.getElementById('stats-modal-name').textContent = name;
      document.getElementById('stats-modal-body').innerHTML = '<div class="text-center py-10 text-slate-400"><div class="inline-block w-7 h-7 border-4 border-primary/30 border-t-primary rounded-full animate-spin mb-3 mx-auto"></div><p class="text-sm">Loading...</p></div>';
      document.getElementById('stats-modal').classList.remove('hidden');

      try {
        const res = await fetch('../backend/admin/get_teacher_stats.php?teacher_id=' + teacherId);
        const data = await res.json();

        if (data.error) {
          document.getElementById('stats-modal-body').innerHTML = `<p class="text-center text-rose-500 py-8">${data.error}</p>`;
          return;
        }

        const body = document.getElementById('stats-modal-body');
        body.innerHTML = `
    <div class="flex flex-col gap-5">
      <!-- Overall numbers -->
      <div class="grid grid-cols-3 gap-3">
        <div class="bg-slate-50 dark:bg-slate-800 rounded-xl p-4 text-center">
          <p class="text-3xl font-black text-slate-800 dark:text-white">${data.total_sessions}</p>
          <p class="text-xs text-slate-400 mt-1">Total Sessions</p>
        </div>
        <div class="bg-emerald-50 dark:bg-emerald-900/20 rounded-xl p-4 text-center">
          <p class="text-3xl font-black text-emerald-600 dark:text-emerald-400">${data.total_present}</p>
          <p class="text-xs text-emerald-500 mt-1">Present Entries</p>
        </div>
        <div class="bg-rose-50 dark:bg-rose-900/20 rounded-xl p-4 text-center">
          <p class="text-3xl font-black text-rose-500 dark:text-rose-400">${data.total_absent}</p>
          <p class="text-xs text-rose-400 mt-1">Absent Entries</p>
        </div>
      </div>

      <!-- Subject-wise breakdown -->
      ${data.subjects.length ? `
      <div>
        <p class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Subject-wise Sessions</p>
        <div class="flex flex-col gap-2.5">
          ${data.subjects.map(s => {
            const barColor = 'bg-primary';
            return `
            <div class="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700">
              <div class="flex items-center justify-between mb-2">
                <span class="text-sm font-semibold text-slate-800 dark:text-white">${esc(s.subject_name)}</span>
                <span class="text-xs text-slate-500">Sem ${s.semester_no} Div ${s.division_name}</span>
              </div>
              <div class="flex items-center gap-2">
                <div class="flex-1 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                  <div class="${barColor} h-full rounded-full" style="width:${s.sessions > 0 ? Math.min(100,Math.round(s.sessions/Math.max(...data.subjects.map(x=>x.sessions))*100)) : 0}%"></div>
                </div>
                <span class="text-xs font-bold text-slate-600 dark:text-slate-300 w-14 text-right">${s.sessions} sessions</span>
              </div>
            </div>`;
          }).join('')}
        </div>
      </div>` : '<p class="text-center text-slate-400 py-4 text-sm">No attendance data recorded yet.</p>'}
    </div>`;
      } catch (e) {
        document.getElementById('stats-modal-body').innerHTML = '<p class="text-center text-rose-500 py-8">Error loading data.</p>';
        console.error(e);
      }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────────
    function esc(s) {
      return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function toast(msg, type) {
      const t = document.getElementById('toast');
      t.innerHTML = `<span class="material-symbols-outlined text-[18px]">${type==='success'?'check_circle':'error'}</span>${msg}`;
      t.className = `fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold flex items-center gap-2 ${type==='success'?'bg-green-600':'bg-red-500'}`;
      t.classList.remove('hidden');
      setTimeout(() => t.classList.add('hidden'), 3500);
    }
    // Live search (client side for instant feel)
    document.getElementById('search-input').addEventListener('input', function() {
      const q = this.value.toLowerCase();
      document.querySelectorAll('tbody tr').forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(q) ? '' : 'none';
      });
    });
  </script>
</body>

</html>