<?php
include("../backend/config/connection.php");
include("../backend/auth/auth.php");

if ($_SESSION['role'] !== 'teacher') {
  header("Location: login.php?error=unauthorized");
  exit();
}

$user_id = $_SESSION['user_id'];
$uq = $conn->prepare("SELECT name FROM users WHERE id = ?");
$uq->bind_param("i", $user_id);
$uq->execute();
$teacher_user = $uq->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html class="light" lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>EduSmart - Take Attendance</title>
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
  <script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            primary: "#2b8cee",
            "primary-dark": "#1a6ec0",
            "background-light": "#f6f7f8",
            "background-dark": "#101922"
          },
          fontFamily: {
            display: ["Lexend", "sans-serif"]
          },
          borderRadius: {
            DEFAULT: "0.25rem",
            lg: "0.5rem",
            xl: "0.75rem",
            "2xl": "1rem",
            full: "9999px"
          },
        },
      },
    };
  </script>
  <style>
    ::-webkit-scrollbar {
      width: 6px;
    }

    ::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px;
    }

    .material-symbols-outlined {
      font-variation-settings: "FILL" 0, "wght" 400, "GRAD" 0, "opsz" 24;
    }

    body {
      font-family: "Lexend", sans-serif;
    }
  </style>
</head>

<body class="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 min-h-screen flex flex-col">

  <!-- Header -->
  <header class="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-6 py-3 sticky top-0 z-50 shadow-sm">
    <div class="flex items-center gap-4">
      <div class="bg-primary/10 p-2 rounded-xl">
        <span class="material-symbols-outlined text-primary text-2xl">school</span>
      </div>
      <h2 class="text-xl font-bold tracking-tight">EduSmart</h2>
    </div>
    <nav class="hidden md:flex items-center gap-6 text-sm font-medium">
      <a class="text-slate-500 hover:text-primary transition-colors" href="teacher_dashboard.php">Dashboard</a>
      <a class="text-primary font-semibold" href="#">Attendance</a>
      <a class="text-slate-500 hover:text-primary transition-colors" href="teacher_reports.php">Reports</a>
    </nav>
    <div class="flex items-center gap-3">
      <div class="size-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
        <?= strtoupper(substr($teacher_user['name'], 0, 1)) ?>
      </div>
      <span class="hidden md:block text-sm font-medium"><?= htmlspecialchars($teacher_user['name']) ?></span>
    </div>
  </header>

  <!-- Main -->
  <main class="flex-1 px-4 sm:px-8 py-8 w-full max-w-[1200px] mx-auto">

    <!-- Page Header -->
    <div class="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
      <div>
        <h1 class="text-3xl font-black tracking-tight mb-1">Take Attendance</h1>
        <p class="text-slate-500 dark:text-slate-400">Select your class and mark attendance.</p>
      </div>
      <div class="flex items-center gap-2 bg-white dark:bg-slate-800 px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm">
        <span class="material-symbols-outlined text-primary text-[20px]">calendar_today</span>
        <span class="font-semibold text-slate-700 dark:text-slate-200" id="display-date"></span>
      </div>
    </div>

    <!-- Controls + Stats -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
      <div class="lg:col-span-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
        <h3 class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-4">Select Class</h3>
        <div class="flex flex-col sm:flex-row gap-4 items-end">
          <label class="flex flex-col flex-1 gap-1.5 w-full">
            <span class="text-sm font-semibold text-slate-700 dark:text-slate-300">Subject &amp; Division</span>
            <div class="relative">
              <select id="class-select" class="w-full appearance-none rounded-lg border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-12 px-4 pr-10 focus:border-primary focus:ring-primary text-sm">
                <option value="">-- Loading classes... --</option>
              </select>
            </div>
          </label>
          <label class="flex flex-col w-full sm:w-44 gap-1.5">
            <span class="text-sm font-semibold text-slate-700 dark:text-slate-300">Date</span>
            <input type="date" id="attendance-date" class="w-full rounded-lg border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-12 px-4 focus:border-primary focus:ring-primary text-sm" />
          </label>
          <button onclick="loadStudents()" class="h-12 px-6 rounded-lg bg-primary hover:bg-primary-dark text-white font-semibold text-sm transition-all flex items-center gap-2 shrink-0">
            <span class="material-symbols-outlined text-[18px]">search</span> Load
          </button>
        </div>

        <!-- Already submitted warning -->
        <div id="already-submitted-msg" class="hidden mt-4 p-3 rounded-lg bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 text-amber-700 dark:text-amber-400 text-sm flex items-center gap-2">
          <span class="material-symbols-outlined text-[18px]">warning</span>
          Attendance already submitted for this class on the selected date.
        </div>
      </div>

      <!-- Stats card -->
      <div class="bg-primary text-white rounded-xl p-6 shadow-lg shadow-primary/20 flex flex-col justify-between relative overflow-hidden">
        <div class="absolute -right-6 -top-6 size-32 bg-white/10 rounded-full blur-2xl"></div>
        <div class="relative z-10 flex justify-between items-start mb-4">
          <h3 class="font-semibold text-white/90">Class Summary</h3>
          <span class="material-symbols-outlined bg-white/20 p-1.5 rounded-lg">bar_chart</span>
        </div>
        <div class="relative z-10 flex items-end gap-2">
          <span class="text-4xl font-bold" id="stat-total">--</span>
          <span class="text-sm mb-1.5 text-blue-100">Total Students</span>
        </div>
        <div class="relative z-10 grid grid-cols-2 gap-4 mt-6 pt-4 border-t border-white/20">
          <div>
            <div class="text-xs text-blue-100 uppercase tracking-wider mb-1">Present</div>
            <div class="text-2xl font-bold" id="stat-present">--</div>
          </div>
          <div>
            <div class="text-xs text-blue-100 uppercase tracking-wider mb-1">Absent</div>
            <div class="text-2xl font-bold text-red-200" id="stat-absent">--</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Student List -->
    <div id="student-list-container" class="hidden bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
      <div class="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap justify-between items-center gap-3 bg-slate-50/50 dark:bg-slate-800/50">
        <span class="text-sm text-slate-500">Showing <span id="student-count-label" class="font-bold text-slate-900 dark:text-white">0</span> students</span>
        <div class="flex items-center gap-2">
          <button onclick="markAll(true)" class="text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20 px-3 py-1.5 rounded-lg text-sm font-semibold border border-green-200 dark:border-green-800 flex items-center gap-1.5 transition-colors">
            <span class="material-symbols-outlined text-[16px]">check_circle</span> All Present
          </button>
          <button onclick="markAll(false)" class="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 px-3 py-1.5 rounded-lg text-sm font-semibold border border-red-200 dark:border-red-800 flex items-center gap-1.5 transition-colors">
            <span class="material-symbols-outlined text-[16px]">cancel</span> All Absent
          </button>
        </div>
      </div>
      <div class="grid grid-cols-12 gap-4 px-6 py-3 bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
        <div class="col-span-2 md:col-span-1">Roll</div>
        <div class="col-span-6 md:col-span-7">Student Name</div>
        <div class="col-span-4 text-center">Status</div>
      </div>
      <div id="student-rows" class="divide-y divide-slate-100 dark:divide-slate-800 max-h-[500px] overflow-y-auto"></div>
    </div>

    <!-- ── NO LECTURE STATE ── -->
    <div id="no-lecture-state" class="hidden">
      <div class="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-2xl p-12 text-center">
        <span class="material-symbols-outlined text-6xl text-amber-400 block mb-4">event_busy</span>
        <h3 class="text-xl font-black text-amber-700 dark:text-amber-400 mb-2" id="no-lecture-title">No Lecture Scheduled</h3>
        <p class="text-amber-600 dark:text-amber-500 text-sm max-w-sm mx-auto" id="no-lecture-msg"></p>
        <p class="text-amber-500 dark:text-amber-600 text-xs mt-3">Please select a date when this subject is scheduled.</p>
      </div>
    </div>

    <!-- ── ON LEAVE STATE ── -->
    <div id="on-leave-state" class="hidden">
      <div class="bg-rose-50 dark:bg-rose-900/20 border border-rose-200 dark:border-rose-800 rounded-2xl p-12 text-center">
        <span class="material-symbols-outlined text-6xl text-rose-400 block mb-4">person_off</span>
        <h3 class="text-xl font-black text-rose-700 dark:text-rose-400 mb-2">You Are on Leave</h3>
        <p class="text-rose-600 dark:text-rose-500 text-sm max-w-sm mx-auto" id="on-leave-msg"></p>
        <p class="text-rose-400 dark:text-rose-600 text-xs mt-3">Attendance cannot be taken. Cancel your leave from the Dashboard to proceed.</p>
        <a href="teacher_dashboard.php" class="inline-flex items-center gap-2 mt-5 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-sm transition-all">
          <span class="material-symbols-outlined text-[18px]">dashboard</span>Go to Dashboard
        </a>
      </div>
    </div>

    <!-- Empty / initial state -->
    <div id="empty-state" class="text-center py-20 text-slate-400">
      <span class="material-symbols-outlined text-6xl mb-3 block">groups</span>
      <p class="font-medium">Select a class and click Load to begin</p>
    </div>

    <!-- Loading state -->
    <div id="loading-state" class="hidden text-center py-20">
      <div class="inline-block w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin mb-4"></div>
      <p class="font-medium text-slate-400">Loading students...</p>
    </div>
  </main>

  <!-- Submit Bar -->
  <div id="submit-bar" class="hidden sticky bottom-0 z-40 w-full bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 p-4 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)]">
    <div class="max-w-[1200px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
      <div class="text-sm text-slate-500">Submit attendance for <span id="submit-label" class="font-bold text-slate-900 dark:text-white"></span></div>
      <div class="flex items-center gap-3 w-full sm:w-auto">
        <button onclick="cancelAttendance()" class="flex-1 sm:flex-none px-6 py-2.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-medium hover:bg-slate-50 transition-colors">Cancel</button>
        <button id="submit-btn" onclick="submitAttendance()" class="flex-1 sm:flex-none px-8 py-2.5 rounded-lg bg-primary hover:bg-primary-dark text-white font-bold shadow-md shadow-blue-500/20 transition-all active:scale-95 flex items-center justify-center gap-2">
          <span class="material-symbols-outlined text-[20px]">send</span> Submit Attendance
        </button>
      </div>
    </div>
  </div>

  <!-- Toast -->
  <div id="toast" class="hidden fixed bottom-24 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold"></div>

  <script>
    let currentClasses = [],
      currentStudents = [],
      selectedClass = null;

    const today = new Date();
    document.getElementById('attendance-date').value = today.toISOString().split('T')[0];
    document.getElementById('display-date').textContent = today.toLocaleDateString('en-IN', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    async function loadClasses() {
      try {
        const res = await fetch('../backend/attendance/get_teacher_classes.php');
        const data = await res.json();
        currentClasses = data;
        const sel = document.getElementById('class-select');
        sel.innerHTML = data.length ?
          '<option value="">-- Select a class --</option>' :
          '<option value="">No classes assigned</option>';
        data.forEach((c, i) => {
          const o = document.createElement('option');
          o.value = i;
          o.textContent = `${c.subject_name} — Sem ${c.semester_no} | Div ${c.division_name}`;
          sel.appendChild(o);
        });
      } catch (e) {
        showToast('Failed to load classes', 'error');
      }
    }

    async function loadStudents() {
      const idx = document.getElementById('class-select').value;
      if (idx === '') {
        showToast('Please select a class first', 'error');
        return;
      }
      selectedClass = currentClasses[+idx];
      const date = document.getElementById('attendance-date').value;
      if (!date) {
        showToast('Please select a date', 'error');
        return;
      }

      // Hide everything, show loading
      hide('empty-state');
      hide('student-list-container');
      hide('no-lecture-state');
      hide('on-leave-state');
      hide('submit-bar');
      hide('already-submitted-msg');
      show('loading-state');

      try {
        const p = new URLSearchParams({
          semester_id: selectedClass.semester_id,
          division_id: selectedClass.division_id,
          subject_id: selectedClass.subject_id,
          date
        });
        const res = await fetch('../backend/attendance/get_students_for_attendance.php?' + p);
        const txt = await res.text();
        let data;
        try {
          data = JSON.parse(txt);
        } catch (e) {
          console.error('Raw:', txt);
          showToast('Server error. Check console.', 'error');
          hide('loading-state');
          show('empty-state');
          return;
        }

        hide('loading-state');

        if (data.error) {
          showToast(data.error, 'error');
          show('empty-state');
          return;
        }

        // ── No lecture on this day ────────────────────────────────────────────
        if (data.no_lecture) {
          document.getElementById('no-lecture-title').textContent =
            `No Lecture on ${data.day}`;
          document.getElementById('no-lecture-msg').textContent =
            `${selectedClass.subject_name} is not scheduled on ${data.day}s ` +
            `for Sem ${selectedClass.semester_no} Div ${selectedClass.division_name}. ` +
            `Attendance cannot be taken for this date.`;
          show('no-lecture-state');
          return;
        }

        // ── Teacher on leave ──────────────────────────────────────────────────
        if (data.on_leave) {
          const reason = data.reason ? `Reason: ${data.reason}` : 'You have applied for leave for this class on this date.';
          document.getElementById('on-leave-msg').textContent = reason;
          show('on-leave-state');
          return;
        }

        // ── Has lecture — load students ───────────────────────────────────────
        currentStudents = data.students.map(s => ({
          ...s,
          present: true
        }));
        renderStudents();
        updateStats();

        if (data.already_submitted) {
          show('already-submitted-msg');
        } else if (currentStudents.length > 0) {
          document.getElementById('submit-label').textContent =
            `${selectedClass.subject_name} — Div ${selectedClass.division_name} (${date})`;
          show('submit-bar');
        }

      } catch (e) {
        hide('loading-state');
        show('empty-state');
        showToast('Failed to load students: ' + e.message, 'error');
        console.error(e);
      }
    }

    function renderStudents() {
      const container = document.getElementById('student-rows');
      if (!currentStudents.length) {
        container.innerHTML = '<div class="px-6 py-12 text-center text-slate-400"><span class="material-symbols-outlined text-4xl block mb-2">person_off</span>No students found.</div>';
        show('student-list-container');
        return;
      }
      const colors = ['bg-blue-100 text-blue-600', 'bg-purple-100 text-purple-600', 'bg-green-100 text-green-600', 'bg-amber-100 text-amber-600', 'bg-pink-100 text-pink-600'];
      container.innerHTML = currentStudents.map((s, i) => {
        const init = s.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
        const col = colors[i % colors.length];
        return `<div class="grid grid-cols-12 gap-4 px-6 py-4 items-center transition-colors ${s.present ? 'hover:bg-slate-50 dark:hover:bg-slate-800/50' : 'bg-red-50/50 border-l-4 border-l-red-500'}" id="row-${i}">
          <div class="col-span-2 md:col-span-1 font-mono text-sm text-slate-500">${esc(s.roll_no)}</div>
          <div class="col-span-6 md:col-span-7 flex items-center gap-3">
            <div class="size-9 rounded-full ${col} flex items-center justify-center font-bold text-xs shrink-0">${init}</div>
            <p class="text-sm font-semibold">${esc(s.name)}</p>
          </div>
          <div class="col-span-4 flex justify-center">
            <label class="inline-flex cursor-pointer items-center gap-2 select-none">
              <span class="text-xs font-medium ${s.present ? 'text-slate-400' : 'text-red-600 font-bold'}" id="al-${i}">Absent</span>
              <div class="relative">
                <input type="checkbox" class="peer sr-only" ${s.present ? 'checked' : ''} onchange="toggle(${i},this.checked)"/>
                <div class="h-7 w-12 rounded-full ${s.present ? 'bg-green-500' : 'bg-red-200'} after:absolute after:start-[3px] after:top-[3px] after:h-[22px] after:w-[22px] after:rounded-full after:bg-white after:transition-all after:content-[''] peer-checked:bg-green-500 peer-checked:after:translate-x-full peer-focus:ring-2 peer-focus:ring-green-300 transition-colors" id="tt-${i}"></div>
              </div>
              <span class="text-xs font-bold text-green-600 ${s.present ? '' : 'opacity-50'}" id="pl-${i}">Present</span>
            </label>
          </div>
        </div>`;
      }).join('');
      show('student-list-container');
      document.getElementById('student-count-label').textContent = currentStudents.length;
    }

    function toggle(i, present) {
      currentStudents[i].present = present;
      const row = document.getElementById(`row-${i}`);
      const tt = document.getElementById(`tt-${i}`);
      const al = document.getElementById(`al-${i}`);
      const pl = document.getElementById(`pl-${i}`);
      if (present) {
        row.classList.remove('bg-red-50/50', 'border-l-4', 'border-l-red-500');
        row.classList.add('hover:bg-slate-50');
        tt.className = tt.className.replace('bg-red-200', 'bg-green-500');
        al.className = 'text-xs font-medium text-slate-400';
        pl.classList.remove('opacity-50');
      } else {
        row.classList.add('bg-red-50/50', 'border-l-4', 'border-l-red-500');
        row.classList.remove('hover:bg-slate-50');
        tt.className = tt.className.replace('bg-green-500', 'bg-red-200');
        al.className = 'text-xs font-bold text-red-600';
        pl.classList.add('opacity-50');
      }
      updateStats();
    }

    function markAll(present) {
      currentStudents.forEach((_, i) => {
        currentStudents[i].present = present;
        const cb = document.querySelector(`#row-${i} input`);
        if (cb) {
          cb.checked = present;
          toggle(i, present);
        }
      });
    }

    function updateStats() {
      const total = currentStudents.length;
      const present = currentStudents.filter(s => s.present).length;
      document.getElementById('stat-total').textContent = total;
      document.getElementById('stat-present').textContent = present;
      document.getElementById('stat-absent').textContent = total - present;
    }

    async function submitAttendance() {
      if (!selectedClass || !currentStudents.length) return;
      const btn = document.getElementById('submit-btn');
      btn.disabled = true;
      btn.innerHTML = '<div class="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>';
      try {
        const res = await fetch('../backend/attendance/save_attendance.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            semester_id: selectedClass.semester_id,
            division_id: selectedClass.division_id,
            subject_id: selectedClass.subject_id,
            date: document.getElementById('attendance-date').value,
            records: currentStudents.map(s => ({
              student_id: s.student_id,
              status: s.present ? 'present' : 'absent'
            }))
          })
        });
        const data = await res.json();
        if (data.success) {
          showToast('Attendance submitted!', 'success');
          hide('submit-bar');
          show('already-submitted-msg');
        } else {
          showToast(data.message || 'Failed', 'error');
        }
      } catch (e) {
        showToast('Network error: ' + e.message, 'error');
      }
      btn.disabled = false;
      btn.innerHTML = '<span class="material-symbols-outlined text-[20px]">send</span> Submit Attendance';
    }

    function cancelAttendance() {
      currentStudents = [];
      selectedClass = null;
      hide('student-list-container');
      hide('submit-bar');
      hide('no-lecture-state');
      hide('on-leave-state');
      show('empty-state');
      document.getElementById('class-select').value = '';
      ['stat-total', 'stat-present', 'stat-absent'].forEach(id => document.getElementById(id).textContent = '--');
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    function show(id) {
      document.getElementById(id)?.classList.remove('hidden');
    }

    function hide(id) {
      document.getElementById(id)?.classList.add('hidden');
    }

    function esc(s) {
      return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function showToast(msg, type) {
      const t = document.getElementById('toast');
      t.textContent = msg;
      t.className = `fixed bottom-24 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold ${type === 'success' ? 'bg-green-600' : 'bg-red-500'}`;
      t.classList.remove('hidden');
      setTimeout(() => t.classList.add('hidden'), 3000);
    }

    loadClasses();
  </script>
</body>

</html>