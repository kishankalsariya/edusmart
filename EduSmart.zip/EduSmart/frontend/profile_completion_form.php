<?php
include("../backend/auth/auth.php");

if ($_SESSION['role'] !== 'student') {
    header("Location: login.php?error=unauthorized");
    exit();
}

?>

<!DOCTYPE html>
<html class="light" lang="en">

<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>EduSmart - Complete Your Profile</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700;800;900&amp;family=Noto+Sans:wght@400;500;700&amp;display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght@100..700,0..1&amp;display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet" />
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#2b8cee",
                        "background-light": "#f6f7f8",
                        "background-dark": "#101922",
                    },
                    fontFamily: {
                        "display": ["Lexend", "Noto Sans", "sans-serif"]
                    },
                    borderRadius: {
                        "DEFAULT": "0.25rem",
                        "lg": "0.5rem",
                        "xl": "0.75rem",
                        "full": "9999px"
                    },
                },
            },
        }
    </script>
    <style>
        body {
            font-family: 'Lexend', sans-serif;
        }

        .form-input:focus {
            border-color: #2b8cee !important;
            /* ring: 0 !important; */
        }

        /* Error state styles */
        .border-red-500 {
            border-color: #ef4444 !important;
        }

        .focus\:ring-red-500\/20:focus {
            --tw-ring-color: rgb(239 68 68 / 0.2) !important;
        }

        /* Animation for error summary */
        @keyframes pulse {

            0%,
            100% {
                opacity: 1;
            }

            50% {
                opacity: 0.7;
            }
        }

        .animate-pulse {
            animation: pulse 1s cubic-bezier(0.4, 0, 0.6, 1) 2;
        }
    </style>
</head>

<body class="bg-background-light dark:bg-background-dark text-[#0d141b] transition-colors duration-300">
    <div class="relative flex min-h-screen flex-col overflow-x-hidden">
        <div class="layout-container flex h-full grow flex-col">
            <!-- TopNavBar -->
            <header class="flex items-center justify-between border-b border-solid border-slate-200 dark:border-slate-800 bg-white dark:bg-background-dark px-10 py-3 sticky top-0 z-50">
                <div class="flex items-center gap-4 text-[#0d141b] dark:text-white">
                    <div class="flex items-center justify-center size-10 bg-primary text-white rounded-lg">
                        <span class="material-symbols-outlined">school</span>
                    </div>
                    <h2 class="text-lg font-bold leading-tight tracking-[-0.015em] font-display">EduSmart</h2>
                </div>
                <div class="flex flex-1 justify-end gap-8 items-center">
                    <nav class="hidden md:flex items-center gap-9">
                        <a class="text-sm font-medium leading-normal dark:text-slate-300 hover:text-primary" href="student_dashboard.php">Dashboard</a>
                    </nav>
            </header>
            <main class="flex flex-1 justify-center py-10 px-4">
                <div class="layout-content-container flex flex-col max-w-[960px] flex-1 gap-6">
                    <!-- PageHeading -->
                    <div class="flex flex-wrap justify-between gap-3 p-4 bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800">
                        <div class="flex min-w-72 flex-col gap-2">
                            <p class="text-[#0d141b] dark:text-white text-3xl font-black leading-tight tracking-[-0.033em] font-display">Complete Your Profile</p>
                            <p class="text-[#4c739a] dark:text-slate-400 text-base font-normal leading-normal">Please fill in your details to finalize your enrollment in the system.</p>
                        </div>
                    </div>

                    <form action="../backend/users/student_save.php" method="post" id="myForm">

                        <!-- Section: Personal Information -->
                        <section class="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden">
                            <div class="border-b border-slate-100 dark:border-slate-800 px-6 py-4 flex items-center gap-3">
                                <span class="material-symbols-outlined text-primary">person</span>
                                <h2 class="text-[#0d141b] dark:text-white text-xl font-bold font-display">Personal Information</h2>
                            </div>
                            <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
                                <!-- First Name -->
                                <div class="flex flex-col gap-2">
                                    <label class="text-[#0d141b] dark:text-slate-200 text-sm font-semibold">First Name <span class="text-red-500">*</span></label>
                                    <input class="form-input w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white h-12 px-4 focus:ring-2 focus:ring-primary/20 outline-none transition-all" name="first_name" type="text" value="" />
                                </div>
                                <!-- Last Name -->
                                <div class="flex flex-col gap-2">
                                    <label class="text-[#0d141b] dark:text-slate-200 text-sm font-semibold">Last Name <span class="text-red-500">*</span></label>
                                    <input class="form-input w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white h-12 px-4 focus:ring-2 focus:ring-primary/20 outline-none transition-all" name="last_name" type="text" value="" />
                                </div>
                                <!-- Roll Number -->
                                <div class="flex flex-col gap-2">
                                    <label class="text-[#0d141b] dark:text-slate-200 text-sm font-semibold">Roll Number <span class="text-red-500">*</span></label>
                                    <input class="form-input w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white h-12 px-4 focus:ring-2 focus:ring-primary/20 outline-none transition-all" name="roll_no" type="text" value="" />
                                    <p class="text-xs text-green-600 font-medium flex items-center gap-1"><span class="material-symbols-outlined text-[14px]">check_circle</span> Verified by registrar</p>
                                </div>
                                <!-- Gender -->
                                <div class="flex flex-col gap-2">
                                    <label class="text-[#0d141b] dark:text-slate-200 text-sm font-semibold">Gender <span class="text-red-500">*</span></label>
                                    <select class="form-input w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white h-12 px-4 focus:ring-2 focus:ring-primary/20 outline-none transition-all" name="gender">
                                        <option disabled="" selected="" value="">Select Gender</option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                    </select>
                                </div>
                                <!-- DOB -->
                                <div class="flex flex-col gap-2">
                                    <label class="text-[#0d141b] dark:text-slate-200 text-sm font-semibold">Date of Birth <span class="text-red-500">*</span></label>
                                    <input class="form-input w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white h-12 px-4 focus:ring-2 focus:ring-primary/20 outline-none transition-all" type="date" name="dob" />
                                </div>
                                <!-- Phone Number -->
                                <div class="flex flex-col gap-2">
                                    <label class="text-[#0d141b] dark:text-slate-200 text-sm font-semibold">Phone Number <span class="text-red-500">*</span></label>
                                    <input class="form-input w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white h-12 px-4 focus:ring-2 focus:ring-primary/20 outline-none transition-all" type="tel" name="phone" />
                                </div>
                                <!-- Address -->
                                <div class="flex flex-col gap-2 md:col-span-2">
                                    <label class="text-[#0d141b] dark:text-slate-200 text-sm font-semibold">Home Address <span class="text-red-500">*</span></label>
                                    <textarea class="form-input w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white p-4 focus:ring-2 focus:ring-primary/20 outline-none transition-all resize-none" placeholder="Enter your full residential address" name="address" rows="3"></textarea>
                                    <div class="flex justify-between">
                                        <p class="text-xs text-red-500 font-medium">Please provide a valid address for official correspondence.</p>
                                        <p class="text-xs text-slate-400">0 / 200 characters</p>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <!-- Section: Academic Information -->
                        <section class="bg-white dark:bg-slate-900 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800 overflow-hidden">
                            <div class="border-b border-slate-100 dark:border-slate-800 px-6 py-4 flex items-center gap-3">
                                <span class="material-symbols-outlined text-primary">history_edu</span>
                                <h2 class="text-[#0d141b] dark:text-white text-xl font-bold font-display">Academic Information</h2>
                            </div>
                            <div class="p-6 grid grid-cols-1 md:grid-cols-3 gap-6">
                                <!-- Course -->
                                <div class="flex flex-col gap-2">
                                    <label class="text-[#0d141b] dark:text-slate-200 text-sm font-semibold">Course</label>
                                    <div class="relative">
                                        <input class="form-input w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 h-12 px-4 cursor-not-allowed italic" disabled="" type="text" value="BSC IT" />
                                        <span class="material-symbols-outlined absolute right-3 top-3 text-slate-400 text-sm">lock</span>
                                    </div>
                                </div>
                                <!-- Semester -->
                                <div class="flex flex-col gap-2">
                                    <label class="text-[#0d141b] dark:text-slate-200 text-sm font-semibold">Current Semester <span class="text-red-500">*</span></label>
                                    <select class="form-input w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white h-12 px-4 focus:ring-2 focus:ring-primary/20 outline-none transition-all" name="semester_id">
                                        <option disabled="" selected="" value="">Select Semester</option>
                                        <option value="1">Semester 1</option>
                                        <option value="2">Semester 2</option>
                                        <option value="3">Semester 3</option>
                                        <option value="4">Semester 4</option>
                                        <option value="5">Semester 5</option>
                                        <option value="6">Semester 6</option>
                                    </select>
                                </div>
                                <!-- Division -->
                                <div class="flex flex-col gap-2">
                                    <label class="text-[#0d141b] dark:text-slate-200 text-sm font-semibold">Division / Section <span class="text-red-500">*</span></label>
                                    <select class="form-input w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 dark:text-white h-12 px-4 focus:ring-2 focus:ring-primary/20 outline-none transition-all" name="division_id">
                                        <option disabled="" selected="" value="">Select Division</option>
                                        <option value="1">Division A</option>
                                        <option value="2">Division B</option>
                                        <option value="3">Division C</option>
                                        <option value="4">Division D</option>
                                    </select>
                                </div>
                            </div>
                        </section>

                        <!-- Footer Actions -->
                        <div class="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 mt-4 mb-10">
                            <button class="text-slate-500 dark:text-slate-400 hover:text-red-500 font-medium transition-colors text-sm flex items-center gap-2" type="reset">
                                <span class="material-symbols-outlined text-lg">delete</span>
                                Discard Changes
                            </button>
                            <div class="flex items-center gap-4 w-full sm:w-auto">
                                <button class="w-full sm:w-40 h-12 rounded-lg bg-primary hover:bg-primary/90 text-white font-bold text-sm tracking-wide shadow-lg shadow-primary/20 transition-all flex items-center justify-center gap-2 group" type="submit">
                                    <span class="material-symbols-outlined text-xl group-hover:scale-110 transition-transform">save</span>
                                    Save Profile
                                </button>
                            </div>
                        </div>

                    </form>
                </div>
            </main>
            <footer class="mt-auto py-8 px-10 border-t border-slate-200 dark:border-slate-800 text-center">
                <p class="text-slate-400 text-sm">&copy; <?php echo date('Y'); ?> EduSmart LMS. All rights reserved.</p>
            </footer>
        </div>
    </div>



    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('myForm');
            const firstNameInput = document.querySelector('input[name="first_name"]');
            const lastNameInput = document.querySelector('input[name="last_name"]');
            const rollNoInput = document.querySelector('input[name="roll_no"]');
            const genderSelect = document.querySelector('select[name="gender"]');
            const dobInput = document.querySelector('input[name="dob"]');
            const phoneInput = document.querySelector('input[name="phone"]');
            const addressTextarea = document.querySelector('textarea[name="address"]');
            const semesterSelect = document.querySelector('select[name="semester_id"]');
            const divisionSelect = document.querySelector('select[name="division_id"]');

            // Character counter for address
            const addressCounter = document.querySelector('.flex.justify-between p:last-child');

            // Real-time address character counter
            if (addressTextarea && addressCounter) {
                addressTextarea.addEventListener('input', function() {
                    const length = this.value.length;
                    addressCounter.textContent = `${length} / 200 characters`;
                    if (length > 200) {
                        addressCounter.classList.add('text-red-500');
                        addressCounter.classList.remove('text-slate-400');
                    } else {
                        addressCounter.classList.remove('text-red-500');
                        addressCounter.classList.add('text-slate-400');
                    }
                });
            }

            // Helper function to show error
            function showError(input, message) {
                // Remove existing error
                removeError(input);

                // Add error class to input
                input.classList.add('border-red-500', 'focus:ring-red-500/20');
                input.classList.remove('border-slate-200', 'dark:border-slate-700');

                // Create error message element
                const errorDiv = document.createElement('div');
                errorDiv.className = 'text-red-500 text-xs mt-1 flex items-center gap-1';
                errorDiv.innerHTML = `<span class="material-symbols-outlined text-[14px]">error</span> ${message}`;

                // Insert after the input or its container
                const parent = input.closest('.flex.flex-col');
                if (parent) {
                    parent.appendChild(errorDiv);
                } else {
                    input.parentNode.insertBefore(errorDiv, input.nextSibling);
                }
            }

            // Helper function to remove error
            function removeError(input) {
                input.classList.remove('border-red-500', 'focus:ring-red-500/20');
                input.classList.add('border-slate-200', 'dark:border-slate-700');

                const parent = input.closest('.flex.flex-col');
                if (parent) {
                    const existingError = parent.querySelector('.text-red-500.text-xs');
                    if (existingError) {
                        existingError.remove();
                    }
                } else {
                    const nextSibling = input.nextSibling;
                    if (nextSibling && nextSibling.classList && nextSibling.classList.contains('text-red-500')) {
                        nextSibling.remove();
                    }
                }
            }

            // Validation functions
            function validateFirstName() {
                const value = firstNameInput.value.trim();
                if (value === '') {
                    showError(firstNameInput, 'First name is required');
                    return false;
                }
                if (value.length < 2) {
                    showError(firstNameInput, 'First name must be at least 2 characters');
                    return false;
                }
                if (!/^[a-zA-Z\s\-']+$/.test(value)) {
                    showError(firstNameInput, 'First name can only contain letters, spaces, hyphens, and apostrophes');
                    return false;
                }
                removeError(firstNameInput);
                return true;
            }

            function validateLastName() {
                const value = lastNameInput.value.trim();
                if (value === '') {
                    showError(lastNameInput, 'Last name is required');
                    return false;
                }
                if (value.length < 2) {
                    showError(lastNameInput, 'Last name must be at least 2 characters');
                    return false;
                }
                if (!/^[a-zA-Z\s\-']+$/.test(value)) {
                    showError(lastNameInput, 'Last name can only contain letters, spaces, hyphens, and apostrophes');
                    return false;
                }
                removeError(lastNameInput);
                return true;
            }

            function validateRollNo() {
                const value = rollNoInput.value.trim();
                if (value === '') {
                    showError(rollNoInput, 'Roll number is required');
                    return false;
                }
                if (!/^[A-Za-z0-9\-/]+$/.test(value)) {
                    showError(rollNoInput, 'Roll number can only contain letters, numbers, hyphens, and slashes');
                    return false;
                }
                removeError(rollNoInput);
                return true;
            }

            function validateGender() {
                const value = genderSelect.value;
                if (value === '') {
                    showError(genderSelect, 'Please select your gender');
                    return false;
                }
                removeError(genderSelect);
                return true;
            }

            function validateDOB() {
                const value = dobInput.value;
                if (value === '') {
                    showError(dobInput, 'Date of birth is required');
                    return false;
                }

                const birthDate = new Date(value);
                const today = new Date();
                let age = today.getFullYear() - birthDate.getFullYear();
                const monthDiff = today.getMonth() - birthDate.getMonth();

                if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
                    age--;
                }

                if (age < 16) {
                    showError(dobInput, 'You must be at least 16 years old');
                    return false;
                }

                if (age > 100) {
                    showError(dobInput, 'Please enter a valid date of birth');
                    return false;
                }

                removeError(dobInput);
                return true;
            }

            function validatePhone() {
                const value = phoneInput.value.trim();
                if (value === '') {
                    showError(phoneInput, 'Phone number is required');
                    return false;
                }

                // Indian mobile number validation (10 digits, starting with 6-9)
                const phoneRegex = /^[6-9]\d{9}$/;
                if (!phoneRegex.test(value)) {
                    showError(phoneInput, 'Please enter a valid 10-digit mobile number');
                    return false;
                }

                removeError(phoneInput);
                return true;
            }

            function validateAddress() {
                const value = addressTextarea.value.trim();
                if (value === '') {
                    showError(addressTextarea, 'Home address is required');
                    return false;
                }
                if (value.length < 10) {
                    showError(addressTextarea, 'Please enter a complete address (at least 10 characters)');
                    return false;
                }
                if (value.length > 200) {
                    showError(addressTextarea, 'Address cannot exceed 200 characters');
                    return false;
                }
                removeError(addressTextarea);
                return true;
            }

            function validateSemester() {
                const value = semesterSelect.value;
                if (value === '') {
                    showError(semesterSelect, 'Please select your current semester');
                    return false;
                }
                removeError(semesterSelect);
                return true;
            }

            function validateDivision() {
                const value = divisionSelect.value;
                if (value === '') {
                    showError(divisionSelect, 'Please select your division/section');
                    return false;
                }
                removeError(divisionSelect);
                return true;
            }

            // Real-time validation on blur
            if (firstNameInput) firstNameInput.addEventListener('blur', validateFirstName);
            if (lastNameInput) lastNameInput.addEventListener('blur', validateLastName);
            if (rollNoInput) rollNoInput.addEventListener('blur', validateRollNo);
            if (genderSelect) genderSelect.addEventListener('blur', validateGender);
            if (genderSelect) genderSelect.addEventListener('change', validateGender);
            if (dobInput) dobInput.addEventListener('blur', validateDOB);
            if (phoneInput) phoneInput.addEventListener('blur', validatePhone);
            if (addressTextarea) addressTextarea.addEventListener('blur', validateAddress);
            if (semesterSelect) semesterSelect.addEventListener('blur', validateSemester);
            if (semesterSelect) semesterSelect.addEventListener('change', validateSemester);
            if (divisionSelect) divisionSelect.addEventListener('blur', validateDivision);
            if (divisionSelect) divisionSelect.addEventListener('change', validateDivision);

            // Real-time validation on input (clear errors while typing)
            if (firstNameInput) firstNameInput.addEventListener('input', () => removeError(firstNameInput));
            if (lastNameInput) lastNameInput.addEventListener('input', () => removeError(lastNameInput));
            if (rollNoInput) rollNoInput.addEventListener('input', () => removeError(rollNoInput));
            if (dobInput) dobInput.addEventListener('input', () => removeError(dobInput));
            if (phoneInput) phoneInput.addEventListener('input', () => removeError(phoneInput));
            if (addressTextarea) addressTextarea.addEventListener('input', () => {
                if (addressTextarea.value.trim() !== '') removeError(addressTextarea);
            });

            // Form submission validation
            if (form) {
                form.addEventListener('submit', function(e) {
                    // Run all validations
                    const isFirstNameValid = validateFirstName();
                    const isLastNameValid = validateLastName();
                    const isRollNoValid = validateRollNo();
                    const isGenderValid = validateGender();
                    const isDOBValid = validateDOB();
                    const isPhoneValid = validatePhone();
                    const isAddressValid = validateAddress();
                    const isSemesterValid = validateSemester();
                    const isDivisionValid = validateDivision();

                    // Check if all validations passed
                    const isValid = isFirstNameValid && isLastNameValid && isRollNoValid &&
                        isGenderValid && isDOBValid && isPhoneValid &&
                        isAddressValid && isSemesterValid && isDivisionValid;

                    if (!isValid) {
                        e.preventDefault();
                        // Scroll to first error
                        const firstError = document.querySelector('.border-red-500');
                        if (firstError) {
                            firstError.scrollIntoView({
                                behavior: 'smooth',
                                block: 'center'
                            });
                            firstError.focus();
                        }

                        // Optional: Show a toast/alert message
                        const errorSummary = document.querySelector('.error-summary');
                        if (!errorSummary) {
                            const summary = document.createElement('div');
                            summary.className = 'error-summary fixed bottom-4 right-4 bg-red-500 text-white px-4 py-3 rounded-lg shadow-lg z-50 animate-pulse';
                            summary.innerHTML = '⚠️ Please fix the errors before submitting.';
                            document.body.appendChild(summary);
                            setTimeout(() => {
                                summary.remove();
                            }, 3000);
                        }
                    }
                });
            }

            // Reset button handler with confirmation
            const resetBtn = document.querySelector('button[type="reset"]');
            if (resetBtn) {
                resetBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    if (confirm('Are you sure you want to discard all changes? This cannot be undone.')) {
                        form.reset();
                        // Clear all errors
                        document.querySelectorAll('.border-red-500').forEach(input => {
                            removeError(input);
                        });
                        // Reset address counter
                        if (addressCounter) {
                            addressCounter.textContent = '0 / 200 characters';
                            addressCounter.classList.remove('text-red-500');
                            addressCounter.classList.add('text-slate-400');
                        }
                    }
                });
            }
        });
    </script>


</body>

</html>