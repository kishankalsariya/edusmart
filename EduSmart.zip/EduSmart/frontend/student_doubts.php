<?php
include("../backend/config/connection.php");
include("../backend/auth/auth.php");

$role    = $_SESSION['role'] ?? '';
$user_id = $_SESSION['user_id'] ?? 0;

date_default_timezone_set('Asia/Kolkata');

if (!in_array($role, ['student', 'teacher'])) {
  header("Location: login.php?error=unauthorized");
  exit();
}

$uq = $conn->prepare("SELECT * FROM users WHERE id=?");
$uq->bind_param("i", $user_id);
$uq->execute();
$user = $uq->get_result()->fetch_assoc();

$initials = strtoupper(substr($user['name'], 0, 1));
$is_teacher = $role === 'teacher';

// Dashboard link based on role
$dashboard_link = $is_teacher ? 'teacher_dashboard.php' : 'student_dashboard.php';
$portal_label   = $is_teacher ? 'Teacher Portal' : 'Student Portal';
?>
<!DOCTYPE html>
<html class="light" lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>EduSmart — Doubts</title>
  <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            primary: "#2b8cee",
            "primary-dark": "#1a6ec0",
            "background-light": "#f6f7f8",
            "background-dark": "#101922",
            "surface-light": "#ffffff",
            "surface-dark": "#1e293b"
          },
          fontFamily: {
            display: ["Lexend", "sans-serif"]
          },
          borderRadius: {
            DEFAULT: "0.25rem",
            lg: "0.5rem",
            xl: "0.75rem",
            "2xl": "1rem",
            full: "9999px"
          },
        }
      }
    };
  </script>
  <style>
    body {
      font-family: "Lexend", sans-serif
    }

    ::-webkit-scrollbar {
      width: 5px;
      height: 5px
    }

    ::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px
    }

    .dark ::-webkit-scrollbar-thumb {
      background: #334155
    }

    .material-symbols-outlined {
      font-variation-settings: "FILL" 0, "wght" 400, "GRAD" 0, "opsz" 24
    }

    .fill {
      font-variation-settings: "FILL" 1, "wght" 400, "GRAD" 0, "opsz" 24
    }

    /* Smooth message entrance */
    @keyframes msgIn {
      from {
        opacity: 0;
        transform: translateY(8px)
      }

      to {
        opacity: 1;
        transform: translateY(0)
      }
    }

    .msg-enter {
      animation: msgIn .2s ease forwards
    }

    /* Typing dots */
    @keyframes blink {

      0%,
      80%,
      100% {
        opacity: 0
      }

      40% {
        opacity: 1
      }
    }

    .dot {
      animation: blink 1.4s infinite both
    }

    .dot:nth-child(2) {
      animation-delay: .2s
    }

    .dot:nth-child(3) {
      animation-delay: .4s
    }
  </style>
</head>

<body class="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 font-display overflow-hidden h-screen">
  <div class="flex h-screen w-full">

    <!-- ═══════════ SIDEBAR ═══════════ -->
    <aside class="hidden md:flex flex-col w-64 h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 shrink-0 z-20">
      <div class="h-16 flex items-center px-6 border-b border-slate-100 dark:border-slate-800">
        <div class="flex items-center gap-3 my-6">
          <div class="bg-primary/10 p-2 rounded-xl">
            <span class="material-symbols-outlined text-primary text-2xl fill">school</span>
          </div>
          <div>
            <h1 class="text-lg font-bold leading-tight">EduSmart</h1>
            <p class="text-slate-500 text-xs"><?= $portal_label ?></p>
          </div>
        </div>
      </div>
      <nav class="flex-1 overflow-y-auto py-4 px-3 flex flex-col gap-1">
        <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors text-sm font-medium" href="<?= $dashboard_link ?>">
          <span class="material-symbols-outlined">dashboard</span>Dashboard
        </a>
        <?php if (!$is_teacher) : ?>
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-sm font-medium" href="student_attendance_details.php">
            <span class="material-symbols-outlined">calendar_month</span>Attendance
          </a>
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-sm font-medium" href="student_schedule.php">
            <span class="material-symbols-outlined">calendar_today</span>Schedule
          </a>
        <?php else : ?>
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-sm font-medium" href="teacher_take_attendance.php">
            <span class="material-symbols-outlined">edit_square</span>Take Attendance
          </a>
          <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-sm font-medium" href="teacher_reports.php">
            <span class="material-symbols-outlined">bar_chart</span>Reports
          </a>
        <?php endif; ?>
        <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-primary/10 text-primary font-semibold text-sm" href="#">
          <span class="material-symbols-outlined fill">chat_bubble</span>Doubts
        </a>
      </nav>
      <div class="mt-auto p-4 border-t border-slate-100 dark:border-slate-800">
        <a href="student_profile.php">
          <div class="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
            <div class="size-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm shrink-0"><?= $initials ?></div>
            <div class="overflow-hidden">
              <p class="text-sm font-semibold truncate"><?= htmlspecialchars($user['name']) ?></p>
              <p class="text-xs text-slate-500 capitalize"><?= $role ?></p>
            </div>
          </div>
        </a>
        <a href="../backend/users/logout.php" class="mt-2 flex items-center gap-3 px-3 py-2.5 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors text-sm font-medium">
          <span class="material-symbols-outlined">logout</span>Logout
        </a>
      </div>
    </aside>

    <!-- ═══════════ CHAT LAYOUT ═══════════ -->
    <main class="flex flex-1 h-full overflow-hidden relative">

      <!-- ── LEFT PANE: Contact List ── -->
      <div id="contact-pane" class="w-full md:w-80 lg:w-96 flex flex-col border-r border-slate-200 dark:border-slate-700 bg-white dark:bg-surface-dark h-full z-10 shrink-0">

        <!-- Search header -->
        <div class="p-4 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div class="flex items-center justify-between mb-4">
            <h2 class="text-xl font-bold text-slate-900 dark:text-white">
              <?= $is_teacher ? 'Students' : 'Teachers' ?>
            </h2>
            <span id="total-unread-badge" class="hidden items-center justify-center min-w-5 h-5 bg-primary text-white text-[10px] font-bold rounded-full px-1.5"></span>
          </div>
          <div class="relative">
            <span class="material-symbols-outlined absolute left-3 top-2.5 text-slate-400 text-[18px]">search</span>
            <input id="contact-search" type="text" placeholder="Search..." class="w-full pl-9 pr-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 border border-transparent focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none text-sm text-slate-900 dark:text-white placeholder-slate-400 transition-all" />
          </div>
        </div>

        <!-- Loading state -->
        <div id="contacts-loading" class="flex-1 flex items-center justify-center">
          <div class="text-center">
            <div class="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin mx-auto mb-3"></div>
            <p class="text-sm text-slate-400">Loading...</p>
          </div>
        </div>

        <!-- Empty state -->
        <div id="contacts-empty" class="hidden flex-1 flex flex-col items-center justify-center p-8 text-center">
          <span class="material-symbols-outlined text-5xl text-slate-300 dark:text-slate-600 block mb-3">person_search</span>
          <p class="text-slate-400 text-sm font-medium">No <?= $is_teacher ? 'students' : 'teachers' ?> found</p>
          <p class="text-slate-400 text-xs mt-1"><?= $is_teacher ? 'No students assigned to your classes yet.' : 'No teachers assigned to your classes yet.' ?></p>
        </div>

        <!-- Contact list -->
        <div id="contact-list" class="hidden flex-1 overflow-y-auto"></div>
      </div>

      <!-- ── RIGHT PANE: Chat Window ── -->
      <div id="chat-pane" class="hidden md:flex flex-1 flex-col bg-slate-50/30 dark:bg-[#0B1116] h-full">

        <!-- Empty / no chat selected state -->
        <div id="no-chat-selected" class="flex flex-col items-center justify-center h-full gap-4">
          <div class="size-24 rounded-full bg-primary/10 flex items-center justify-center">
            <span class="material-symbols-outlined text-5xl text-primary fill">chat_bubble</span>
          </div>
          <div class="text-center">
            <h3 class="text-xl font-bold text-slate-700 dark:text-slate-200">EduSmart Doubts</h3>
            <p class="text-slate-400 text-sm mt-1">Select a <?= $is_teacher ? 'student' : 'teacher' ?> to start chatting</p>
          </div>
          <?php if (!$is_teacher) : ?>
            <div class="flex items-center gap-2 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-800 rounded-xl px-4 py-3 text-sm text-blue-700 dark:text-blue-400 max-w-xs text-center">
              <span class="material-symbols-outlined text-[18px]">lightbulb</span>
              Ask your teacher any doubt — they'll reply as soon as possible.
            </div>
          <?php else : ?>
            <div class="flex items-center gap-2 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-100 dark:border-emerald-800 rounded-xl px-4 py-3 text-sm text-emerald-700 dark:text-emerald-400 max-w-xs text-center">
              <span class="material-symbols-outlined text-[18px]">school</span>
              Answer student doubts and help them learn better.
            </div>
          <?php endif; ?>
        </div>

        <!-- Active chat area (hidden until contact selected) -->
        <div id="active-chat" class="hidden flex-1 flex flex-col h-full">

          <!-- Chat Header -->
          <header class="h-16 px-5 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-surface-dark flex items-center justify-between shrink-0 shadow-sm z-10">
            <div class="flex items-center gap-3">
              <!-- Mobile back button -->
              <button id="btn-back" onclick="closeChat()" class="md:hidden p-2 -ml-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                <span class="material-symbols-outlined">arrow_back</span>
              </button>
              <div id="chat-avatar" class="size-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0 bg-primary/10 text-primary"></div>
              <div>
                <h2 id="chat-name" class="text-base font-bold text-slate-900 dark:text-white leading-tight"></h2>
                <p id="chat-sub" class="text-xs text-slate-500 dark:text-slate-400"></p>
              </div>
            </div>
          </header>

          <!-- Messages area -->
          <div id="messages-area" class="flex-1 overflow-y-auto p-4 sm:p-6 flex flex-col gap-3">
            <div id="msg-loading" class="flex-1 flex items-center justify-center py-10">
              <div class="w-7 h-7 border-4 border-primary/30 border-t-primary rounded-full animate-spin"></div>
            </div>
            <div id="msg-empty" class="hidden flex-col items-center justify-center py-16 text-center gap-3">
              <span class="material-symbols-outlined text-5xl text-slate-300 dark:text-slate-600">chat_bubble_outline</span>
              <p class="text-slate-400 text-sm font-medium">No messages yet</p>
              <p class="text-slate-400 text-xs"><?= $is_teacher ? 'Wait for the student to ask a doubt.' : 'Ask your first doubt below!' ?></p>
            </div>
            <!-- messages injected here -->
          </div>

          <!-- Input Area -->
          <div class="p-3 sm:p-4 bg-white dark:bg-surface-dark border-t border-slate-200 dark:border-slate-800 shrink-0">
            <div class="flex items-end gap-2 bg-slate-100 dark:bg-slate-800 px-3 py-2 rounded-2xl border border-transparent focus-within:border-primary/40 focus-within:bg-white dark:focus-within:bg-slate-900 transition-all">
              <textarea id="msg-input" rows="1" placeholder="<?= $is_teacher ? 'Type your reply...' : 'Ask a doubt...' ?>" class="flex-1 bg-transparent border-0 focus:ring-0 text-sm text-slate-900 dark:text-white placeholder-slate-400 resize-none py-2 max-h-32 outline-none leading-relaxed" onkeydown="handleKey(event)"></textarea>
              <button id="send-btn" onclick="sendMessage()" class="p-2 bg-primary hover:bg-primary-dark text-white rounded-xl shadow-sm transition-all active:scale-95 shrink-0 flex items-center justify-center">
                <span class="material-symbols-outlined text-[20px]">send</span>
              </button>
            </div>
            <p class="text-center text-[10px] text-slate-400 mt-1.5">Press <kbd class="bg-slate-200 dark:bg-slate-700 px-1 py-0.5 rounded text-[9px]">Enter</kbd> to send · <kbd class="bg-slate-200 dark:bg-slate-700 px-1 py-0.5 rounded text-[9px]">Shift+Enter</kbd> for new line</p>
          </div>
        </div>
      </div>

    </main>
  </div>




  <script>
    const ROLE = '<?= $role ?>';
    const MY_NAME = '<?= addslashes($user['name']) ?>';
    const MY_INIT = '<?= $initials ?>';
    const IS_TEACHER = <?= $is_teacher ? 'true' : 'false' ?>;

    let contacts = [];
    let activeId = null; // teacher_id (for student) or student_id (for teacher)
    let activeName = '';
    let lastMsgId = 0;
    let pollTimer = null;
    let isMobile = window.innerWidth < 768;

    const avatarColors = [
      'bg-blue-100 text-blue-700', 'bg-purple-100 text-purple-700',
      'bg-emerald-100 text-emerald-700', 'bg-amber-100 text-amber-700',
      'bg-rose-100 text-rose-700', 'bg-teal-100 text-teal-700'
    ];

    function avColor(i) {
      return avatarColors[i % avatarColors.length];
    }

    function initials(name) {
      return name.trim().split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
    }

    function esc(s) {
      return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\n/g, '<br>');
    }

    function fmtTime(ts) {
      if (!ts) return '';
      const d = new Date(ts.replace(' ', 'T'));
      const now = new Date();
      const diff = (now - d) / 1000;
      if (diff < 60) return 'just now';
      if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
      if (diff < 86400) return d.toLocaleTimeString('en-IN', {
        hour: '2-digit',
        minute: '2-digit'
      });
      const yest = new Date(now);
      yest.setDate(yest.getDate() - 1);
      if (d.toDateString() === yest.toDateString()) return 'Yesterday';
      return d.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short'
      });
    }

    function fmtMsgTime(ts) {
      if (!ts) return '';
      const d = new Date(ts.replace(' ', 'T'));
      return d.toLocaleTimeString('en-IN', {
        hour: '2-digit',
        minute: '2-digit'
      });
    }

    function fmtDateLabel(ts) {
      const d = new Date(ts.replace(' ', 'T'));
      const now = new Date();
      if (d.toDateString() === now.toDateString()) return 'Today';
      const yest = new Date(now);
      yest.setDate(yest.getDate() - 1);
      if (d.toDateString() === yest.toDateString()) return 'Yesterday';
      return d.toLocaleDateString('en-IN', {
        weekday: 'long',
        day: 'numeric',
        month: 'long'
      });
    }

    // ── Load contacts ─────────────────────────────────────────────────────────────
    async function loadContacts() {
      try {
        const res = await fetch('../backend/doubts/get_contacts.php');
        const data = await res.json();
        contacts = data.contacts || [];
        renderContacts(contacts);
      } catch (e) {
        console.error(e);
      }
    }

    function renderContacts(list) {
      const loading = document.getElementById('contacts-loading');
      const empty = document.getElementById('contacts-empty');
      const cl = document.getElementById('contact-list');
      loading.classList.add('hidden');

      if (!list.length) {
        empty.classList.remove('hidden');
        cl.classList.add('hidden');
        return;
      }
      empty.classList.add('hidden');
      cl.classList.remove('hidden');

      let totalUnread = 0;
      cl.innerHTML = list.map((c, i) => {
        const cid = IS_TEACHER ? c.student_id : c.teacher_id;
        const cname = IS_TEACHER ? c.student_name : c.teacher_name;
        const csub = IS_TEACHER ?
          `Sem ${c.semester_no} · Div ${c.division_name} · Roll ${c.roll_no}` :
          c.subjects || '';
        const unread = parseInt(c.unread) || 0;
        totalUnread += unread;
        const isActive = cid == activeId;
        const init = initials(cname);
        const color = avColor(i);
        const lastMsg = c.last_msg ? esc(c.last_msg).substring(0, 45) + (c.last_msg.length > 45 ? '…' : '') : '<em class="text-slate-400">No messages yet</em>';
        const lastTime = fmtTime(c.last_time);

        return `
    <div class="contact-item group flex items-center gap-3 p-4 cursor-pointer transition-all border-l-4 ${isActive?'bg-primary/5 dark:bg-primary/10 border-primary':'border-transparent hover:bg-slate-50 dark:hover:bg-slate-800/50'}"
      data-id="${cid}" data-name="${cname.replace(/'/g,"&#39;")}" data-sub="${csub.replace(/'/g,'&#39;')}" data-idx="${i}"
      onclick="openChat(${cid},'${cname.replace(/'/g,"\\'")}','${csub.replace(/'/g,"\\'")}',${i})">
      <div class="relative shrink-0">
        <div class="size-12 rounded-full ${color} flex items-center justify-center font-bold text-sm shadow-sm">${init}</div>
        ${isActive?'<span class="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white dark:border-slate-800 rounded-full"></span>':''}
      </div>
      <div class="flex-1 min-w-0">
        <div class="flex justify-between items-baseline mb-0.5">
          <h3 class="text-sm font-semibold text-slate-900 dark:text-white truncate">${cname}</h3>
          <span class="text-[10px] ${unread?'text-primary font-bold':'text-slate-400'} shrink-0 ml-2">${lastTime}</span>
        </div>
        <p class="text-xs text-slate-400 truncate mb-0.5">${csub}</p>
        <p class="text-xs ${unread?'text-slate-900 dark:text-white font-semibold':'text-slate-500 dark:text-slate-400'} truncate">${lastMsg}</p>
      </div>
      ${unread?`<span class="size-5 flex items-center justify-center bg-primary text-white text-[10px] font-bold rounded-full shrink-0">${unread>9?'9+':unread}</span>`:''}
    </div>`;
      }).join('');

      // Total unread badge
      const badge = document.getElementById('total-unread-badge');
      if (totalUnread > 0) {
        badge.textContent = totalUnread > 99 ? '99+' : totalUnread;
        badge.classList.remove('hidden');
        badge.classList.add('flex');
      } else {
        badge.classList.add('hidden');
        badge.classList.remove('flex');
      }

      // Search filter
      document.getElementById('contact-search').oninput = function() {
        const q = this.value.toLowerCase();
        document.querySelectorAll('.contact-item').forEach(el => {
          el.style.display = el.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
      };
    }

    // ── Open a chat ───────────────────────────────────────────────────────────────
    function openChat(cid, cname, csub, idx) {
      activeId = cid;
      activeName = cname;
      lastMsgId = 0;

      // Update active state in contact list
      document.querySelectorAll('.contact-item').forEach(el => {
        const isThis = parseInt(el.dataset.id) === cid;
        el.classList.toggle('bg-primary/5', isThis);
        el.classList.toggle('dark:bg-primary/10', isThis);
        el.classList.toggle('border-primary', isThis);
        el.classList.toggle('border-transparent', !isThis);
        // Remove unread badge
        if (isThis) {
          const b = el.querySelector('.bg-primary.rounded-full');
          if (b) b.remove();
        }
      });

      // Set header
      const init = initials(cname);
      const color = avatarColors[idx % avatarColors.length];
      document.getElementById('chat-avatar').className = `size-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0 ${color}`;
      document.getElementById('chat-avatar').textContent = init;
      document.getElementById('chat-name').textContent = cname;
      document.getElementById('chat-sub').textContent = csub;

      // Show chat pane
      document.getElementById('no-chat-selected').classList.add('hidden');
      document.getElementById('active-chat').classList.remove('hidden');
      document.getElementById('msg-loading').classList.remove('hidden');
      document.getElementById('msg-empty').classList.add('hidden');
      document.getElementById('messages-area').querySelectorAll('.msg-row,.date-sep').forEach(e => e.remove());

      // On mobile: hide contact list, show chat
      if (isMobile || window.innerWidth < 768) {
        document.getElementById('contact-pane').classList.add('hidden');
        document.getElementById('chat-pane').classList.remove('hidden');
        document.getElementById('chat-pane').classList.add('flex');
      }

      // Focus input
      document.getElementById('msg-input').focus();

      // Load messages + start polling
      if (pollTimer) clearInterval(pollTimer);
      fetchMessages(true);
      pollTimer = setInterval(() => fetchMessages(false), 3000);
    }

    function closeChat() {
      if (pollTimer) clearInterval(pollTimer);
      activeId = null;
      document.getElementById('contact-pane').classList.remove('hidden');
      document.getElementById('chat-pane').classList.add('hidden');
      document.getElementById('chat-pane').classList.remove('flex');
    }

    // ── Fetch messages ────────────────────────────────────────────────────────────
    async function fetchMessages(initial) {
      if (!activeId) return;
      try {
        const url = `../backend/doubts/get_messages.php?with=${activeId}${lastMsgId?'&after='+lastMsgId:''}`;
        const res = await fetch(url);
        const data = await res.json();
        const msgs = data.messages || [];

        if (initial) document.getElementById('msg-loading').classList.add('hidden');

        if (!msgs.length) {
          if (initial) document.getElementById('msg-empty').classList.remove('hidden');
          // Refresh contacts silently for unread updates
          refreshContactsUnread();
          return;
        }
        document.getElementById('msg-empty').classList.add('hidden');

        const area = document.getElementById('messages-area');
        const atBottom = area.scrollHeight - area.scrollTop - area.clientHeight < 80;

        msgs.forEach(m => appendMessage(m, false));
        if (msgs.length) lastMsgId = Math.max(...msgs.map(m => m.doubt_id));

        if (initial || atBottom) scrollBottom();
        refreshContactsUnread();
      } catch (e) {
        console.error(e);
      }
    }

    // ── Render a single message ───────────────────────────────────────────────────
    let lastRenderedDate = '';

    function appendMessage(m, animate) {
      const area = document.getElementById('messages-area');
      const isMine = (IS_TEACHER && m.sent_by === 'teacher') || (!IS_TEACHER && m.sent_by === 'student');
      const dt = m.created_at ? m.created_at.split(' ')[0] : '';
      const time = fmtMsgTime(m.created_at);

      // Date separator
      if (dt && dt !== lastRenderedDate) {
        lastRenderedDate = dt;
        const sep = document.createElement('div');
        sep.className = 'date-sep flex justify-center my-3';
        sep.innerHTML = `<span class="text-[10px] font-semibold text-slate-400 bg-slate-100 dark:bg-slate-800 px-3 py-1 rounded-full uppercase tracking-wider">${fmtDateLabel(m.created_at)}</span>`;
        area.appendChild(sep);
      }

      const wrap = document.createElement('div');
      wrap.className = `msg-row flex gap-2.5 max-w-[78%] ${isMine?'self-end flex-row-reverse':'self-start'} ${animate?'msg-enter':''}`;
      wrap.dataset.id = m.doubt_id;

      const avatarHtml = `<div class="size-8 rounded-full ${isMine?'bg-primary/10 text-primary':'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'} flex items-center justify-center font-bold text-xs shrink-0 self-end mb-5">${isMine?MY_INIT:initials(activeName)}</div>`;

      const bubbleClass = isMine ?
        'bg-primary text-white rounded-2xl rounded-br-sm shadow-md shadow-primary/10' :
        'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-2xl rounded-bl-sm shadow-sm border border-slate-100 dark:border-slate-700';

      const tickHtml = isMine ?
        `<span class="material-symbols-outlined text-[12px] ${m.is_read?'text-blue-400':'text-slate-300'}" style="font-variation-settings:'FILL' 1">done_all</span>` :
        '';

      wrap.innerHTML = `
    ${avatarHtml}
    <div class="flex flex-col gap-0.5 ${isMine?'items-end':'items-start'}">
      <div class="${bubbleClass} px-4 py-2.5">
        <p class="text-sm leading-relaxed whitespace-pre-wrap">${esc(m.message)}</p>
      </div>
      <div class="flex items-center gap-1 px-1">
        <span class="text-[10px] text-slate-400">${time}</span>
        ${tickHtml}
      </div>
    </div>`;

      area.appendChild(wrap);
    }

    function scrollBottom() {
      const area = document.getElementById('messages-area');
      area.scrollTo({
        top: area.scrollHeight,
        behavior: 'smooth'
      });
    }

    // ── Send message ──────────────────────────────────────────────────────────────
    async function sendMessage() {
      if (!activeId) return;
      const input = document.getElementById('msg-input');
      const text = input.value.trim();
      if (!text) return;

      input.value = '';
      input.style.height = 'auto';

      const btn = document.getElementById('send-btn');
      btn.disabled = true;

      // Optimistic UI — add message immediately
      const tempMsg = {
        doubt_id: Date.now(),
        message: text,
        sent_by: ROLE,
        is_read: 0,
        created_at: new Date().toLocaleString('sv-SE').replace('T', ' ')
        // created_at: new Date().toISOString().replace('T', ' ').split('.')[0]
      };
      document.getElementById('msg-empty').classList.add('hidden');
      appendMessage(tempMsg, true);
      scrollBottom();

      try {
        const res = await fetch('../backend/doubts/send_message.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            with: activeId,
            message: text
          })
        });
        const data = await res.json();
        if (data.success) {
          // Replace temp with real id
          const tempEl = document.querySelector(`[data-id="${tempMsg.doubt_id}"]`);
          if (tempEl) tempEl.dataset.id = data.doubt_id;
          lastMsgId = Math.max(lastMsgId, data.doubt_id);
        }
      } catch (e) {
        console.error(e);
      }

      btn.disabled = false;
      input.focus();
      loadContacts(); // refresh contact list to show latest message
    }

    // ── Keyboard shortcuts ────────────────────────────────────────────────────────
    function handleKey(e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
      // Auto-expand textarea
      const t = document.getElementById('msg-input');
      t.style.height = 'auto';
      t.style.height = Math.min(t.scrollHeight, 128) + 'px';
    }

    // ── Silent contact refresh for unread counts ──────────────────────────────────
    async function refreshContactsUnread() {
      try {
        const res = await fetch('../backend/doubts/get_contacts.php');
        const data = await res.json();
        contacts = data.contacts || [];
        renderContacts(contacts);
      } catch (e) {}
    }

    // ── Mobile resize handler ─────────────────────────────────────────────────────
    window.addEventListener('resize', () => {
      isMobile = window.innerWidth < 768;
      if (!isMobile && activeId) {
        document.getElementById('contact-pane').classList.remove('hidden');
        document.getElementById('chat-pane').classList.remove('hidden');
        document.getElementById('chat-pane').classList.add('flex');
      }
    });

    // Init
    loadContacts();
  </script>
</body>

</html>