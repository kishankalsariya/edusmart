<?php
include("../backend/config/connection.php");
include("../backend/auth/auth.php");

if ($_SESSION['role'] !== 'student') {
  header("Location: login.php?error=unauthorized");
  exit();
}

$user_id = $_SESSION['user_id'];
$uq = $conn->prepare("SELECT * FROM users WHERE id = ?");
$uq->bind_param("i", $user_id);
$uq->execute();
$user = $uq->get_result()->fetch_assoc();
?>
<!DOCTYPE html>
<html class="light" lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>EduSmart - My Attendance</title>
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
  <script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            primary: "#2b8cee",
            "primary-dark": "#1a6ec0",
            "background-light": "#f6f7f8",
            "background-dark": "#101922"
          },
          fontFamily: {
            display: ["Lexend", "sans-serif"]
          },
          borderRadius: {
            DEFAULT: "0.25rem",
            lg: "0.5rem",
            xl: "0.75rem",
            "2xl": "1rem",
            full: "9999px"
          },
        },
      },
    };
  </script>
  <style>
    ::-webkit-scrollbar {
      width: 6px;
    }

    ::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px;
    }

    .material-symbols-outlined {
      font-variation-settings: "FILL" 0, "wght" 400, "GRAD" 0, "opsz" 24;
    }

    body {
      font-family: "Lexend", sans-serif;
    }

    .circle-bg {
      fill: none;
      stroke: #e2e8f0;
      stroke-width: 8;
    }

    .circle-progress {
      fill: none;
      stroke-width: 8;
      stroke-linecap: round;
      transition: stroke-dashoffset 1s ease;
      transform: rotate(-90deg);
      transform-origin: 50% 50%;
    }
  </style>
</head>

<body class="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 min-h-screen flex">

  <!-- Sidebar -->
  <aside class="hidden md:flex flex-col w-64 h-screen sticky top-0 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 shrink-0">
    <div class="h-16 flex items-center px-6 border-b border-slate-100 dark:border-slate-800">
      <div class="flex items-center gap-3 mt-4 mb-4">
        <div class="bg-primary/10 p-2 rounded-xl">
          <span class="material-symbols-outlined text-primary text-2xl">school</span>
        </div>
        <div>
          <h1 class="text-slate-900 dark:text-white text-lg font-bold leading-tight">EduSmart</h1>
          <p class="text-slate-500 text-xs">Student Portal</p>
        </div>
      </div>
    </div>
    <nav class="flex-1 overflow-y-auto py-4 px-3 flex flex-col gap-1">
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors text-sm font-medium" href="student_dashboard.php">
        <span class="material-symbols-outlined">dashboard</span> Dashboard
      </a>
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-primary/10 text-primary font-semibold text-sm" href="#">
        <span class="material-symbols-outlined">calendar_month</span> Attendance
      </a>
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors text-sm font-medium" href="student_schedule.php">
        <span class="material-symbols-outlined">calendar_today</span> Schedule
      </a>
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors text-sm font-medium" href="student_doubts.php">
        <span class="material-symbols-outlined">chat_bubble</span> Doubts
      </a>
    </nav>
    <div class="p-4 border-t border-slate-100 dark:border-slate-800">
      <a href="student_profile.php">
        <div class="flex items-center gap-3">
          <div class="size-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
            <?= strtoupper(substr($user['name'], 0, 1)) ?>
          </div>
          <div class="min-w-0">
            <p class="text-sm font-semibold truncate"><?= htmlspecialchars($user['name']) ?></p>
            <!-- <p class="text-xs text-slate-500 truncate"><?= htmlspecialchars($user['email']) ?></p> -->
          </div>
        </div>
      </a>
    </div>
  </aside>

  <!-- Content -->
  <div class="flex-1 flex flex-col min-h-screen overflow-auto">

    <!-- Mobile Header -->
    <header class="md:hidden flex items-center justify-between bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 py-3 sticky top-0 z-30">
      <div class="flex items-center gap-2">
        <span class="material-symbols-outlined text-primary">school</span>
        <span class="font-bold">EduSmart</span>
      </div>
      <div class="size-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs">
        <?= strtoupper(substr($user['name'], 0, 1)) ?>
      </div>
    </header>

    <main class="flex-1 px-4 sm:px-8 py-8 max-w-[1000px] mx-auto w-full">

      <!-- Page Header -->
      <div class="mb-8">
        <h1 class="text-3xl font-black tracking-tight mb-1">My Attendance</h1>
        <p class="text-slate-500 dark:text-slate-400">Track your overall and subject-wise attendance.</p>
      </div>

      <!-- Loading -->
      <div id="loading-state" class="text-center py-20">
        <div class="inline-block w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin mb-4"></div>
        <p class="text-slate-400 font-medium">Loading your attendance data...</p>
      </div>

      <!-- No data state -->
      <div id="no-data-state" class="hidden text-center py-20">
        <span class="material-symbols-outlined text-6xl text-slate-300 block mb-4">event_busy</span>
        <h3 class="text-lg font-bold text-slate-600 dark:text-slate-300 mb-2">No Attendance Records Yet</h3>
        <p class="text-slate-400">Your attendance will appear here once your teachers start marking it.</p>
      </div>

      <!-- Main Data -->
      <div id="main-content" class="hidden space-y-8">

        <!-- Overall Card -->
        <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
          <h2 class="text-lg font-bold mb-6 flex items-center gap-2">
            <span class="material-symbols-outlined text-primary">donut_large</span>
            Overall Attendance
          </h2>
          <div class="flex flex-col sm:flex-row items-center gap-8">

            <!-- Circular Progress -->
            <div class="relative shrink-0">
              <svg width="160" height="160" viewBox="0 0 160 160">
                <circle class="circle-bg" cx="80" cy="80" r="68" />
                <circle id="overall-circle" class="circle-progress" cx="80" cy="80" r="68" stroke="#2b8cee" stroke-dasharray="427.26" stroke-dashoffset="427.26" />
              </svg>
              <div class="absolute inset-0 flex flex-col items-center justify-center">
                <span id="overall-pct" class="text-4xl font-black text-slate-900 dark:text-white">--%</span>
                <span class="text-xs text-slate-500 font-medium mt-1">Overall</span>
              </div>
            </div>

            <!-- Stats Grid -->
            <div class="grid grid-cols-3 gap-4 flex-1 w-full">
              <div class="bg-slate-50 dark:bg-slate-800 rounded-xl p-4 text-center">
                <div class="text-2xl font-black text-slate-900 dark:text-white" id="overall-total">--</div>
                <div class="text-xs text-slate-500 font-medium mt-1">Total Classes</div>
              </div>
              <div class="bg-green-50 dark:bg-green-900/20 rounded-xl p-4 text-center">
                <div class="text-2xl font-black text-green-600" id="overall-present">--</div>
                <div class="text-xs text-green-600/70 font-medium mt-1">Present</div>
              </div>
              <div class="bg-red-50 dark:bg-red-900/20 rounded-xl p-4 text-center">
                <div class="text-2xl font-black text-red-500" id="overall-absent">--</div>
                <div class="text-xs text-red-500/70 font-medium mt-1">Absent</div>
              </div>
            </div>
          </div>

          <!-- Attendance Warning Banner -->
          <div id="warning-banner" class="hidden mt-6 p-4 rounded-xl bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 flex items-start gap-3">
            <span class="material-symbols-outlined text-red-500 shrink-0 mt-0.5">warning</span>
            <div>
              <p class="font-semibold text-red-700 dark:text-red-400 text-sm">Low Attendance Warning</p>
              <p class="text-red-600/80 dark:text-red-400/70 text-xs mt-0.5">Your attendance is below 75%. This may affect your eligibility for exams.</p>
            </div>
          </div>
          <div id="good-banner" class="hidden mt-6 p-4 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 flex items-center gap-3">
            <span class="material-symbols-outlined text-green-500">verified</span>
            <p class="font-semibold text-green-700 dark:text-green-400 text-sm">Great! Your attendance is above 75%.</p>
          </div>
        </div>

        <!-- Subject-wise Card -->
        <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
          <h2 class="text-lg font-bold mb-6 flex items-center gap-2">
            <span class="material-symbols-outlined text-primary">menu_book</span>
            Subject-wise Breakdown
          </h2>
          <div id="subject-list" class="space-y-4"></div>
        </div>

        <!-- Recent Log Card -->
        <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
          <h2 class="text-lg font-bold mb-6 flex items-center gap-2">
            <span class="material-symbols-outlined text-primary">history</span>
            Recent Activity
            <span class="text-xs font-normal text-slate-400 ml-2">(Last 30 records)</span>
          </h2>
          <div class="overflow-x-auto">
            <table class="w-full text-sm">
              <thead>
                <tr class="text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
                  <th class="pb-3 text-left">Date</th>
                  <th class="pb-3 text-left">Day</th>
                  <th class="pb-3 text-left">Subject</th>
                  <th class="pb-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody id="recent-log" class="divide-y divide-slate-100 dark:divide-slate-800"></tbody>
            </table>
          </div>
        </div>

      </div>
    </main>
  </div>

  <script>
    async function loadAttendance() {
      try {
        const res = await fetch('../backend/attendance/get_student_attendance.php');
        const data = await res.json();
        document.getElementById('loading-state').classList.add('hidden');

        if (data.error || data.overall.total === 0) {
          document.getElementById('no-data-state').classList.remove('hidden');
          return;
        }

        document.getElementById('main-content').classList.remove('hidden');
        renderOverall(data.overall);
        renderSubjects(data.subjects);
        renderLog(data.recent_log);
      } catch (e) {
        document.getElementById('loading-state').classList.add('hidden');
        document.getElementById('no-data-state').classList.remove('hidden');
      }
    }

    function renderOverall(o) {
      const pct = o.percentage;
      document.getElementById('overall-pct').textContent = pct + '%';
      document.getElementById('overall-total').textContent = o.total;
      document.getElementById('overall-present').textContent = o.present;
      document.getElementById('overall-absent').textContent = o.absent;

      // Animate circle: circumference = 2 * pi * 68 = 427.26
      const circ = 427.26;
      const offset = circ - (circ * pct / 100);
      setTimeout(() => {
        const circle = document.getElementById('overall-circle');
        circle.style.strokeDashoffset = offset;
        // Color based on %
        circle.style.stroke = pct >= 75 ? '#22c55e' : pct >= 60 ? '#f59e0b' : '#ef4444';
        document.getElementById('overall-pct').style.color = pct >= 75 ? '#22c55e' : pct >= 60 ? '#f59e0b' : '#ef4444';
      }, 100);

      if (pct < 75) {
        document.getElementById('warning-banner').classList.remove('hidden');
      } else {
        document.getElementById('good-banner').classList.remove('hidden');
      }
    }

    function renderSubjects(subjects) {
      const container = document.getElementById('subject-list');
      if (!subjects.length) {
        container.innerHTML = '<p class="text-slate-400 text-sm text-center py-4">No subject data available.</p>';
        return;
      }
      container.innerHTML = subjects.map(s => {
        const pct = s.percentage;
        const barColor = pct >= 75 ? 'bg-green-500' : pct >= 60 ? 'bg-amber-500' : 'bg-red-500';
        const textColor = pct >= 75 ? 'text-green-600' : pct >= 60 ? 'text-amber-600' : 'text-red-500';
        const badge = pct >= 75 ?
          '<span class="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">Good</span>' :
          pct >= 60 ?
          '<span class="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-medium">At Risk</span>' :
          '<span class="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-medium">Low</span>';
        return `
    <div class="p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30">
      <div class="flex items-center justify-between mb-3">
        <div class="flex items-center gap-2">
          <span class="material-symbols-outlined text-primary text-[18px]">book</span>
          <span class="font-semibold text-slate-800 dark:text-white text-sm">${esc(s.subject_name)}</span>
          ${badge}
        </div>
        <span class="font-black ${textColor} text-lg">${pct}%</span>
      </div>
      <div class="w-full bg-slate-200 dark:bg-slate-700 rounded-full h-2.5 mb-2">
        <div class="${barColor} h-2.5 rounded-full transition-all duration-1000" style="width: 0%" data-width="${pct}%"></div>
      </div>
      <div class="flex justify-between text-xs text-slate-500">
        <span>${s.present_count} Present</span>
        <span>${s.absent_count} Absent</span>
        <span>${s.total_classes} Total</span>
      </div>
    </div>`;
      }).join('');

      // Animate bars
      setTimeout(() => {
        document.querySelectorAll('[data-width]').forEach(el => {
          el.style.width = el.dataset.width;
        });
      }, 150);
    }

    function renderLog(log) {
      const tbody = document.getElementById('recent-log');
      if (!log.length) {
        tbody.innerHTML = '<tr><td colspan="4" class="py-6 text-center text-slate-400 text-sm">No recent records</td></tr>';
        return;
      }
      tbody.innerHTML = log.map(r => {
        const isPresent = r.status === 'present';
        const badge = isPresent ?
          '<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-100 text-green-700 text-xs font-semibold"><span class="w-1.5 h-1.5 rounded-full bg-green-500 inline-block"></span>Present</span>' :
          '<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-100 text-red-700 text-xs font-semibold"><span class="w-1.5 h-1.5 rounded-full bg-red-500 inline-block"></span>Absent</span>';
        const d = new Date(r.attendance_date);
        const dateStr = d.toLocaleDateString('en-IN', {
          day: 'numeric',
          month: 'short',
          year: 'numeric'
        });
        return `<tr class="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
      <td class="py-3 text-slate-700 dark:text-slate-300">${dateStr}</td>
      <td class="py-3 text-slate-500">${r.day_name}</td>
      <td class="py-3 font-medium text-slate-800 dark:text-white">${esc(r.subject_name)}</td>
      <td class="py-3 text-center">${badge}</td>
    </tr>`;
      }).join('');
    }

    function esc(s) {
      return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    loadAttendance();
  </script>
</body>

</html>