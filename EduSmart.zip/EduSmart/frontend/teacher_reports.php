<?php
include("../backend/config/connection.php");
include("../backend/auth/auth.php");

if ($_SESSION['role'] !== 'teacher') {
  header("Location: login.php?error=unauthorized");
  exit();
}
$user_id = $_SESSION['user_id'];
$uq = $conn->prepare("SELECT name FROM users WHERE id = ?");
$uq->bind_param("i", $user_id);
$uq->execute();
$teacher_user = $uq->get_result()->fetch_assoc();
$initials = strtoupper(substr($teacher_user['name'], 0, 2));
?>
<!DOCTYPE html>
<html class="light" lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>EduSmart - Teacher Reports</title>
  <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            primary: "#2b8cee",
            "primary-dark": "#1a6ec0",
            "background-light": "#f6f7f8",
            "background-dark": "#101922",
            "slate-850": "#15202B"
          },
          fontFamily: {
            display: ["Lexend", "sans-serif"]
          },
          borderRadius: {
            DEFAULT: "0.25rem",
            lg: "0.5rem",
            xl: "0.75rem",
            "2xl": "1rem",
            full: "9999px"
          },
        }
      },
    };
  </script>
  <style>
    body {
      font-family: "Lexend", sans-serif;
    }

    ::-webkit-scrollbar {
      width: 6px;
      height: 6px
    }

    ::-webkit-scrollbar-track {
      background: transparent
    }

    ::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px
    }

    .dark ::-webkit-scrollbar-thumb {
      background: #475569
    }

    .material-symbols-outlined {
      font-variation-settings: "FILL" 0, "wght" 400, "GRAD" 0, "opsz" 24
    }

    .bar-fill {
      width: 0;
      transition: width 1s cubic-bezier(.4, 0, .2, 1)
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(6px)
      }

      to {
        opacity: 1;
        transform: translateY(0)
      }
    }

    .fade-in {
      animation: fadeIn .25s ease forwards
    }
  </style>
</head>

<body class="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-white h-screen overflow-hidden flex">

  <!-- ═══════════════ SIDEBAR ═══════════════ -->
  <aside class="w-64 h-full bg-white dark:bg-slate-850 border-r border-slate-200 dark:border-slate-800 flex-shrink-0 flex flex-col">
    <div class="p-6 flex items-center gap-3">
      <div class="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
        <span class="material-symbols-outlined text-primary text-2xl">school</span>
      </div>
      <div>
        <h1 class="text-slate-900 dark:text-white text-lg font-bold leading-tight">EduSmart</h1>
        <p class="text-slate-500 dark:text-slate-400 text-xs">Teacher Panel</p>
      </div>
    </div>

    <nav class="flex-1 overflow-y-auto px-4 py-2 flex flex-col gap-1">
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors" href="teacher_dashboard.php">
        <span class="material-symbols-outlined">dashboard</span><span class="text-sm font-medium">Dashboard</span>
      </a>
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors" href="teacher_take_attendance.php">
        <span class="material-symbols-outlined">edit_square</span><span class="text-sm font-medium">Take Attendance</span>
      </a>
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors" href="teacher_attendance_records.php">
        <span class="material-symbols-outlined">receipt_long</span><span class="text-sm font-medium">Attendance Records</span>
      </a>
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors" href="student_doubts.php">
        <span class="material-symbols-outlined">chat_bubble</span><span class="text-sm font-medium">Student Doubts</span>
      </a>
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-primary/10 text-primary font-semibold" href="#">
        <span class="material-symbols-outlined">bar_chart</span><span class="text-sm font-medium">Reports</span>
      </a>
    </nav>

    <!-- Teacher info + logout -->
    <div class="mt-auto border-t border-slate-100 dark:border-slate-800">
      <a class="flex items-center gap-3 mx-4 mb-4 px-3 py-2.5 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors" href="../backend/users/logout.php">
        <span class="material-symbols-outlined">logout</span><span class="text-sm font-medium">Logout</span>
      </a>
    </div>
  </aside>

  <!-- ═══════════════ MAIN ═══════════════ -->
  <main class="flex-1 h-full overflow-y-auto">
    <div class="max-w-[1200px] mx-auto p-8 flex flex-col gap-8">

      <!-- Page header -->
      <div class="flex flex-wrap justify-between items-end gap-4">
        <div>
          <h1 class="text-3xl font-black tracking-tight text-slate-900 dark:text-white mb-1">Reports &amp; Analytics</h1>
          <p class="text-slate-500 dark:text-slate-400">Select a subject to view student attendance summary.</p>
        </div>
      </div>

      <!-- ── Subject selector ── -->
      <div class="bg-white dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-700 p-6 shadow-sm">
        <div class="flex items-center gap-2 mb-5">
          <span class="material-symbols-outlined text-primary">tune</span>
          <h3 class="font-bold text-slate-800 dark:text-white">Select Class</h3>
        </div>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">

          <!-- Subject dropdown -->
          <div class="lg:col-span-2">
            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Subject / Semester / Division <span class="text-red-400">*</span></label>
            <div class="relative">
              <select id="class-select" class="w-full appearance-none rounded-xl border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 px-4 pr-10 text-sm focus:border-primary focus:ring-primary">
                <option value="">-- Loading classes... --</option>
              </select>
            </div>
          </div>

          <!-- Search -->
          <div>
            <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Search Student</label>
            <div class="relative">
              <span class="material-symbols-outlined absolute left-3 top-2.5 text-slate-400 text-[20px]">search</span>
              <input type="text" id="search-input" placeholder="Name or Roll No..." class="w-full rounded-xl border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 pl-10 pr-4 text-sm focus:border-primary focus:ring-primary" />
            </div>
          </div>

          <!-- Button -->
          <div class="flex items-end gap-3">
            <button onclick="loadReport()" class="flex-1 h-11 rounded-xl bg-primary hover:bg-primary-dark text-white font-bold text-sm flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md shadow-primary/20">
              <span class="material-symbols-outlined text-[18px]">bar_chart</span> Generate
            </button>
            <button onclick="clearReport()" class="h-11 px-4 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
              <span class="material-symbols-outlined text-[20px]">refresh</span>
            </button>
          </div>
        </div>
      </div>

      <!-- ── Stat cards (hidden until data loads) ── -->
      <div id="stats-row" class="hidden grid grid-cols-2 lg:grid-cols-4 gap-4 fade-in">

        <!-- Total lectures -->
        <div class="flex flex-col gap-1 p-5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-850 shadow-sm relative overflow-hidden">
          <div class="absolute right-2 top-2 opacity-[0.07] pointer-events-none"><span class="material-symbols-outlined text-7xl text-indigo-500">event_note</span></div>
          <div class="flex justify-between items-start">
            <p class="text-slate-500 dark:text-slate-400 text-sm font-medium">Total Lectures</p>
            <span class="material-symbols-outlined text-primary bg-primary/10 p-1 rounded-md text-[20px]">event_note</span>
          </div>
          <p id="stat-lectures" class="text-4xl font-black text-slate-900 dark:text-white mt-2">--</p>
          <p class="text-xs text-slate-400 mt-1">Conducted so far</p>
        </div>

        <!-- Total students -->
        <div class="flex flex-col gap-1 p-5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-850 shadow-sm relative overflow-hidden">
          <div class="absolute right-2 top-2 opacity-[0.07] pointer-events-none"><span class="material-symbols-outlined text-7xl text-blue-500">groups</span></div>
          <div class="flex justify-between items-start">
            <p class="text-slate-500 dark:text-slate-400 text-sm font-medium">Total Students</p>
            <span class="material-symbols-outlined text-blue-500 bg-blue-50 dark:bg-blue-900/20 p-1 rounded-md text-[20px]">groups</span>
          </div>
          <p id="stat-students" class="text-4xl font-black text-slate-900 dark:text-white mt-2">--</p>
          <p class="text-xs text-slate-400 mt-1">In this class</p>
        </div>

        <!-- Safe -->
        <div class="flex flex-col gap-1 p-5 rounded-xl border border-emerald-100 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-900/10 shadow-sm relative overflow-hidden cursor-pointer hover:shadow-md transition-shadow" onclick="applyFilter('safe')">
          <div class="absolute right-2 top-2 opacity-[0.1] pointer-events-none"><span class="material-symbols-outlined text-7xl text-emerald-500">verified</span></div>
          <div class="flex justify-between items-start">
            <p class="text-emerald-700 dark:text-emerald-400 text-sm font-semibold">Safe ≥ 75%</p>
            <span class="material-symbols-outlined text-emerald-600 bg-emerald-100 dark:bg-emerald-900/40 p-1 rounded-md text-[20px]">verified</span>
          </div>
          <p id="stat-safe" class="text-4xl font-black text-emerald-700 dark:text-emerald-400 mt-2">--</p>
          <p class="text-xs text-emerald-500 mt-1">Click to filter</p>
        </div>

        <!-- At risk + Critical combined card with split -->
        <div class="flex flex-col gap-3 p-5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-850 shadow-sm">
          <p class="text-slate-500 dark:text-slate-400 text-sm font-medium">Need Attention</p>
          <div class="flex gap-3">
            <div class="flex-1 p-3 rounded-xl bg-amber-50 dark:bg-amber-900/20 border border-amber-100 dark:border-amber-800 cursor-pointer hover:shadow transition-shadow" onclick="applyFilter('risk')">
              <p class="text-xs font-bold text-amber-600 dark:text-amber-400 mb-1">At Risk</p>
              <p id="stat-risk" class="text-2xl font-black text-amber-600 dark:text-amber-400">--</p>
              <p class="text-[10px] text-amber-500 mt-0.5">60–74%</p>
            </div>
            <div class="flex-1 p-3 rounded-xl bg-rose-50 dark:bg-rose-900/20 border border-rose-100 dark:border-rose-800 cursor-pointer hover:shadow transition-shadow" onclick="applyFilter('critical')">
              <p class="text-xs font-bold text-rose-600 dark:text-rose-400 mb-1">Critical</p>
              <p id="stat-critical" class="text-2xl font-black text-rose-600 dark:text-rose-400">--</p>
              <p class="text-[10px] text-rose-500 mt-0.5">&lt; 60%</p>
            </div>
          </div>
        </div>
      </div>

      <!-- ── Results table ── -->
      <div id="results-panel" class="hidden bg-white dark:bg-slate-850 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden fade-in">

        <!-- Table toolbar -->
        <div class="flex flex-wrap items-center justify-between gap-3 px-6 py-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50/60 dark:bg-slate-800/40">

          <!-- Active filter pill -->
          <div class="flex items-center gap-2 flex-wrap">
            <span class="text-sm text-slate-500 font-medium">Showing:</span>
            <div class="flex items-center gap-1 bg-slate-200 dark:bg-slate-700 p-1 rounded-xl">
              <button id="tab-all" onclick="applyFilter('all')" class="px-3 py-1.5 rounded-lg text-xs font-bold bg-primary text-white transition-all">
                All <span id="badge-all" class="ml-1 bg-white/20 px-1.5 py-0.5 rounded-full"></span>
              </button>
              <button id="tab-safe" onclick="applyFilter('safe')" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-slate-600 transition-all">
                Safe <span id="badge-safe" class="ml-1 bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded-full"></span>
              </button>
              <button id="tab-risk" onclick="applyFilter('risk')" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-slate-600 transition-all">
                At Risk <span id="badge-risk" class="ml-1 bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full"></span>
              </button>
              <button id="tab-critical" onclick="applyFilter('critical')" class="px-3 py-1.5 rounded-lg text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-slate-600 transition-all">
                Critical <span id="badge-critical" class="ml-1 bg-rose-100 text-rose-700 px-1.5 py-0.5 rounded-full"></span>
              </button>
            </div>
            <span id="result-count" class="text-xs text-slate-400 font-medium"></span>
          </div>
        </div>

        <!-- Table -->
        <div class="overflow-x-auto">
          <table class="w-full text-sm">
            <thead>
              <tr class="bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
                <th class="px-6 py-3 text-left w-12">#</th>
                <th class="px-6 py-3 text-left w-28">Roll No</th>
                <th class="px-6 py-3 text-left">Student Name</th>
                <th class="px-6 py-3 text-center">Total Lectures</th>
                <th class="px-6 py-3 text-center">Attended</th>
                <th class="px-6 py-3 text-center">Missed</th>
                <th class="px-6 py-3 text-left w-52">Attendance %</th>
                <th class="px-6 py-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody id="report-tbody" class="divide-y divide-slate-100 dark:divide-slate-800"></tbody>
          </table>
        </div>

        <!-- Empty -->
        <div id="empty-result" class="hidden text-center py-14">
          <span class="material-symbols-outlined text-5xl text-slate-300 dark:text-slate-600 block mb-3">search_off</span>
          <p class="text-slate-400 font-medium">No students found.</p>
        </div>
      </div>

      <!-- Initial empty state -->
      <div id="initial-state" class="text-center py-20">
        <span class="material-symbols-outlined text-7xl text-slate-300 dark:text-slate-600 block mb-4">insert_chart</span>
        <h3 class="text-lg font-bold text-slate-600 dark:text-slate-300 mb-2">Select a Class to Generate Report</h3>
        <p class="text-sm text-slate-400 max-w-xs mx-auto">Choose your subject, semester and division above, then click Generate.</p>
      </div>

      <!-- Loading -->
      <div id="loading-state" class="hidden text-center py-20">
        <div class="inline-block w-10 h-10 border-4 border-primary/30 border-t-primary rounded-full animate-spin mb-4"></div>
        <p class="text-slate-400 font-medium">Generating report...</p>
      </div>

    </div><!-- /max-w -->
  </main>

  <!-- Toast -->
  <div id="toast" class="hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold flex items-center gap-2"></div>

  <script>
    let allClasses = [];
    let allStudents = [];
    let currentCls = null;
    let currentFilter = 'all';
    const avatarColors = ['bg-blue-100 text-blue-700', 'bg-purple-100 text-purple-700', 'bg-amber-100 text-amber-700', 'bg-pink-100 text-pink-700', 'bg-teal-100 text-teal-700', 'bg-indigo-100 text-indigo-700'];

    // ── Load classes ──────────────────────────────────────────────────────────────
    async function loadClasses() {
      try {
        const res = await fetch('../backend/attendance/get_teacher_classes.php');
        const data = await res.json();
        allClasses = data;
        const sel = document.getElementById('class-select');
        sel.innerHTML = data.length ? '<option value="">-- Select a class --</option>' : '<option value="">No classes assigned</option>';
        data.forEach((c, i) => {
          const o = document.createElement('option');
          o.value = i;
          o.textContent = `${c.subject_name}  |  Sem ${c.semester_no}  |  Div ${c.division_name}`;
          sel.appendChild(o);
        });
      } catch (e) {
        toast('Failed to load classes', 'error');
      }
    }

    // ── Load report ───────────────────────────────────────────────────────────────
    async function loadReport() {
      const idx = document.getElementById('class-select').value;
      const search = document.getElementById('search-input').value.trim();
      if (idx === '') {
        toast('Please select a class.', 'error');
        return;
      }

      currentCls = allClasses[+idx];

      hide('initial-state');
      hide('results-panel');
      hide('stats-row');
      show('loading-state');

      try {
        const p = new URLSearchParams({
          subject_id: currentCls.subject_id,
          semester_id: currentCls.semester_id,
          division_id: currentCls.division_id,
          search,
          filter: 'all'
        });
        const res = await fetch('../backend/attendance/get_report.php?' + p);
        const txt = await res.text();
        let data;
        try {
          data = JSON.parse(txt);
        } catch (e) {
          console.error('Raw:', txt);
          toast('Server error. Check console.', 'error');
          hide('loading-state');
          show('initial-state');
          return;
        }
        hide('loading-state');
        if (data.error) {
          toast(data.error, 'error');
          show('initial-state');
          return;
        }

        allStudents = data.students;

        // Stat cards
        document.getElementById('stat-lectures').textContent = data.total_lectures;
        document.getElementById('stat-students').textContent = data.total_students;
        document.getElementById('stat-safe').textContent = data.safe;
        document.getElementById('stat-risk').textContent = data.risk;
        document.getElementById('stat-critical').textContent = data.critical;

        // Badges
        document.getElementById('badge-all').textContent = data.total_students;
        document.getElementById('badge-safe').textContent = data.safe;
        document.getElementById('badge-risk').textContent = data.risk;
        document.getElementById('badge-critical').textContent = data.critical;

        show('stats-row');
        show('results-panel');
        currentFilter = 'all';
        setActiveTab('tab-all');
        renderTable();

      } catch (e) {
        hide('loading-state');
        show('initial-state');
        toast('Error: ' + e.message, 'error');
        console.error(e);
      }
    }

    // ── Render table ──────────────────────────────────────────────────────────────
    function renderTable() {
      const tbody = document.getElementById('report-tbody');
      const filtered = currentFilter === 'all' ?
        allStudents :
        allStudents.filter(s => s.grade === currentFilter);

      document.getElementById('result-count').textContent = filtered.length + ' students';

      if (!filtered.length) {
        tbody.innerHTML = '';
        show('empty-result');
        return;
      }
      hide('empty-result');

      tbody.innerHTML = filtered.map((s, i) => {
        const pct = s.pct;
        const barColor = pct >= 75 ? 'bg-emerald-500' : pct >= 60 ? 'bg-amber-500' : 'bg-rose-500';
        const rowBg = s.grade === 'critical' ? 'bg-rose-50/40 dark:bg-rose-900/5 border-l-4 border-l-rose-400' :
          s.grade === 'risk' ? 'bg-amber-50/40 dark:bg-amber-900/5 border-l-4 border-l-amber-400' :
          'hover:bg-slate-50 dark:hover:bg-slate-800/30';

        const initials = s.student_name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
        const avatarCol = avatarColors[i % avatarColors.length];

        const statusBadge = s.grade === 'safe' ?
          `<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800"><span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>Safe</span>` :
          s.grade === 'risk' ?
          `<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 border border-amber-100 dark:border-amber-800"><span class="w-1.5 h-1.5 rounded-full bg-amber-500"></span>At Risk</span>` :
          `<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 dark:bg-rose-900/30 text-rose-700 dark:text-rose-400 border border-rose-100 dark:border-rose-800"><span class="w-1.5 h-1.5 rounded-full bg-rose-500"></span>Critical</span>`;

        return `
    <tr class="transition-colors ${rowBg}">
      <td class="px-6 py-4 text-xs font-mono text-slate-400">${i + 1}</td>
      <td class="px-6 py-4 text-sm font-mono font-semibold text-slate-600 dark:text-slate-300">${esc(s.roll_no)}</td>
      <td class="px-6 py-4 text-sm">
        <div class="flex items-center gap-3">
          <div class="w-8 h-8 rounded-full ${avatarCol} flex items-center justify-center text-xs font-bold shrink-0">${initials}</div>
          <span class="font-semibold text-slate-800 dark:text-white">${esc(s.student_name)}</span>
        </div>
      </td>
      <td class="px-6 py-4 text-sm text-slate-600 dark:text-slate-400 text-center font-semibold">${s.total_lectures}</td>
      <td class="px-6 py-4 text-sm text-center font-bold text-emerald-600 dark:text-emerald-400">${s.attended}</td>
      <td class="px-6 py-4 text-sm text-center font-bold text-rose-500 dark:text-rose-400">${s.absent_count}</td>
      <td class="px-6 py-4 text-sm">
        <div class="flex items-center gap-2">
          <div class="flex-1 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
            <div class="bar-fill h-full ${barColor} rounded-full" data-w="${pct}"></div>
          </div>
          <span class="text-xs font-bold w-10 text-right ${pct >= 75 ? 'text-emerald-600' : pct >= 60 ? 'text-amber-600' : 'text-rose-500'}">${pct}%</span>
        </div>
      </td>
      <td class="px-6 py-4 text-sm text-center">${statusBadge}</td>
    </tr>`;
      }).join('');

      // Animate bars
      setTimeout(() => {
        document.querySelectorAll('.bar-fill[data-w]').forEach(el => {
          el.style.width = el.dataset.w + '%';
        });
      }, 60);
    }

    // ── Filter ────────────────────────────────────────────────────────────────────
    function applyFilter(filter) {
      currentFilter = filter;
      setActiveTab('tab-' + filter);
      renderTable();
    }

    function setActiveTab(activeId) {
      ['tab-all', 'tab-safe', 'tab-risk', 'tab-critical'].forEach(id => {
        const b = document.getElementById(id);
        b.classList.remove('bg-primary', 'text-white');
        b.classList.add('text-slate-600', 'dark:text-slate-300');
      });
      const a = document.getElementById(activeId);
      a.classList.add('bg-primary', 'text-white');
      a.classList.remove('text-slate-600', 'dark:text-slate-300');
    }

    // ── Clear ─────────────────────────────────────────────────────────────────────
    function clearReport() {
      document.getElementById('class-select').value = '';
      document.getElementById('search-input').value = '';
      allStudents = [];
      currentCls = null;
      hide('results-panel');
      hide('stats-row');
      hide('loading-state');
      show('initial-state');
    }

    // ── Helpers ───────────────────────────────────────────────────────────────────
    function show(id) {
      document.getElementById(id)?.classList.remove('hidden');
    }

    function hide(id) {
      document.getElementById(id)?.classList.add('hidden');
    }

    function esc(s) {
      return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function toast(msg, type) {
      const t = document.getElementById('toast');
      t.innerHTML = (type === 'success' ? '<span class="material-symbols-outlined text-[18px]">check_circle</span>' : '<span class="material-symbols-outlined text-[18px]">error</span>') + msg;
      t.className = `fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold flex items-center gap-2 ${type==='success'?'bg-green-600':'bg-red-500'}`;
      t.classList.remove('hidden');
      setTimeout(() => t.classList.add('hidden'), 3000);
    }

    document.addEventListener('DOMContentLoaded', () => {
      loadClasses();
      document.getElementById('search-input').addEventListener('keydown', e => {
        if (e.key === 'Enter') loadReport();
      });
    });
  </script>
</body>

</html>