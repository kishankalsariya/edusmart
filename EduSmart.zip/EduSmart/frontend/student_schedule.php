<?php

include("../backend/config/connection.php");
include("../backend/auth/auth.php");

if ($_SESSION['role'] !== 'student') {
    header("Location: login.php?error=unauthorized");
    exit();
}

$user_id = $_SESSION['user_id'];

date_default_timezone_set('Asia/Kolkata');


$uq = $conn->prepare("SELECT * FROM users WHERE id = ?");
$uq->bind_param("i", $user_id);
$uq->execute();
$uresult = $uq->get_result();
$user = $uresult->fetch_assoc();

// Get student details
$student_query = "
    SELECT stu.*, c.course_name, sem.semester_no, d.division_name
    FROM students stu
    JOIN courses c ON stu.course_id = c.course_id
    JOIN semesters sem ON stu.semester_id = sem.semester_id
    JOIN divisions d ON stu.division_id = d.division_id
    WHERE stu.user_id = ?
";
$student_stmt = $conn->prepare($student_query);
$student_stmt->bind_param("i", $user_id);
$student_stmt->execute();
$student_result = $student_stmt->get_result();
$student = $student_result->fetch_assoc();

// Get selected day from URL or default to today
$selected_day = isset($_GET['day']) ? $_GET['day'] : date('l');
$valid_days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

// Validate day
if (!in_array($selected_day, $valid_days)) {
    $selected_day = date('l');
}


// Get lectures for selected day

$schedule_query = "
    SELECT 
        s.subject_name,
        TIME_FORMAT(t.start_time, '%h:%i %p') as start_time,
        TIME_FORMAT(t.end_time, '%h:%i %p') as end_time,
        COALESCE(u.name, 'Not Assigned') as teacher_name,
        t.day,
        TIMESTAMPDIFF(MINUTE, CURTIME(), t.start_time) as minutes_until_start,
        TIMESTAMPDIFF(MINUTE, CURTIME(), t.end_time) as minutes_until_end
    FROM students stu
    JOIN division_subject_teacher dst ON 
        dst.semester_id = stu.semester_id 
        AND dst.division_id = stu.division_id
    JOIN timetable t ON dst.dst_id = t.dst_id
    JOIN subjects s ON dst.subject_id = s.subject_id
    LEFT JOIN subject_teacher_assignment sta ON 
        sta.semester_id = dst.semester_id 
        AND sta.division_id = dst.division_id 
        AND sta.subject_id = dst.subject_id
        AND sta.academic_year = ?
        AND sta.status = 'active'
    LEFT JOIN teachers teach ON sta.teacher_id = teach.teacher_id
    LEFT JOIN users u ON teach.user_id = u.id
    WHERE stu.user_id = ?
      AND t.day = ?
    ORDER BY t.start_time
";

$academic_year = date('Y') . '-' . (date('Y') + 1);
$schedule_stmt = $conn->prepare($schedule_query);
$schedule_stmt->bind_param("sis", $academic_year, $user_id, $selected_day);
$schedule_stmt->execute();
$schedule_result = $schedule_stmt->get_result();
$lecture_count = $schedule_result->num_rows;

$is_today1 = ($selected_day === date('l'));

?>


<!DOCTYPE html>
<html class="light" lang="en">

<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>EduSmart - My Weekly Schedule</title>
    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect" />
    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700&amp;display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script id="tailwind-config">
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#2b8cee",
                        "background-light": "#f8fafc",
                        "background-dark": "#101922",
                    },
                    fontFamily: {
                        "display": ["Lexend", "sans-serif"]
                    },
                    borderRadius: {
                        "DEFAULT": "0.25rem",
                        "lg": "0.5rem",
                        "xl": "0.75rem",
                        "2xl": "1rem",
                        "full": "9999px"
                    },
                },
            },
        }
    </script>
    <style type="text/tailwindcss">
        .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #e2e8f0;
            border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #cbd5e1;
        }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #334155;
        }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #475569;
        }
        .sticky-header {
            position: sticky;
            top: 0;
            z-index: 40;
        }
    </style>
</head>

<body class="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 font-display antialiased overflow-hidden">
    <div class="flex h-screen w-full">
        <aside class="hidden md:flex flex-col w-64 h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 shrink-0 z-20 transition-all duration-300">
            <!-- Logo Section -->
            <div class="h-16 flex items-center px-6 border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-center gap-3 mb-8 mt-8">
                    <div class="bg-primary/10 p-2 rounded-xl">
                        <span class="material-symbols-outlined text-primary text-3xl">school</span>
                    </div>
                    <div>
                        <h1 class="text-slate-900 dark:text-white text-xl font-bold leading-tight">
                            EduSmart
                        </h1>
                        <p class="text-slate-500 dark:text-slate-400 text-xs font-medium">
                            Student Portal
                        </p>
                    </div>
                </div>
            </div>


            <!-- Navigation Links -->
            <nav class="flex-1 overflow-y-auto py-4 px-3 flex flex-col gap-1">
                <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors" href="student_dashboard.php">
                    <span class="material-symbols-outlined fill-1">dashboard</span>
                    <span>Dashboard</span>
                </a>
                <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors" href="student_attendance_details.php">
                    <span class="material-symbols-outlined icon-fill">calendar_month</span>
                    <span class="text-sm font-medium leading-normal">Attendance</span>
                </a>
                <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-primary/10 text-primary font-medium transition-colors" href="#">
                    <span class="material-symbols-outlined icon-fill">calendar_today</span>
                    <span class="text-sm font-medium leading-normal">Schedule</span>
                </a>
                <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors" href="student_doubts.php">
                    <span class="material-symbols-outlined fill-current">chat_bubble</span>
                    <span class="text-sm font-medium">Doubts</span>
                </a>
                <div class="mt-auto pt-4 border-t border-slate-300 dark:border-slate-800">
                    <!-- <div class="p-4 border-b border-slate-100 dark:border-slate-800"> -->
                    <a href="student_profile.php">
                        <div class="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
                            <div class="size-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
                                <?= strtoupper(substr($user['name'], 0, 1)) ?>
                            </div>
                            <div class="flex flex-col overflow-hidden">
                                <h3 class="text-sm font-semibold truncate text-slate-900 dark:text-white">
                                    <?= $user['name'] ?>
                                </h3>

                            </div>
                        </div>
                    </a>
                    <!-- </div> -->
                </div>
            </nav>
        </aside>

        <div class="flex-1 overflow-y-auto p-2 md:p-4 scroll-smooth">
            <main class="max-w-[1200px] mx-auto px-4 py-8">

                <!-- Page Heading -->
                <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
                    <div>
                        <h1 class="text-4xl font-black tracking-tight dark:text-white">My Weekly Schedule</h1>
                        <?php if ($student) : ?>
                            <p class="text-[#4c739a] dark:text-slate-400 text-base mt-1 flex items-center gap-2">
                                <span class="material-symbols-outlined text-sm">calendar_today</span>
                                Semester <?php echo $student['semester_no']; ?> -
                                Division <?php echo $student['division_name']; ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>



                <!-- Day Tabs -->
                <div class="mb-8 overflow-x-auto">
                    <div class="flex border-b border-[#cfdbe7] dark:border-slate-800 min-w-max">
                        <?php
                        $days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                        foreach ($days as $day) :
                            $is_today = ($day == date('l'));
                            $is_selected = ($day == $selected_day);

                            $day_abbr = substr($day, 0, 3);
                        ?>
                            <a href="?day=<?php echo $day; ?>" class="flex flex-col items-center justify-center border-b-[3px] px-8 pb-3 pt-2 transition-colors 
                                  <?php echo $is_selected ? 'border-primary text-primary' : 'border-transparent text-[#4c739a] hover:text-primary'; ?>">
                                <p class="text-sm font-bold uppercase tracking-wider"><?php echo $day_abbr; ?></p>
                                <?php if ($is_today) : ?>
                                    <span class="text-[10px] font-bold bg-primary/10 px-2 py-0.5 rounded-full mt-1">TODAY</span>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Schedule Section Header -->
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-xl font-bold dark:text-white"><?php echo $selected_day; ?>'s Lectures</h3>
                    <span class="text-sm text-[#4c739a]">
                        <?php echo $lecture_count; ?> Lecture<?php echo ($lecture_count != 1) ? 's' : ''; ?> Scheduled
                    </span>
                </div>

                <!-- Schedule Content -->
                <div class="grid gap-4">
                    <?php
                    if ($lecture_count > 0) :
                        while ($lecture = $schedule_result->fetch_assoc()) :
                            $is_live =  $is_today1 && ($lecture['minutes_until_start'] <= 0 && $lecture['minutes_until_end'] >= 0);
                            $is_upcoming = $is_today1 && ($lecture['minutes_until_start'] > 0);
                            $is_completed = $is_today1 && ($lecture['minutes_until_end'] < 0);

                            // Card classes
                            $card_class = "flex flex-col md:flex-row items-stretch gap-4 rounded-xl bg-white dark:bg-slate-900 p-5 shadow-sm border transition-all";
                            if ($is_live) {
                                $card_class = "group relative flex flex-col md:flex-row items-stretch gap-4 rounded-xl bg-white dark:bg-slate-900 p-1 border-2 border-primary shadow-lg transition-all";
                            } else {
                                $card_class .= " border-transparent hover:border-[#e7edf3] dark:hover:border-slate-800";
                            }
                    ?>

                            <div class="<?php echo $card_class; ?>">
                                <?php if ($is_live) : ?>
                                    <div class="flex flex-col md:flex-row flex-1 p-4 gap-6">
                                    <?php endif; ?>

                                    <!-- Sidebar Time -->
                                    <div class="flex flex-col items-center justify-center md:border-r border-[#e7edf3] dark:border-slate-800 md:pr-6 md:min-w-[140px]">
                                        <p class="<?php echo $is_live ? 'text-primary' : 'text-[#0d141b] dark:text-slate-200'; ?> text-sm font-bold">
                                            <?php echo $lecture['start_time']; ?>
                                        </p>
                                        <div class="h-8 w-px <?php echo $is_live ? 'bg-primary/20' : 'bg-slate-200 dark:bg-slate-700'; ?> my-1 hidden md:block"></div>
                                        <p class="text-[#4c739a] dark:text-slate-400 text-sm font-medium">
                                            <?php echo $lecture['end_time']; ?>
                                        </p>
                                    </div>

                                    <!-- Lecture Details -->
                                    <div class="flex-1 space-y-2">
                                        <div class="flex flex-wrap items-center gap-2">
                                            <h4 class="text-lg font-bold dark:text-white">
                                                <?php echo htmlspecialchars($lecture['subject_name']); ?>
                                            </h4>
                                            <?php if ($is_live) : ?>
                                                <span class="flex items-center gap-1 rounded-full bg-red-100 text-red-600 px-2.5 py-0.5 text-[10px] font-black uppercase tracking-wider pulse-indicator">
                                                    <span class="h-1.5 w-1.5 rounded-full bg-red-600"></span>
                                                    Live Now
                                                </span>
                                            <?php elseif ($is_upcoming) : ?>
                                                <span class="flex items-center gap-1 rounded-full bg-blue-100 text-blue-600 px-2.5 py-0.5 text-[10px] font-black uppercase tracking-wider">
                                                    Starts in <?php echo $lecture['minutes_until_start']; ?> min
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="flex flex-wrap gap-4 text-sm text-[#4c739a] dark:text-slate-400">
                                            <div class="flex items-center gap-1.5">
                                                <span class="material-symbols-outlined text-base">person</span>
                                                <?php echo htmlspecialchars($lecture['teacher_name']); ?>
                                            </div>
                                            <?php if ($is_live) : ?>
                                                <div class="flex items-center gap-1.5">
                                                    <span class="material-symbols-outlined text-base">timer</span>
                                                    <?php echo abs($lecture['minutes_until_end']); ?> minutes remaining
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <?php if ($is_live) : ?>
                                    </div>
                                <?php endif; ?>
                            </div>

                        <?php
                        endwhile;
                    else :
                        ?>

                        <!-- Empty State -->
                        <div class="flex flex-col items-center justify-center text-center py-16 bg-white dark:bg-slate-900/50 rounded-2xl border-2 border-dashed border-[#e7edf3] dark:border-slate-800">
                            <div class="bg-primary/10 p-6 rounded-full mb-6">
                                <span class="material-symbols-outlined text-6xl text-primary">event_busy</span>
                            </div>
                            <h4 class="text-2xl font-bold mb-2 dark:text-white">No lectures scheduled</h4>
                            <p class="text-[#4c739a] dark:text-slate-400 max-w-sm px-4">
                                Looks like you have a free <?php echo $selected_day; ?>!
                                <?php echo ($selected_day == 'Saturday' || $selected_day == 'Sunday')
                                    ? 'Enjoy your weekend!'
                                    : 'Catch up on some self-study.'; ?>
                            </p>
                        </div>

                    <?php endif; ?>
                </div>

                <!-- Upcoming Days Preview -->
                <div class="mt-12 pt-12 border-t border-[#e7edf3] dark:border-slate-800">
                    <h3 class="text-xl font-bold dark:text-white mb-6">Upcoming This Week</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <?php
                        // Get next 3 days with lectures
                        $upcoming_query = "
                            SELECT DISTINCT t.day, COUNT(*) as lecture_count
                            FROM students stu
                            JOIN division_subject_teacher dst ON dst.semester_id = stu.semester_id 
                                AND dst.division_id = stu.division_id
                            JOIN timetable t ON dst.dst_id = t.dst_id
                            WHERE stu.user_id = ?
                              AND t.day != ?
                              AND FIELD(t.day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday') 
                                  > FIELD(?, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday')
                            GROUP BY t.day
                            ORDER BY FIELD(t.day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday')
                            LIMIT 3
                        ";
                        $upcoming_stmt = $conn->prepare($upcoming_query);
                        $upcoming_stmt->bind_param("iss", $user_id, $selected_day, $selected_day);
                        $upcoming_stmt->execute();
                        $upcoming_result = $upcoming_stmt->get_result();

                        if ($upcoming_result->num_rows > 0) :
                            while ($upcoming = $upcoming_result->fetch_assoc()) :
                        ?>
                                <a href="?day=<?php echo $upcoming['day']; ?>" class="bg-white dark:bg-slate-800 p-4 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-primary transition-colors">
                                    <div class="flex justify-between items-center mb-2">
                                        <h4 class="font-bold dark:text-white"><?php echo $upcoming['day']; ?></h4>
                                        <span class="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                                            <?php echo $upcoming['lecture_count']; ?> lectures
                                        </span>
                                    </div>
                                    <p class="text-sm text-slate-500 dark:text-slate-400">
                                        Click to view schedule
                                    </p>
                                </a>
                            <?php
                            endwhile;
                        else :
                            ?>
                            <div class="col-span-3 text-center py-8 text-slate-500 dark:text-slate-400">
                                No more lectures scheduled for this week
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>

            <footer class="mt-auto py-8 pb-2 text-center text-sm text-[#4c739a] border-t border-[#e7edf3] dark:border-slate-500">
                <p>&copy; <?php echo date('Y'); ?> EduSmart ERP System. Designed for Academic Excellence.</p>
            </footer>
        </div>
    </div>




    <script>
        // setInterval(function() {
        //     if (!document.hidden) {
        //         window.location.reload();
        //     }
        // }, 60000);

        // Highlight current day
        document.addEventListener('DOMContentLoaded', function() {
            const currentDay = '<?php echo date('l'); ?>';
            const selectedDay = '<?php echo $selected_day; ?>';

            // Add active class to selected day
            const dayLinks = document.querySelectorAll('a[href*="day="]');
            dayLinks.forEach(link => {
                if (link.textContent.includes('<?php echo substr($selected_day, 0, 3); ?>')) {
                    link.classList.add('active-day');
                }
            });
        });
    </script>
</body>

</html>