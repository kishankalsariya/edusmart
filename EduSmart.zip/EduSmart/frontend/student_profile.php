<?php
session_start();
include("../backend/config/connection.php");
include("../backend/auth/auth.php");

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'student') {
  header("Location: login.php?error=unauthorized");
  exit();
}

$user_id = $_SESSION['user_id'];

// Fetch user
$uq = $conn->prepare("SELECT * FROM users WHERE id = ?");
$uq->bind_param("i", $user_id);
$uq->execute();
$user = $uq->get_result()->fetch_assoc();

// Fetch student with sem/div
$sq = $conn->prepare("
    SELECT s.*, sem.semester_no, d.division_name
    FROM students s
    JOIN semesters sem ON s.semester_id = sem.semester_id
    JOIN divisions d   ON s.division_id  = d.division_id
    WHERE s.user_id = ?
");
$sq->bind_param("i", $user_id);
$sq->execute();
$student = $sq->get_result()->fetch_assoc();

// Attendance stats
$att_total = 0;
$att_present = 0;
if ($student) {
  $aq = $conn->prepare("SELECT COUNT(*) AS total, SUM(status='present') AS present FROM attendance WHERE student_id=?");
  $aq->bind_param("i", $student['student_id']);
  $aq->execute();
  $att = $aq->get_result()->fetch_assoc();
  $att_total   = (int)$att['total'];
  $att_present = (int)$att['present'];
}
$att_pct = $att_total > 0 ? round(($att_present / $att_total) * 100, 1) : 0;

// Fetch all semesters and divisions for dropdowns
$sems = $conn->query("SELECT semester_id, semester_no FROM semesters ORDER BY semester_no");
$divs = $conn->query("SELECT division_id, division_name FROM divisions ORDER BY division_name");

$initials = strtoupper(substr($user['name'], 0, 1));
?>
<!DOCTYPE html>
<html class="light" lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>EduSmart — My Profile</title>
  <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            primary: "#2b8cee",
            "primary-dark": "#1a6ec0",
            "background-light": "#f6f7f8",
            "background-dark": "#101922"
          },
          fontFamily: {
            display: ["Lexend", "sans-serif"]
          },
          borderRadius: {
            DEFAULT: "0.25rem",
            lg: "0.5rem",
            xl: "0.75rem",
            "2xl": "1rem",
            full: "9999px"
          },
        }
      },
    };
  </script>
  <style>
    body {
      font-family: "Lexend", sans-serif;
    }

    ::-webkit-scrollbar {
      width: 6px
    }

    ::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px
    }

    .dark ::-webkit-scrollbar-thumb {
      background: #334155
    }

    .material-symbols-outlined {
      font-variation-settings: "FILL" 0, "wght" 400, "GRAD" 0, "opsz" 24
    }

    .icon-fill {
      font-variation-settings: "FILL" 1, "wght" 400, "GRAD" 0, "opsz" 24
    }

    /* View/Edit toggle */
    .view-val {
      display: flex;
    }

    .edit-inp {
      display: none;
    }

    .is-editing .view-val {
      display: none;
    }

    .is-editing .edit-inp {
      display: block;
    }
  </style>
</head>

<body class="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 antialiased overflow-hidden">
  <div class="flex h-screen w-full">

    <!-- ═══════════ SIDEBAR ═══════════ -->
    <aside class="hidden md:flex flex-col w-64 h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 shrink-0">
      <div class="h-16 flex items-center px-6 border-b border-slate-100 dark:border-slate-800">
        <div class="flex items-center gap-3 mt-6 mb-6">
          <div class="bg-primary/10 p-2 rounded-xl"><span class="material-symbols-outlined text-primary text-2xl">school</span></div>
          <div>
            <h1 class="text-lg font-bold leading-tight">EduSmart</h1>
            <p class="text-slate-500 text-xs">Student Portal</p>
          </div>
        </div>
      </div>
      <nav class="flex-1 overflow-y-auto py-4 px-3 flex flex-col gap-1">
        <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors text-sm font-medium" href="student_dashboard.php">
          <span class="material-symbols-outlined">dashboard</span>Dashboard
        </a>
        <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors text-sm font-medium" href="student_attendance_details.php">
          <span class="material-symbols-outlined">calendar_month</span>Attendance
        </a>
        <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors text-sm font-medium" href="student_schedule.php">
          <span class="material-symbols-outlined">calendar_today</span>Schedule
        </a>
        <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white transition-colors text-sm font-medium" href="student_doubts.php">
          <span class="material-symbols-outlined">chat_bubble</span>Doubts
        </a>
      </nav>
      <div class="p-4 border-t border-slate-100 dark:border-slate-800">
        <div class="flex items-center gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50">
          <div class="size-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm" id="sidebar-initials"><?= $initials ?></div>
          <div class="overflow-hidden">
            <p class="text-sm font-semibold truncate" id="sidebar-name"><?= htmlspecialchars($user['name']) ?></p>
          </div>
        </div>
        <a href="../backend/users/logout.php" class="flex items-center gap-3 mt-2 px-3 py-2.5 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors text-sm font-medium">
          <span class="material-symbols-outlined">logout</span>Logout
        </a>
      </div>
    </aside>

    <!-- ═══════════ MAIN ═══════════ -->
    <main class="flex-1 flex flex-col h-full overflow-hidden">

      <!-- Mobile header -->
      <header class="md:hidden flex items-center justify-between p-4 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shrink-0">
        <span class="text-lg font-bold">EduSmart</span>
        <div class="size-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-xs"><?= $initials ?></div>
      </header>

      <!-- Scrollable content -->
      <div class="flex-1 overflow-y-auto">
        <div class="max-w-[900px] mx-auto p-4 md:p-8 flex flex-col gap-6">

          <!-- Page heading -->
          <div>
            <h1 class="text-3xl font-black tracking-tight mb-1">My Profile</h1>
            <p class="text-slate-500 dark:text-slate-400">View and update your personal and academic information.</p>
          </div>

          <?php if (!$student) : ?>
            <!-- Profile incomplete banner -->
            <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col md:flex-row shadow-sm">
              <div class="md:w-1/3 bg-primary/10 flex items-center justify-center p-10">
                <div class="size-28 rounded-full bg-white dark:bg-slate-800 shadow-lg flex items-center justify-center">
                  <span class="material-symbols-outlined text-6xl text-primary">person_add</span>
                </div>
              </div>
              <div class="md:w-2/3 p-8 flex flex-col justify-center gap-4">
                <span class="px-2 py-0.5 bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300 text-xs font-bold rounded uppercase tracking-wider w-fit">Profile Incomplete</span>
                <h3 class="text-2xl font-bold">Complete Your Student Identity</h3>
                <p class="text-slate-500 dark:text-slate-400">Your profile is missing academic details like Semester, Division, and Roll Number. Please complete it to access all features.</p>
                <a href="profile_completion_form.php" class="inline-flex items-center gap-2 px-6 h-12 bg-primary text-white rounded-xl font-bold hover:bg-primary-dark transition-all shadow-lg shadow-primary/20 w-fit">
                  <span class="material-symbols-outlined">edit_note</span>Complete Profile
                </a>
              </div>
            </div>

          <?php else : ?>

            <!-- ── Profile Header Card ── -->
            <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
              <!-- Cover gradient -->
              <div class="h-28 bg-gradient-to-r from-blue-500 via-primary to-cyan-400"></div>
              <div class="px-6 pb-6">
                <div class="flex flex-col sm:flex-row gap-4 items-start sm:items-end -mt-12 relative">
                  <!-- Avatar -->
                  <div class="relative">
                    <div class="h-32 w-32 rounded-full border-4 border-white dark:border-slate-900 bg-white dark:bg-slate-800 overflow-hidden shadow-md">
                      <div  id="avatar-initials" style="font-size: 48px;" class="size-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm w-full h-full object-cover">
                        <?= $initials ?>
                      </div>
                    </div>
                  </div>
                  <!-- Name & info -->
                  <div class="flex-1 pb-1 pt-10 sm:pt-0">
                    <h2 class="text-2xl font-black text-slate-900 dark:text-white" id="header-name"><?= htmlspecialchars($user['name']) ?></h2>
                    <p class="text-slate-500 dark:text-slate-400 text-sm font-medium">BSC Information Technology &nbsp;·&nbsp; Sem <?= htmlspecialchars($student['semester_no']) ?> &nbsp;·&nbsp; Div <?= htmlspecialchars($student['division_name']) ?></p>
                  </div>
                  <!-- Edit / Save / Cancel buttons -->
                  <div class="flex items-center gap-2 w-full sm:w-auto">
                    <button id="edit-btn" onclick="startEdit()" class="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary hover:bg-primary-dark text-white font-bold text-sm transition-all shadow-md shadow-primary/20 active:scale-95">
                      <span class="material-symbols-outlined text-[18px]">edit</span>Edit Profile
                    </button>
                    <button id="save-btn" onclick="saveProfile()" style="display:none" class="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm transition-all shadow-md active:scale-95">
                      <span class="material-symbols-outlined text-[18px]">save</span>Save
                    </button>
                    <button id="cancel-btn" onclick="cancelEdit()" style="display:none" class="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                      <span class="material-symbols-outlined text-[18px]">close</span>Cancel
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <!-- ── Stat cards ── -->
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <!-- Roll No -->
              <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm text-center">
                <span class="material-symbols-outlined text-primary text-2xl block mb-1">tag</span>
                <p class="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Roll No</p>
                <p class="text-xl font-black text-slate-900 dark:text-white font-mono"><?= htmlspecialchars($student['roll_no']) ?></p>
              </div>
              <!-- Semester -->
              <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm text-center">
                <span class="material-symbols-outlined text-primary text-2xl block mb-1">calendar_month</span>
                <p class="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Semester</p>
                <p class="text-xl font-black text-slate-900 dark:text-white"><?= htmlspecialchars($student['semester_no']) ?></p>
              </div>
              <!-- Division -->
              <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm text-center">
                <span class="material-symbols-outlined text-primary text-2xl block mb-1">group</span>
                <p class="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Division</p>
                <p class="text-xl font-black text-slate-900 dark:text-white"><?= htmlspecialchars($student['division_name']) ?></p>
              </div>
              <!-- Attendance -->
              <div class="rounded-2xl border p-4 shadow-sm text-center <?= $att_pct >= 75 ? 'bg-emerald-50 dark:bg-emerald-900/20 border-emerald-100 dark:border-emerald-800' : ($att_pct >= 60 ? 'bg-amber-50 dark:bg-amber-900/20 border-amber-100 dark:border-amber-800' : 'bg-rose-50 dark:bg-rose-900/20 border-rose-100 dark:border-rose-800') ?>">
                <span class="material-symbols-outlined text-2xl block mb-1 <?= $att_pct >= 75 ? 'text-emerald-600' : ($att_pct >= 60 ? 'text-amber-600' : 'text-rose-500') ?>">how_to_reg</span>
                <p class="text-xs font-semibold uppercase tracking-wider mb-1 <?= $att_pct >= 75 ? 'text-emerald-600' : ($att_pct >= 60 ? 'text-amber-600' : 'text-rose-500') ?>">Attendance</p>
                <p class="text-xl font-black <?= $att_pct >= 75 ? 'text-emerald-700' : ($att_pct >= 60 ? 'text-amber-700' : 'text-rose-600') ?>"><?= $att_total > 0 ? $att_pct . '%' : '--' ?></p>
              </div>
            </div>

            <!-- ══════════════════════════════════════
           FORM — view & edit modes in one page
      ═══════════════════════════════════════ -->
            <div id="profile-form">

              <!-- ── Section: Personal Information ── -->
              <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden mb-6">
                <div class="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
                  <span class="material-symbols-outlined text-primary">badge</span>
                  <h3 class="font-bold text-slate-900 dark:text-white">Personal Information</h3>
                </div>
                <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">

                  <!-- First Name -->
                  <div class="flex flex-col gap-1.5">
                    <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">First Name <span class="text-red-400">*</span></label>
                    <div class="view-val items-center gap-2 text-slate-800 dark:text-white font-medium py-1"><?= htmlspecialchars($student['first_name']) ?></div>
                    <input class="edit-inp w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 px-4 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20" id="f_first_name" type="text" value="<?= htmlspecialchars($student['first_name']) ?>" placeholder="First name" />
                  </div>

                  <!-- Last Name -->
                  <div class="flex flex-col gap-1.5">
                    <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Last Name <span class="text-red-400">*</span></label>
                    <div class="view-val items-center gap-2 text-slate-800 dark:text-white font-medium py-1"><?= htmlspecialchars($student['last_name']) ?></div>
                    <input class="edit-inp w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 px-4 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20" id="f_last_name" type="text" value="<?= htmlspecialchars($student['last_name']) ?>" placeholder="Last name" />
                  </div>

                  <!-- Email -->
                  <div class="flex flex-col gap-1.5">
                    <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Email Address <span class="text-red-400">*</span></label>
                    <div class="view-val items-center gap-2 text-slate-800 dark:text-white font-medium py-1">
                      <span class="material-symbols-outlined text-[16px] text-slate-400">mail</span><?= htmlspecialchars($user['email']) ?>
                    </div>
                    <input class="edit-inp w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 px-4 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20" id="f_email" type="email" value="<?= htmlspecialchars($user['email']) ?>" placeholder="Email address" />
                  </div>

                  <!-- Phone -->
                  <div class="flex flex-col gap-1.5">
                    <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Phone Number</label>
                    <div class="view-val items-center gap-2 text-slate-800 dark:text-white font-medium py-1">
                      <span class="material-symbols-outlined text-[16px] text-slate-400">call</span>
                      <?= $student['phone'] ? htmlspecialchars($student['phone']) : '<span class="text-slate-400 italic text-sm">Not provided</span>' ?>
                    </div>
                    <input class="edit-inp w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 px-4 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20" id="f_phone" type="tel" value="<?= htmlspecialchars($student['phone'] ?? '') ?>" placeholder="10-digit phone number" maxlength="10" />
                  </div>

                  <!-- Gender -->
                  <div class="flex flex-col gap-1.5">
                    <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Gender</label>
                    <div class="view-val items-center gap-2 text-slate-800 dark:text-white font-medium py-1">
                      <span class="material-symbols-outlined text-[16px] text-slate-400">person</span>
                      <?= $student['gender'] ? htmlspecialchars($student['gender']) : '<span class="text-slate-400 italic text-sm">Not provided</span>' ?>
                    </div>
                    <select class="edit-inp w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 px-4 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20" id="f_gender">
                      <option value="">Select Gender</option>
                      <option value="Male" <?= $student['gender'] === 'Male'   ? 'selected' : '' ?>>Male</option>
                      <option value="Female" <?= $student['gender'] === 'Female' ? 'selected' : '' ?>>Female</option>
                      <option value="Other" <?= $student['gender'] === 'Other'  ? 'selected' : '' ?>>Other</option>
                    </select>
                  </div>

                  <!-- Date of Birth -->
                  <div class="flex flex-col gap-1.5">
                    <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Date of Birth</label>
                    <div class="view-val items-center gap-2 text-slate-800 dark:text-white font-medium py-1">
                      <span class="material-symbols-outlined text-[16px] text-slate-400">cake</span>
                      <?php
                      if ($student['dob']) {
                        $d = new DateTime($student['dob']);
                        echo $d->format('d M Y');
                      } else {
                        echo '<span class="text-slate-400 italic text-sm">Not provided</span>';
                      }
                      ?>
                    </div>
                    <input class="edit-inp w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 px-4 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20" id="f_dob" type="date" value="<?= htmlspecialchars($student['dob'] ?? '') ?>" />
                  </div>

                  <!-- Address (full width) -->
                  <div class="flex flex-col gap-1.5 md:col-span-2">
                    <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Address</label>
                    <div class="view-val items-start gap-2 text-slate-800 dark:text-white font-medium py-1">
                      <span class="material-symbols-outlined text-[16px] text-slate-400 mt-0.5">home</span>
                      <?= $student['address'] ? htmlspecialchars($student['address']) : '<span class="text-slate-400 italic text-sm">Not provided</span>' ?>
                    </div>
                    <textarea class="edit-inp w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-4 py-3 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20 resize-none" id="f_address" rows="3" placeholder="Your full address"><?= htmlspecialchars($student['address'] ?? '') ?></textarea>
                  </div>

                </div>
              </div>

              <!-- ── Section: Academic Information ── -->
              <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden mb-6">
                <div class="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
                  <span class="material-symbols-outlined text-primary">history_edu</span>
                  <h3 class="font-bold text-slate-900 dark:text-white">Academic Information</h3>
                  <!-- Edit mode note -->
                  <span id="academic-edit-note" class="hidden ml-auto text-xs text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20 px-2 py-1 rounded-lg font-medium flex items-center gap-1">
                    <span class="material-symbols-outlined text-[14px]">info</span>
                    Changes here will affect your attendance records
                  </span>
                </div>
                <div class="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">

                  <!-- Roll No -->
                  <div class="flex flex-col gap-1.5">
                    <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Roll Number <span class="text-red-400">*</span></label>
                    <div class="view-val items-center gap-2 text-slate-800 dark:text-white font-medium py-1">
                      <span class="font-mono bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-sm"><?= htmlspecialchars($student['roll_no']) ?></span>
                    </div>
                    <input class="edit-inp w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 px-4 text-sm font-mono focus:border-primary focus:ring-2 focus:ring-primary/20" id="f_roll_no" type="text" value="<?= htmlspecialchars($student['roll_no']) ?>" placeholder="Roll number" />
                  </div>

                  <!-- Course (locked) -->
                  <div class="flex flex-col gap-1.5">
                    <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Course</label>
                    <div class="flex items-center gap-2 h-11 px-4 rounded-xl bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-slate-400 text-sm">
                      <span class="material-symbols-outlined text-[16px]">lock</span>BSC Information Technology
                    </div>
                  </div>

                  <!-- Semester -->
                  <div class="flex flex-col gap-1.5">
                    <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Semester <span class="text-red-400">*</span></label>
                    <div class="view-val items-center gap-2 text-slate-800 dark:text-white font-medium py-1">
                      <span class="material-symbols-outlined text-[16px] text-slate-400">calendar_month</span>Semester <?= htmlspecialchars($student['semester_no']) ?>
                    </div>
                    <select class="edit-inp w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 px-4 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20" id="f_semester_id">
                      <option value="">Select Semester</option>
                      <?php
                      $sems->data_seek(0);
                      while ($sem = $sems->fetch_assoc()) :
                      ?>
                        <option value="<?= $sem['semester_id'] ?>" <?= $student['semester_id'] == $sem['semester_id'] ? 'selected' : '' ?>>
                          Semester <?= $sem['semester_no'] ?>
                        </option>
                      <?php endwhile; ?>
                    </select>
                  </div>

                  <!-- Division -->
                  <div class="flex flex-col gap-1.5">
                    <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Division <span class="text-red-400">*</span></label>
                    <div class="view-val items-center gap-2 text-slate-800 dark:text-white font-medium py-1">
                      <span class="material-symbols-outlined text-[16px] text-slate-400">group</span>Division <?= htmlspecialchars($student['division_name']) ?>
                    </div>
                    <select class="edit-inp w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 px-4 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20" id="f_division_id">
                      <option value="">Select Division</option>
                      <?php
                      $divs->data_seek(0);
                      while ($div = $divs->fetch_assoc()) :
                      ?>
                        <option value="<?= $div['division_id'] ?>" <?= $student['division_id'] == $div['division_id'] ? 'selected' : '' ?>>
                          Division <?= htmlspecialchars($div['division_name']) ?>
                        </option>
                      <?php endwhile; ?>
                    </select>
                  </div>

                </div>
              </div>

              <!-- ── Mobile save/cancel bar (visible only in edit mode) ── -->
              <div id="mobile-action-bar" class="hidden sticky bottom-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 p-4 flex gap-3 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.05)] md:hidden">
                <button onclick="cancelEdit()" class="flex-1 h-11 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 font-semibold text-sm hover:bg-slate-50 transition-colors">Cancel</button>
                <button onclick="saveProfile()" class="flex-1 h-11 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm transition-all active:scale-95 flex items-center justify-center gap-2">
                  <span class="material-symbols-outlined text-[18px]">save</span>Save Changes
                </button>
              </div>

            </div><!-- /profile-form -->

          <?php endif; ?>

          <div class="h-6"></div>
        </div><!-- /max-w -->
      </div><!-- /scroll -->
    </main>
  </div>

  <!-- Toast -->
  <div id="toast" class="hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold flex items-center gap-2"></div>

  <script>
    const originalValues = {
      first_name: <?= json_encode($student['first_name']  ?? '') ?>,
      last_name: <?= json_encode($student['last_name']   ?? '') ?>,
      email: <?= json_encode($user['email']) ?>,
      phone: <?= json_encode($student['phone']       ?? '') ?>,
      gender: <?= json_encode($student['gender']      ?? '') ?>,
      dob: <?= json_encode($student['dob']         ?? '') ?>,
      address: <?= json_encode($student['address']     ?? '') ?>,
      roll_no: <?= json_encode($student['roll_no']     ?? '') ?>,
      semester_id: <?= json_encode((string)($student['semester_id'] ?? '')) ?>,
      division_id: <?= json_encode((string)($student['division_id'] ?? '')) ?>,
    };

    function startEdit() {
      document.getElementById('profile-form').classList.add('is-editing');
      document.getElementById('edit-btn').style.display = 'none';
      document.getElementById('save-btn').style.display = 'flex';
      document.getElementById('cancel-btn').style.display = 'flex';
      document.getElementById('mobile-action-bar').classList.remove('hidden');
      document.getElementById('academic-edit-note').classList.remove('hidden');
    }

    function cancelEdit() {
      // Restore original values
      document.getElementById('f_first_name').value = originalValues.first_name;
      document.getElementById('f_last_name').value = originalValues.last_name;
      document.getElementById('f_email').value = originalValues.email;
      document.getElementById('f_phone').value = originalValues.phone;
      document.getElementById('f_gender').value = originalValues.gender;
      document.getElementById('f_dob').value = originalValues.dob;
      document.getElementById('f_address').value = originalValues.address;
      document.getElementById('f_roll_no').value = originalValues.roll_no;
      document.getElementById('f_semester_id').value = originalValues.semester_id;
      document.getElementById('f_division_id').value = originalValues.division_id;

      document.getElementById('profile-form').classList.remove('is-editing');
      document.getElementById('edit-btn').style.display = 'flex';
      document.getElementById('save-btn').style.display = 'none';
      document.getElementById('cancel-btn').style.display = 'none';
      document.getElementById('mobile-action-bar').classList.add('hidden');
      document.getElementById('academic-edit-note').classList.add('hidden');
    }

    async function saveProfile() {
      const payload = {
        first_name: document.getElementById('f_first_name').value.trim(),
        last_name: document.getElementById('f_last_name').value.trim(),
        email: document.getElementById('f_email').value.trim(),
        phone: document.getElementById('f_phone').value.trim(),
        gender: document.getElementById('f_gender').value,
        dob: document.getElementById('f_dob').value,
        address: document.getElementById('f_address').value.trim(),
        roll_no: document.getElementById('f_roll_no').value.trim(),
        semester_id: document.getElementById('f_semester_id').value,
        division_id: document.getElementById('f_division_id').value,
      };

      // Client-side check
      if (!payload.first_name || !payload.last_name) {
        toast('First name and last name are required.', 'error');
        return;
      }
      if (!payload.email) {
        toast('Email is required.', 'error');
        return;
      }
      if (!payload.roll_no) {
        toast('Roll number is required.', 'error');
        return;
      }
      if (!payload.semester_id || !payload.division_id) {
        toast('Please select semester and division.', 'error');
        return;
      }

      const saveBtn = document.getElementById('save-btn');
      saveBtn.disabled = true;
      saveBtn.innerHTML = '<div class="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>';

      try {
        const res = await fetch('../backend/users/update_student.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(payload)
        });
        const txt = await res.text();
        let data;
        try {
          data = JSON.parse(txt);
        } catch (e) {
          console.error('Raw:', txt);
          toast('Server error. Check console.', 'error');
          return;
        }

        if (!data.success) {
          toast(data.message || 'Update failed.', 'error');
          return;
        }

        // ── Update page UI with new values ────────────────────────────────────────
        const fullName = payload.first_name + ' ' + payload.last_name;
        const newInitials = (payload.first_name[0] + payload.last_name[0]).toUpperCase();

        // Header
        document.getElementById('header-name').textContent = fullName;
        document.getElementById('avatar-initials').textContent = newInitials;
        document.getElementById('sidebar-name').textContent = fullName;
        document.getElementById('sidebar-initials').textContent = newInitials;

        // Update view-val fields (refresh displayed text)
        refreshViewValues(payload);

        // Exit edit mode
        cancelEdit();
        toast('Profile updated successfully!', 'success');

      } catch (e) {
        toast('Network error: ' + e.message, 'error');
        console.error(e);
      }

      saveBtn.disabled = false;
      saveBtn.innerHTML = '<span class="material-symbols-outlined text-[18px]">save</span>Save';
    }

    function refreshViewValues(p) {
      // Re-render view-val text by reloading — simplest approach for PHP-rendered content
      // Just reload the page to show updated data cleanly
      setTimeout(() => {
        window.location.reload();
      }, 800);
    }

    function toast(msg, type) {
      const t = document.getElementById('toast');
      t.innerHTML = (type === 'success' ?
        '<span class="material-symbols-outlined text-[18px]">check_circle</span>' :
        '<span class="material-symbols-outlined text-[18px]">error</span>') + msg;
      t.className = `fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold flex items-center gap-2 ${type==='success'?'bg-green-600':'bg-red-500'}`;
      t.classList.remove('hidden');
      setTimeout(() => t.classList.add('hidden'), type === 'success' ? 3500 : 4000);
    }
  </script>
</body>

</html>