<?php
session_start();

date_default_timezone_set('Asia/Kolkata');

// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    $role = $_SESSION['role'] ?? '';
    if ($role === 'student')     header("Location: student_dashboard.php");
    elseif ($role === 'teacher') header("Location: teacher_dashboard.php");
    elseif ($role === 'admin')   header("Location: admin.php");
    exit();
}
?>
<!DOCTYPE html>
<html class="light" lang="en">

<head>
    <meta charset="utf-8" />
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <title>EduSmart — Forgot Password</title>
    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <script>
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        primary: "#2b8cee",
                        "primary-dark": "#1a6ec0",
                        "background-light": "#f6f7f8",
                        "background-dark": "#101922"
                    },
                    fontFamily: {
                        display: ["Lexend", "sans-serif"]
                    },
                    borderRadius: {
                        DEFAULT: "0.25rem",
                        lg: "0.5rem",
                        xl: "0.75rem",
                        "2xl": "1rem",
                        full: "9999px"
                    },
                }
            },
        };
    </script>
    <style>
        body {
            font-family: "Lexend", sans-serif;
        }

        .material-symbols-outlined {
            font-variation-settings: "FILL" 0, "wght" 400, "GRAD" 0, "opsz" 24;
        }

        /* OTP input group */
        .otp-input {
            width: 48px;
            height: 56px;
            text-align: center;
            font-size: 1.5rem;
            font-weight: 800;
            border-radius: 12px;
            border: 2px solid #e2e8f0;
            background: #f8fafc;
            transition: all .2s;
            caret-color: transparent;
        }

        .otp-input:focus {
            border-color: #2b8cee;
            background: #fff;
            outline: none;
            box-shadow: 0 0 0 3px rgba(43, 140, 238, .15);
        }

        .otp-input.filled {
            border-color: #2b8cee;
            color: #2b8cee;
        }

        .dark .otp-input {
            background: #1e293b;
            border-color: #334155;
            color: #e2e8f0;
        }

        .dark .otp-input:focus {
            background: #0f172a;
            border-color: #2b8cee;
        }

        /* Password strength bar */
        .strength-bar {
            height: 4px;
            border-radius: 2px;
            transition: width .4s, background .4s;
        }

        @keyframes fadeSlide {
            from {
                opacity: 0;
                transform: translateY(10px)
            }

            to {
                opacity: 1;
                transform: translateY(0)
            }
        }

        .step {
            animation: fadeSlide .3s ease;
        }

        /* Stepper */
        .step-circle {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: .8rem;
            transition: all .3s;
        }

        .step-line {
            flex: 1;
            height: 2px;
            transition: background .3s;
        }
    </style>
</head>

<body class="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 min-h-screen flex flex-col items-center justify-center p-4">

    <div class="w-full max-w-md">

        <!-- Logo -->
        <div class="flex flex-col items-center mb-8">
            <div class="w-14 h-14 bg-primary/10 rounded-2xl flex items-center justify-center mb-3">
                <span class="material-symbols-outlined text-primary text-4xl">school</span>
            </div>
            <h1 class="text-2xl font-black text-slate-900 dark:text-white">EduSmart</h1>
            <p class="text-slate-500 text-sm mt-1">Password Recovery</p>
        </div>

        <!-- Stepper -->
        <div class="flex items-center mb-8 px-4">
            <div id="sc1" class="step-circle bg-primary text-white">1</div>
            <div id="sl1" class="step-line bg-slate-200 dark:bg-slate-700 mx-1"></div>
            <div id="sc2" class="step-circle bg-slate-200 dark:bg-slate-700 text-slate-400">2</div>
            <div id="sl2" class="step-line bg-slate-200 dark:bg-slate-700 mx-1"></div>
            <div id="sc3" class="step-circle bg-slate-200 dark:bg-slate-700 text-slate-400">3</div>
            <div class="ml-3 flex flex-col">
                <span id="step-label" class="text-xs font-bold text-primary">Enter Email</span>
                <span id="step-sub" class="text-xs text-slate-400">Step 1 of 3</span>
            </div>
        </div>

        <!-- Card -->
        <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xl overflow-hidden">

            <!-- ═══════ STEP 1: Email ═══════ -->
            <div id="step-1" class="step p-8">
                <h2 class="text-xl font-black mb-1">Forgot your password?</h2>
                <p class="text-slate-500 dark:text-slate-400 text-sm mb-6">Enter your registered email address. We'll send a 6-digit verification code.</p>

                <div class="flex flex-col gap-5">
                    <div class="flex flex-col gap-1.5">
                        <label class="text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider">Email Address</label>
                        <div class="relative">
                            <span class="material-symbols-outlined absolute left-3 top-3 text-slate-400 text-[20px]">mail</span>
                            <input id="inp-email" type="email" autocomplete="off" placeholder="your@email.com" class="w-full h-12 pl-10 pr-4 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all" onkeydown="if(event.key==='Enter') sendOTP()" />
                        </div>
                    </div>

                    <button onclick="sendOTP()" id="btn-send-otp" class="w-full h-12 rounded-xl bg-primary hover:bg-primary-dark text-white font-bold text-sm flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md shadow-primary/20">
                        <span class="material-symbols-outlined text-[18px]">send</span>Send Verification Code
                    </button>

                    <a href="login.php" class="text-center text-sm text-slate-500 hover:text-primary transition-colors flex items-center justify-center gap-1">
                        <span class="material-symbols-outlined text-[16px]">arrow_back</span>Back to Login
                    </a>
                </div>
            </div>

            <!-- ═══════ STEP 2: OTP ═══════ -->
            <div id="step-2" class="step p-8 hidden">
                <h2 class="text-xl font-black mb-1">Enter Verification Code</h2>
                <p class="text-slate-500 dark:text-slate-400 text-sm mb-1">We sent a 6-digit code to</p>
                <p id="display-email" class="text-primary font-bold text-sm mb-6"></p>

                <!-- OTP input boxes -->
                <div class="flex justify-center gap-2 mb-6" id="otp-boxes">
                    <input class="otp-input" type="text" maxlength="1" inputmode="numeric" pattern="[0-9]" id="otp0" onkeyup="otpKey(event,0)" autocomplete="off" />
                    <input class="otp-input" type="text" maxlength="1" inputmode="numeric" pattern="[0-9]" id="otp1" onkeyup="otpKey(event,1)" autocomplete="off" />
                    <input class="otp-input" type="text" maxlength="1" inputmode="numeric" pattern="[0-9]" id="otp2" onkeyup="otpKey(event,2)" autocomplete="off" />
                    <input class="otp-input" type="text" maxlength="1" inputmode="numeric" pattern="[0-9]" id="otp3" onkeyup="otpKey(event,3)" autocomplete="off" />
                    <input class="otp-input" type="text" maxlength="1" inputmode="numeric" pattern="[0-9]" id="otp4" onkeyup="otpKey(event,4)" autocomplete="off" />
                    <input class="otp-input" type="text" maxlength="1" inputmode="numeric" pattern="[0-9]" id="otp5" onkeyup="otpKey(event,5)" autocomplete="off" />
                </div>

                <!-- Timer -->
                <div class="text-center text-sm text-slate-500 mb-6">
                    Code expires in <span id="otp-timer" class="font-bold text-primary">10:00</span>
                </div>

                <!-- Error -->
                <div id="otp-error" class="hidden mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-900/20 border border-rose-200 dark:border-rose-800 text-rose-600 dark:text-rose-400 text-sm flex items-center gap-2">
                    <span class="material-symbols-outlined text-[16px]">error</span>
                    <span id="otp-error-msg"></span>
                </div>

                <div class="flex flex-col gap-3">
                    <button onclick="verifyOTP()" id="btn-verify" class="w-full h-12 rounded-xl bg-primary hover:bg-primary-dark text-white font-bold text-sm flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md shadow-primary/20">
                        <span class="material-symbols-outlined text-[18px]">verified</span>Verify Code
                    </button>
                    <button onclick="resendOTP()" id="btn-resend" class="w-full h-12 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-sm hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors flex items-center justify-center gap-2">
                        <span class="material-symbols-outlined text-[16px]">refresh</span>Resend Code
                    </button>
                    <button onclick="goToStep(1)" class="text-center text-sm text-slate-500 hover:text-primary transition-colors flex items-center justify-center gap-1">
                        <span class="material-symbols-outlined text-[16px]">arrow_back</span>Change Email
                    </button>
                </div>
            </div>

            <!-- ═══════ STEP 3: New Password ═══════ -->
            <div id="step-3" class="step p-8 hidden">
                <h2 class="text-xl font-black mb-1">Set New Password</h2>
                <p class="text-slate-500 dark:text-slate-400 text-sm mb-6">Choose a strong password for your account.</p>

                <div class="flex flex-col gap-5">

                    <!-- New Password -->
                    <div class="flex flex-col gap-1.5">
                        <label class="text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider">New Password</label>
                        <div class="relative">
                            <span class="material-symbols-outlined absolute left-3 top-3 text-slate-400 text-[20px]">lock</span>
                            <input id="inp-password" type="password" placeholder="Minimum 6 characters" class="w-full h-12 pl-10 pr-12 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all" oninput="checkStrength(this.value)" />
                            <button type="button" onclick="togglePwd('inp-password',this)" class="absolute right-3 top-3 text-slate-400 hover:text-slate-600 transition-colors">
                                <span class="material-symbols-outlined text-[20px]">visibility</span>
                            </button>
                        </div>
                        <!-- Strength bar -->
                        <div class="h-1.5 w-full bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden mt-1">
                            <div id="strength-bar" class="strength-bar h-full w-0 bg-slate-300"></div>
                        </div>
                        <p id="strength-label" class="text-xs text-slate-400 font-medium"></p>
                    </div>

                    <!-- Confirm Password -->
                    <div class="flex flex-col gap-1.5">
                        <label class="text-xs font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider">Confirm Password</label>
                        <div class="relative">
                            <span class="material-symbols-outlined absolute left-3 top-3 text-slate-400 text-[20px]">lock_reset</span>
                            <input id="inp-confirm" type="password" placeholder="Re-enter password" class="w-full h-12 pl-10 pr-12 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all" onkeydown="if(event.key==='Enter') resetPassword()" />
                            <button type="button" onclick="togglePwd('inp-confirm',this)" class="absolute right-3 top-3 text-slate-400 hover:text-slate-600 transition-colors">
                                <span class="material-symbols-outlined text-[20px]">visibility</span>
                            </button>
                        </div>
                        <!-- Match indicator -->
                        <p id="match-label" class="text-xs font-medium hidden"></p>
                    </div>

                    <!-- Error -->
                    <div id="pwd-error" class="hidden p-3 rounded-xl bg-rose-50 dark:bg-rose-900/20 border border-rose-200 dark:border-rose-800 text-rose-600 dark:text-rose-400 text-sm flex items-center gap-2">
                        <span class="material-symbols-outlined text-[16px]">error</span>
                        <span id="pwd-error-msg"></span>
                    </div>

                    <button onclick="resetPassword()" id="btn-reset" class="w-full h-12 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md">
                        <span class="material-symbols-outlined text-[18px]">lock_reset</span>Update Password
                    </button>
                </div>
            </div>

            <!-- ═══════ STEP 4: Success ═══════ -->
            <div id="step-4" class="step p-8 hidden text-center">
                <div class="w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mx-auto mb-5">
                    <span class="material-symbols-outlined text-5xl text-emerald-600 dark:text-emerald-400">check_circle</span>
                </div>
                <h2 class="text-xl font-black mb-2 text-emerald-700 dark:text-emerald-400">Password Updated!</h2>
                <p class="text-slate-500 dark:text-slate-400 text-sm mb-8">Your password has been reset successfully. You can now log in with your new password.</p>
                <a href="login.php" class="inline-flex items-center justify-center gap-2 w-full h-12 rounded-xl bg-primary hover:bg-primary-dark text-white font-bold text-sm transition-all active:scale-95 shadow-md shadow-primary/20">
                    <span class="material-symbols-outlined text-[18px]">login</span>Go to Login
                </a>
            </div>

        </div><!-- /card -->
    </div><!-- /max-w -->

    <!-- Loading overlay -->
    <div id="loading-overlay" class="hidden fixed inset-0 bg-black/20 dark:bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
        <div class="bg-white dark:bg-slate-900 rounded-2xl p-6 flex items-center gap-4 shadow-2xl">
            <div class="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin"></div>
            <span id="loading-msg" class="font-semibold text-slate-700 dark:text-white text-sm">Please wait...</span>
        </div>
    </div>

    <script>
        let currentEmail = '';
        let timerInterval = null;

        // ── Step navigation ───────────────────────────────────────────────────────────
        function goToStep(n) {
            [1, 2, 3, 4].forEach(i => {
                document.getElementById('step-' + i).classList.add('hidden');
            });
            document.getElementById('step-' + n).classList.remove('hidden');
            updateStepper(n);
            if (n === 2) {
                document.getElementById('otp0').focus();
                startTimer(10 * 60); // 10 minutes
            }
            if (n === 1 && timerInterval) {
                clearInterval(timerInterval);
            }
        }

        function updateStepper(n) {
            const labels = ['', 'Enter Email', 'Verify Code', 'New Password'];
            const subs = ['', 'Step 1 of 3', 'Step 2 of 3', 'Step 3 of 3'];
            document.getElementById('step-label').textContent = n <= 3 ? labels[n] : 'Done';
            document.getElementById('step-sub').textContent = n <= 3 ? subs[n] : 'Complete';

            [1, 2, 3].forEach(i => {
                const circle = document.getElementById('sc' + i);
                if (i < n) {
                    circle.className = 'step-circle bg-emerald-500 text-white';
                    circle.innerHTML = '<span class="material-symbols-outlined text-[16px]">check</span>';
                } else if (i === n) {
                    circle.className = 'step-circle bg-primary text-white';
                    circle.textContent = i;
                } else {
                    circle.className = 'step-circle bg-slate-200 dark:bg-slate-700 text-slate-400';
                    circle.textContent = i;
                }
                if (i < 3) {
                    document.getElementById('sl' + i).style.background = i < n ? '#22c55e' : '';
                }
            });
        }

        // ── Step 1: Send OTP ──────────────────────────────────────────────────────────
        async function sendOTP() {
            const email = document.getElementById('inp-email').value.trim();
            if (!email) {
                showToast('Please enter your email address.', 'error');
                return;
            }
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                showToast('Please enter a valid email.', 'error');
                return;
            }

            currentEmail = email;
            showLoading('Sending verification code...');

            try {
                const res = await fetch('../backend/users/send_otp.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        email
                    })
                });
                const data = await res.json();
                hideLoading();

                if (!data.success) {
                    showToast(data.message, 'error');
                    return;
                }

                document.getElementById('display-email').textContent = email;
                // Clear OTP boxes
                for (let i = 0; i < 6; i++) {
                    document.getElementById('otp' + i).value = '';
                    document.getElementById('otp' + i).classList.remove('filled');
                }
                document.getElementById('otp-error').classList.add('hidden');
                goToStep(2);

            } catch (e) {
                hideLoading();
                showToast('Network error. Please try again.', 'error');
            }
        }

        // ── OTP box keyboard handling ─────────────────────────────────────────────────
        function otpKey(e, idx) {
            const boxes = Array.from({
                length: 6
            }, (_, i) => document.getElementById('otp' + i));
            const val = e.target.value;

            // Only allow digits
            e.target.value = val.replace(/[^0-9]/g, '');
            e.target.classList.toggle('filled', e.target.value !== '');

            if (e.key === 'Backspace') {
                if (!e.target.value && idx > 0) boxes[idx - 1].focus();
                return;
            }
            if (e.target.value && idx < 5) boxes[idx + 1].focus();
            if (idx === 5 && e.target.value) verifyOTP(); // auto-verify on last digit
        }

        // Paste handling for OTP
        document.addEventListener('DOMContentLoaded', () => {
            for (let i = 0; i < 6; i++) {
                document.getElementById('otp' + i).addEventListener('paste', e => {
                    e.preventDefault();
                    const pasted = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '');
                    pasted.split('').slice(0, 6).forEach((ch, j) => {
                        const box = document.getElementById('otp' + j);
                        box.value = ch;
                        box.classList.add('filled');
                    });
                    const last = Math.min(pasted.length, 5);
                    document.getElementById('otp' + last).focus();
                    if (pasted.length === 6) verifyOTP();
                });
            }

            // Check password match on confirm input
            document.getElementById('inp-confirm').addEventListener('input', () => {
                const pwd = document.getElementById('inp-password').value;
                const cfm = document.getElementById('inp-confirm').value;
                const lbl = document.getElementById('match-label');
                if (!cfm) {
                    lbl.classList.add('hidden');
                    return;
                }
                lbl.classList.remove('hidden');
                if (pwd === cfm) {
                    lbl.textContent = '✓ Passwords match';
                    lbl.className = 'text-xs font-medium text-emerald-600 dark:text-emerald-400';
                } else {
                    lbl.textContent = '✗ Passwords do not match';
                    lbl.className = 'text-xs font-medium text-rose-500';
                }
            });
        });

        // ── Step 2: Verify OTP ────────────────────────────────────────────────────────
        async function verifyOTP() {
            const otp = Array.from({
                length: 6
            }, (_, i) => document.getElementById('otp' + i).value).join('');
            if (otp.length < 6) {
                showOTPError('Please enter all 6 digits.');
                return;
            }

            document.getElementById('otp-error').classList.add('hidden');
            showLoading('Verifying code...');

            try {
                const res = await fetch('../backend/users/verify_otp.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        email: currentEmail,
                        otp
                    })
                });
                const data = await res.json();
                hideLoading();

                if (!data.success) {
                    showOTPError(data.message);
                    return;
                }

                clearInterval(timerInterval);
                goToStep(3);
                document.getElementById('inp-password').focus();

            } catch (e) {
                hideLoading();
                showOTPError('Network error. Please try again.');
            }
        }

        function showOTPError(msg) {
            document.getElementById('otp-error-msg').textContent = msg;
            document.getElementById('otp-error').classList.remove('hidden');
            // Shake OTP boxes
            const boxes = document.getElementById('otp-boxes');
            boxes.style.animation = 'none';
            setTimeout(() => {
                boxes.style.animation = 'shake .4s ease';
            }, 10);
        }

        // ── Resend OTP ────────────────────────────────────────────────────────────────
        async function resendOTP() {
            clearInterval(timerInterval);
            for (let i = 0; i < 6; i++) {
                document.getElementById('otp' + i).value = '';
                document.getElementById('otp' + i).classList.remove('filled');
            }
            document.getElementById('otp-error').classList.add('hidden');
            await sendOTP();
            // sendOTP calls goToStep(2) which restarts timer
        }

        // ── Timer ─────────────────────────────────────────────────────────────────────
        function startTimer(seconds) {
            if (timerInterval) clearInterval(timerInterval);
            const display = document.getElementById('otp-timer');
            let remaining = seconds;
            display.style.color = '';

            timerInterval = setInterval(() => {
                remaining--;
                const m = Math.floor(remaining / 60);
                const s = remaining % 60;
                display.textContent = m + ':' + String(s).padStart(2, '0');

                if (remaining <= 60) display.style.color = '#ef4444';
                if (remaining <= 0) {
                    clearInterval(timerInterval);
                    display.textContent = 'Expired';
                    showOTPError('Code expired. Please request a new one.');
                }
            }, 1000);
        }

        // ── Step 3: Reset Password ────────────────────────────────────────────────────
        async function resetPassword() {
            const password = document.getElementById('inp-password').value;
            const confirm = document.getElementById('inp-confirm').value;

            document.getElementById('pwd-error').classList.add('hidden');

            if (password.length < 6) {
                showPwdError('Password must be at least 6 characters.');
                return;
            }
            if (password !== confirm) {
                showPwdError('Passwords do not match.');
                return;
            }

            showLoading('Updating password...');

            try {
                const res = await fetch('../backend/users/reset_password.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        password,
                        confirm
                    })
                });
                const data = await res.json();
                hideLoading();

                if (!data.success) {
                    showPwdError(data.message);
                    return;
                }

                // Show success step
                document.getElementById('step-3').classList.add('hidden');
                document.getElementById('step-4').classList.remove('hidden');
                document.getElementById('step-label').textContent = 'Complete';
                document.getElementById('step-sub').textContent = 'Done!';
                [1, 2, 3].forEach(i => {
                    const c = document.getElementById('sc' + i);
                    c.className = 'step-circle bg-emerald-500 text-white';
                    c.innerHTML = '<span class="material-symbols-outlined text-[16px]">check</span>';
                });

            } catch (e) {
                hideLoading();
                showPwdError('Network error. Please try again.');
            }
        }

        function showPwdError(msg) {
            document.getElementById('pwd-error-msg').textContent = msg;
            document.getElementById('pwd-error').classList.remove('hidden');
        }

        // ── Password strength checker ─────────────────────────────────────────────────
        function checkStrength(val) {
            const bar = document.getElementById('strength-bar');
            const label = document.getElementById('strength-label');
            let score = 0;
            if (val.length >= 6) score++;
            if (val.length >= 10) score++;
            if (/[A-Z]/.test(val)) score++;
            if (/[0-9]/.test(val)) score++;
            if (/[^A-Za-z0-9]/.test(val)) score++;

            const configs = [{
                    w: '0%',
                    color: 'bg-slate-300',
                    text: '',
                    tc: ''
                },
                {
                    w: '20%',
                    color: 'bg-rose-500',
                    text: 'Very Weak',
                    tc: 'text-rose-500'
                },
                {
                    w: '40%',
                    color: 'bg-amber-500',
                    text: 'Weak',
                    tc: 'text-amber-500'
                },
                {
                    w: '60%',
                    color: 'bg-yellow-400',
                    text: 'Fair',
                    tc: 'text-yellow-500'
                },
                {
                    w: '80%',
                    color: 'bg-blue-500',
                    text: 'Strong',
                    tc: 'text-blue-500'
                },
                {
                    w: '100%',
                    color: 'bg-emerald-500',
                    text: 'Very Strong',
                    tc: 'text-emerald-600'
                },
            ];
            const cfg = configs[score] || configs[0];
            bar.style.width = cfg.w;
            bar.className = 'strength-bar h-full ' + cfg.color;
            label.textContent = cfg.text;
            label.className = 'text-xs font-medium ' + cfg.tc;
        }

        // ── Toggle password visibility ────────────────────────────────────────────────
        function togglePwd(inputId, btn) {
            const inp = document.getElementById(inputId);
            const isText = inp.type === 'text';
            inp.type = isText ? 'password' : 'text';
            btn.querySelector('.material-symbols-outlined').textContent = isText ? 'visibility' : 'visibility_off';
        }

        // ── Loading overlay ───────────────────────────────────────────────────────────
        function showLoading(msg) {
            document.getElementById('loading-msg').textContent = msg || 'Please wait...';
            document.getElementById('loading-overlay').classList.remove('hidden');
        }

        function hideLoading() {
            document.getElementById('loading-overlay').classList.add('hidden');
        }

        // ── Toast ─────────────────────────────────────────────────────────────────────
        function showToast(msg, type) {
            // Create toast dynamically
            const existing = document.getElementById('toast-popup');
            if (existing) existing.remove();
            const t = document.createElement('div');
            t.id = 'toast-popup';
            t.className = `fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold flex items-center gap-2 ${type==='success'?'bg-green-600':'bg-red-500'}`;
            t.innerHTML = `<span class="material-symbols-outlined text-[18px]">${type==='success'?'check_circle':'error'}</span>${msg}`;
            document.body.appendChild(t);
            setTimeout(() => t.remove(), 3500);
        }
    </script>
</body>

</html>