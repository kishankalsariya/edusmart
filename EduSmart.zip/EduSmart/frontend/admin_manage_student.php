<?php
include("../backend/config/connection.php");
include("../backend/auth/auth.php");

if ($_SESSION['role'] !== 'admin') {
  header("Location: login.php?error=unauthorized");
  exit();
}

$today        = date('Y-m-d');
$academic_year = date('Y') . '-' . (date('Y') + 1);

// ── Filters ───────────────────────────────────────────────────────────────────
$search        = trim($_GET['search']   ?? '');
$filter_sem    = (int)($_GET['semester'] ?? 0);
$filter_div    = (int)($_GET['division'] ?? 0);
$filter_status = trim($_GET['filter']   ?? '');  // '' | 'low' | 'critical'

// ── Semesters + Divisions for dropdowns ───────────────────────────────────────
$semesters = $conn->query("SELECT semester_id, semester_no FROM semesters ORDER BY semester_no")->fetch_all(MYSQLI_ASSOC);
$divisions = $conn->query("SELECT division_id, division_name FROM divisions ORDER BY division_name")->fetch_all(MYSQLI_ASSOC);

// ── Fetch all students with attendance % ──────────────────────────────────────
$sql = "
    SELECT
        s.student_id,
        s.roll_no,
        s.gender,
        u.id   AS user_id,
        u.name,
        u.email,
        sem.semester_id,
        sem.semester_no,
        d.division_id,
        d.division_name,
        COUNT(a.attendance_id)        AS total_classes,
        SUM(a.status = 'present')     AS attended,
        CASE
            WHEN COUNT(a.attendance_id) = 0 THEN NULL
            ELSE ROUND(SUM(a.status='present') / COUNT(a.attendance_id) * 100, 1)
        END AS pct
    FROM students s
    JOIN users u       ON s.user_id     = u.id
    JOIN semesters sem ON s.semester_id = sem.semester_id
    JOIN divisions d   ON s.division_id  = d.division_id
    LEFT JOIN attendance a ON a.student_id = s.student_id
    WHERE 1=1
";
$params = [];
$types = '';

if ($filter_sem) {
  $sql .= " AND s.semester_id = ?";
  $types .= "i";
  $params[] = $filter_sem;
}
if ($filter_div) {
  $sql .= " AND s.division_id  = ?";
  $types .= "i";
  $params[] = $filter_div;
}
if ($search !== '') {
  $like   = '%' . $search . '%';
  $sql   .= " AND (u.name LIKE ? OR u.email LIKE ? OR s.roll_no LIKE ?)";
  $types .= "sss";
  $params[] = $like;
  $params[] = $like;
  $params[] = $like;
}
$sql .= " GROUP BY s.student_id, s.roll_no, s.gender, u.id, u.name, u.email, sem.semester_id, sem.semester_no, d.division_id, d.division_name ORDER BY sem.semester_no, d.division_name, CAST(s.roll_no AS UNSIGNED)";

$stmt = $conn->prepare($sql);
$all_students = [];
if ($stmt) {
  if ($types) $stmt->bind_param($types, ...$params);
  $stmt->execute();
  $all_students = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
  $stmt->close();
}

// Apply attendance status filter
if ($filter_status === 'low') {
  $all_students = array_values(array_filter($all_students, fn ($s) => $s['pct'] !== null && $s['pct'] < 75));
}
if ($filter_status === 'critical') {
  $all_students = array_values(array_filter($all_students, fn ($s) => $s['pct'] !== null && $s['pct'] < 60));
}

// ── Summary stats (always from full unfiltered count) ─────────────────────────
$total_students = (int)$conn->query("SELECT COUNT(*) AS c FROM students")->fetch_assoc()['c'];
$low_count      = 0;
$critical_count = 0;
$pct_sum = 0;
$pct_count = 0;
$all_q = $conn->query("
    SELECT ROUND(SUM(a.status='present')/COUNT(a.attendance_id)*100,1) AS pct
    FROM students s LEFT JOIN attendance a ON a.student_id=s.student_id
    GROUP BY s.student_id HAVING COUNT(a.attendance_id) > 0
");
if ($all_q) {
  while ($r = $all_q->fetch_assoc()) {
    $p = (float)$r['pct'];
    $pct_sum += $p;
    $pct_count++;
    if ($p < 75) $low_count++;
    if ($p < 60) $critical_count++;
  }
}
$avg_att = $pct_count > 0 ? round($pct_sum / $pct_count, 1) : null;

$av_colors = ['bg-blue-100 text-blue-700', 'bg-purple-100 text-purple-700', 'bg-emerald-100 text-emerald-700', 'bg-amber-100 text-amber-700', 'bg-rose-100 text-rose-700', 'bg-teal-100 text-teal-700'];
?>
<!DOCTYPE html>
<html class="light" lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>EduSmart — Manage Students</title>
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet" />
  <script>
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            primary: "#2b8cee",
            "primary-dark": "#1a6ec0",
            "background-light": "#f6f7f8",
            "background-dark": "#101922",
            "surface-light": "#ffffff",
            "surface-dark": "#1a2632"
          },
          fontFamily: {
            display: ["Lexend", "sans-serif"]
          },
          borderRadius: {
            DEFAULT: "0.25rem",
            lg: "0.5rem",
            xl: "0.75rem",
            "2xl": "1rem",
            full: "9999px"
          }
        }
      }
    };
  </script>
  <style>
    body {
      font-family: "Lexend", sans-serif
    }

    ::-webkit-scrollbar {
      width: 6px;
      height: 6px
    }

    ::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px
    }

    .dark ::-webkit-scrollbar-thumb {
      background: #334155
    }

    .material-symbols-outlined {
      font-variation-settings: "FILL" 0, "wght" 400, "GRAD" 0, "opsz" 24
    }

    .fill {
      font-variation-settings: "FILL" 1, "wght" 400, "GRAD" 0, "opsz" 24
    }
  </style>
</head>

<body class="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 font-display h-screen overflow-hidden flex">

  <!-- SIDEBAR -->
  <aside class="hidden lg:flex w-64 flex-col bg-surface-light dark:bg-surface-dark border-r border-slate-200 dark:border-slate-700 flex-shrink-0">
    <div class="flex items-center gap-3 px-6 py-5 border-b border-slate-100 dark:border-slate-800">
      <div class="size-9 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
        <span class="material-symbols-outlined fill">school</span>
      </div>
      <div>
        <h1 class="text-lg font-bold leading-tight">EduSmart</h1>
        <p class="text-slate-500 text-xs">Admin Panel</p>
      </div>
    </div>
    <nav class="flex-1 overflow-y-auto px-3 py-4 flex flex-col gap-1">
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-primary transition-colors" href="admin.php">
        <span class="material-symbols-outlined">dashboard</span><span class="text-sm font-medium">Dashboard</span>
      </a>
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-primary transition-colors" href="admin_manage_teacher.php">
        <span class="material-symbols-outlined">supervisor_account</span><span class="text-sm font-medium">Manage Teachers</span>
      </a>
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-primary/10 text-primary font-semibold" href="#">
        <span class="material-symbols-outlined fill">groups</span><span class="text-sm">Manage Students</span>
      </a>
      <a class="flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-primary transition-colors" href="admin_assign_teacher.php">
        <span class="material-symbols-outlined">assignment_ind</span><span class="text-sm font-medium">Assign Teachers</span>
      </a>
    </nav>
    <div class="px-4 py-4 border-t border-slate-100 dark:border-slate-800">
      <div class="bg-primary/5 dark:bg-slate-800 rounded-xl p-4 border border-primary/10">
        <div class="flex items-center gap-2 mb-2">
          <span class="material-symbols-outlined text-primary text-[20px]">support_agent</span>
          <p class="font-bold text-sm">Need Help?</p>
        </div>
        <p class="text-xs text-slate-500 dark:text-slate-400 mb-3">Contact the engineering team for system support.</p>
        <button class="w-full py-2 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded-lg text-xs font-bold text-slate-700 dark:text-slate-200">Contact Support</button>
      </div>
    </div>
  </aside>

  <!-- MAIN WRAPPER -->
  <div class="flex-1 flex flex-col h-full overflow-hidden">

    <!-- Top Nav -->
    <header class="h-16 flex items-center justify-between px-6 border-b border-slate-200 dark:border-slate-700 bg-surface-light dark:bg-surface-dark shrink-0">
      <h2 class="text-xl font-bold tracking-tight hidden lg:block">Manage Students</h2>
      <div class="flex lg:hidden items-center gap-3">
        <span class="material-symbols-outlined fill text-primary">school</span>
        <span class="text-lg font-bold">EduSmart</span>
      </div>
      <div class="flex items-center gap-3">
        <a href="../backend/users/logout.php" class="flex items-center gap-2 h-9 px-4 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors text-sm font-semibold">
          <span class="material-symbols-outlined text-[18px]">logout</span><span class="hidden md:inline">Logout</span>
        </a>
      </div>
    </header>

    <!-- Scrollable Content -->
    <main class="flex-1 overflow-y-auto bg-background-light dark:bg-background-dark p-4 lg:p-8">
      <div class="max-w-[1300px] mx-auto flex flex-col gap-6">

        <!-- STAT CARDS -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">

          <div class="bg-surface-light dark:bg-surface-dark p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="flex justify-between items-start mb-3">
              <p class="text-slate-500 text-sm font-medium">Total Students</p>
              <span class="material-symbols-outlined text-primary bg-primary/10 p-1 rounded-lg text-[20px]">groups</span>
            </div>
            <h3 class="text-3xl font-black text-slate-900 dark:text-white"><?= $total_students ?></h3>
            <p class="text-xs text-slate-400 mt-2">Enrolled in system</p>
          </div>

          <div class="bg-surface-light dark:bg-surface-dark p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="flex justify-between items-start mb-3">
              <p class="text-slate-500 text-sm font-medium">Avg Attendance</p>
              <span class="material-symbols-outlined text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 p-1 rounded-lg text-[20px]">fact_check</span>
            </div>
            <h3 class="text-3xl font-black <?= $avg_att === null ? 'text-slate-400' : ($avg_att >= 75 ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600') ?>">
              <?= $avg_att !== null ? $avg_att . '%' : '--' ?>
            </h3>
            <p class="text-xs text-slate-400 mt-2">Overall average</p>
          </div>

          <div class="<?= $low_count > 0 ? 'bg-amber-50 dark:bg-amber-900/10 border-amber-200 dark:border-amber-800' : 'bg-surface-light dark:bg-surface-dark border-slate-200 dark:border-slate-700' ?> p-5 rounded-2xl border shadow-sm cursor-pointer" onclick="setFilter('low')">
            <div class="flex justify-between items-start mb-3">
              <p class="<?= $low_count > 0 ? 'text-amber-600' : 'text-slate-500' ?> text-sm font-medium">At Risk (&lt;75%)</p>
              <span class="material-symbols-outlined text-amber-600 bg-amber-50 dark:bg-amber-900/20 p-1 rounded-lg text-[20px]">warning</span>
            </div>
            <h3 class="text-3xl font-black <?= $low_count > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-400' ?>"><?= $low_count ?></h3>
            <p class="text-xs <?= $low_count > 0 ? 'text-amber-500' : 'text-slate-400' ?> mt-2">Click to filter</p>
          </div>

          <div class="<?= $critical_count > 0 ? 'bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-800' : 'bg-surface-light dark:bg-surface-dark border-slate-200 dark:border-slate-700' ?> p-5 rounded-2xl border shadow-sm cursor-pointer" onclick="setFilter('critical')">
            <div class="flex justify-between items-start mb-3">
              <p class="<?= $critical_count > 0 ? 'text-red-600' : 'text-slate-500' ?> text-sm font-medium">Critical (&lt;60%)</p>
              <span class="material-symbols-outlined text-red-600 bg-red-50 dark:bg-red-900/20 p-1 rounded-lg text-[20px]">notification_important</span>
            </div>
            <h3 class="text-3xl font-black <?= $critical_count > 0 ? 'text-red-600 dark:text-red-400' : 'text-slate-400' ?>"><?= $critical_count ?></h3>
            <p class="text-xs <?= $critical_count > 0 ? 'text-red-500' : 'text-slate-400' ?> mt-2">Click to filter</p>
          </div>
        </div>

        <!-- FILTER & SEARCH -->
        <div class="bg-surface-light dark:bg-surface-dark rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm p-5">
          
        <form method="GET" class="flex flex-col md:flex-row flex-wrap gap-4 items-end">

            <!-- Search -->
            <div class="flex flex-col w-full md:flex-[2] gap-1.5">
              <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Search</label>
              <div class="relative">
                <span class="material-symbols-outlined absolute left-3 top-2.5 text-slate-400 text-[20px]">search</span>
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Name, email or roll no..." id="search-input" autocomplete="off" class="w-full pl-10 pr-4 h-11 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none transition-all" />
              </div>
            </div>

            <!-- Semester -->
            <div class="flex flex-col w-full md:w-44 gap-1.5">
              <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Semester</label>
              <div class="relative">
                <select name="semester" class="w-full h-11 px-4 pr-10 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none appearance-none">
                  <option value="0">All Semesters</option>
                  <?php foreach ($semesters as $sem) : ?>
                    <option value="<?= $sem['semester_id'] ?>" <?= $filter_sem == $sem['semester_id'] ? 'selected' : '' ?>>Semester <?= $sem['semester_no'] ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>

            <!-- Division -->
            <div class="flex flex-col w-full md:w-44 gap-1.5">
              <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Division</label>
              <div class="relative">
                <select name="division" class="w-full h-11 px-4 pr-10 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none appearance-none">
                  <option value="0">All Divisions</option>
                  <?php foreach ($divisions as $div) : ?>
                    <option value="<?= $div['division_id'] ?>" <?= $filter_div == $div['division_id'] ? 'selected' : '' ?>>Division <?= htmlspecialchars($div['division_name']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>

            <!-- Attendance Status -->
            <div class="flex flex-col w-full md:w-44 gap-1.5">
              <label class="text-xs font-semibold text-slate-500 uppercase tracking-wider">Att. Status</label>
              <div class="relative">
                <select name="filter" id="filter-select" class="w-full h-11 px-4 pr-10 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm focus:border-primary focus:ring-2 focus:ring-primary/20 outline-none appearance-none">
                  <option value="" <?= $filter_status === '' ? 'selected' : '' ?>>All Students</option>
                  <option value="low" <?= $filter_status === 'low' ? 'selected' : '' ?>>At Risk (&lt;75%)</option>
                  <option value="critical" <?= $filter_status === 'critical' ? 'selected' : '' ?>>Critical (&lt;60%)</option>
                </select>
              </div>
            </div>

            <!-- Buttons -->
            <div class="flex items-end gap-2">
              <button type="submit" class="h-11 px-6 rounded-xl bg-primary hover:bg-primary-dark text-white font-semibold text-sm flex items-center gap-2 transition-all active:scale-95">
                <span class="material-symbols-outlined text-[18px]">filter_list</span>Filter
              </button>
              <a href="admin_manage_student.php" class="h-11 px-4 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-sm flex items-center gap-1.5 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                <span class="material-symbols-outlined text-[18px]">refresh</span>Clear
              </a>
            </div>
          </form>
        </div>

        <!-- STUDENT TABLE -->
        <div class="bg-surface-light dark:bg-surface-dark rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">

          <!-- Toolbar -->
          <div class="px-6 py-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between gap-3 bg-slate-50/60 dark:bg-slate-800/40">
            <div>
              <h3 class="font-bold text-slate-900 dark:text-white">Student Records</h3>
              <p class="text-xs text-slate-500 mt-0.5">
                Showing <span class="font-bold text-slate-800 dark:text-white"><?= count($all_students) ?></span> students
                <?php if ($filter_status || $search || $filter_sem || $filter_div) : ?>
                  <span class="text-slate-400">(filtered from <?= $total_students ?>)</span>
                <?php endif; ?>
              </p>
            </div>
            <a href="../frontend/register.php" target="_blank" class="flex items-center gap-2 px-4 py-2 bg-primary hover:bg-primary-dark text-white rounded-xl text-sm font-semibold transition-all shadow-md shadow-primary/20 active:scale-95">
              <span class="material-symbols-outlined text-[18px]">add</span>Add Student
            </a>
          </div>

          <!-- Table -->
          <div class="overflow-x-auto">
            <table class="w-full text-sm border-collapse">
              <thead>
                <tr class="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-700 text-xs font-bold text-slate-500 uppercase tracking-wider">
                  <th class="px-6 py-4 text-left">Student</th>
                  <th class="px-6 py-4 text-left hidden sm:table-cell">Roll No</th>
                  <th class="px-6 py-4 text-left hidden md:table-cell">Semester</th>
                  <th class="px-6 py-4 text-left hidden md:table-cell">Division</th>
                  <th class="px-6 py-4 text-center">Classes</th>
                  <th class="px-6 py-4 text-left">Attendance</th>
                  <th class="px-6 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100 dark:divide-slate-800">
                <?php if (empty($all_students)) : ?>
                  <tr>
                    <td colspan="7" class="px-6 py-16 text-center">
                      <span class="material-symbols-outlined text-5xl text-slate-300 dark:text-slate-600 block mb-3">search_off</span>
                      <p class="text-slate-400 font-medium">No students found matching your filters.</p>
                    </td>
                  </tr>
                <?php else : ?>
                  <?php foreach ($all_students as $i => $s) :
                    $pct      = $s['pct'] !== null ? (float)$s['pct'] : null;
                    $total    = (int)$s['total_classes'];
                    $attended = (int)$s['attended'];
                    $initials = strtoupper(substr($s['name'], 0, 1));
                    $avColor  = $av_colors[$i % count($av_colors)];

                    // Row & badge styling
                    if ($pct === null) {
                      $rowClass   = 'hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors';
                      $badgeClass = 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400';
                      $badgeLabel = '--';
                      $badgeIcon  = '';
                    } elseif ($pct < 60) {
                      $rowClass   = 'bg-red-50/50 dark:bg-red-900/5 border-l-4 border-l-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors';
                      $badgeClass = 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-800';
                      $badgeLabel = $pct . '%';
                      $badgeIcon  = 'warning';
                    } elseif ($pct < 75) {
                      $rowClass   = 'bg-amber-50/40 dark:bg-amber-900/5 border-l-4 border-l-amber-400 hover:bg-amber-50 dark:hover:bg-amber-900/10 transition-colors';
                      $badgeClass = 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-800';
                      $badgeLabel = $pct . '%';
                      $badgeIcon  = 'warning';
                    } else {
                      $rowClass   = 'hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors';
                      $badgeClass = 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800';
                      $badgeLabel = $pct . '%';
                      $badgeIcon  = '';
                    }

                    // Progress bar width & color
                    $barWidth = $pct !== null ? min(100, $pct) : 0;
                    $barColor = $pct === null ? 'bg-slate-300' : ($pct < 60 ? 'bg-red-500' : ($pct < 75 ? 'bg-amber-500' : 'bg-emerald-500'));
                  ?>
                    <tr class="<?= $rowClass ?>">

                      <!-- Student Name + Email -->
                      <td class="px-6 py-4">
                        <div class="flex items-center gap-3">
                          <div class="size-10 rounded-full <?= $avColor ?> flex items-center justify-center font-bold text-sm shrink-0"><?= $initials ?></div>
                          <div>
                            <p class="font-semibold text-slate-900 dark:text-white"><?= htmlspecialchars($s['name']) ?></p>
                            <p class="text-xs text-slate-400 truncate max-w-[160px]"><?= htmlspecialchars($s['email']) ?></p>
                          </div>
                        </div>
                      </td>

                      <!-- Roll No -->
                      <td class="px-6 py-4 hidden sm:table-cell">
                        <span class="font-mono text-xs bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded text-slate-600 dark:text-slate-300">
                          <?= htmlspecialchars($s['roll_no']) ?>
                        </span>
                      </td>

                      <!-- Semester -->
                      <td class="px-6 py-4 text-slate-500 dark:text-slate-400 text-sm hidden md:table-cell">
                        Semester <?= $s['semester_no'] ?>
                      </td>

                      <!-- Division -->
                      <td class="px-6 py-4 text-slate-500 dark:text-slate-400 text-sm hidden md:table-cell">
                        Division <?= htmlspecialchars($s['division_name']) ?>
                      </td>

                      <!-- Classes -->
                      <td class="px-6 py-4 text-center">
                        <div class="flex flex-col items-center">
                          <span class="font-bold text-slate-700 dark:text-slate-200"><?= $attended ?> / <?= $total ?></span>
                          <span class="text-[10px] text-slate-400">attended</span>
                        </div>
                      </td>

                      <!-- Attendance % with bar -->
                      <td class="px-6 py-4">
                        <div class="flex items-center gap-2 min-w-[120px]">
                          <div class="flex-1 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                            <div class="<?= $barColor ?> h-full rounded-full" style="width:<?= $barWidth ?>%"></div>
                          </div>
                          <span class="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-xs font-bold <?= $badgeClass ?> shrink-0">
                            <?php if ($badgeIcon) : ?>
                              <span class="material-symbols-outlined text-[12px]"><?= $badgeIcon ?></span>
                            <?php endif; ?>
                            <?= $badgeLabel ?>
                          </span>
                        </div>
                      </td>

                      <!-- Actions -->
                      <td class="px-6 py-4 text-right">
                        <div class="flex items-center justify-end gap-1">
                          <a href="javascript:void(0)" title="View Profile" class="p-2 rounded-lg text-slate-400 hover:text-primary hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors">
                            <span class="material-symbols-outlined text-[20px]">visibility</span>
                          </a>
                        </div>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php endif; ?>
              </tbody>
            </table>
          </div>

          <!-- Table Footer Legend -->
          <div class="px-6 py-4 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between bg-slate-50/40 dark:bg-slate-800/20">
            <p class="text-sm text-slate-500">Total <span class="font-bold text-slate-800 dark:text-white"><?= count($all_students) ?></span> students shown</p>
            <div class="flex items-center gap-4 text-xs text-slate-500">
              <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-emerald-500"></span>≥ 75% Safe</span>
              <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-amber-500"></span>60–74% At Risk</span>
              <span class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-red-500"></span>&lt; 60% Critical</span>
            </div>
          </div>
        </div>

      </div><!-- /max-w -->
    </main>
  </div>

  <!-- Toast -->
  <div id="toast" class="hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold flex items-center gap-2"></div>

  <script>
    let deleteUserId = 0;

    function setFilter(val) {
      document.getElementById('filter-select').value = val;
      document.querySelector('form').submit();
    }

    // Live search
    document.getElementById('search-input').addEventListener('input', function() {
      const q = this.value.toLowerCase();
      document.querySelectorAll('tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
      });
    });

    function toast(msg, type) {
      const t = document.getElementById('toast');
      t.innerHTML = `<span class="material-symbols-outlined text-[18px]">${type==='success'?'check_circle':'error'}</span>${msg}`;
      t.className = `fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold flex items-center gap-2 ${type==='success'?'bg-green-600':'bg-red-500'}`;
      t.classList.remove('hidden');
      setTimeout(() => t.classList.add('hidden'), 3500);
    }
  </script>
</body>

</html>