<?php
include("../backend/config/connection.php");
include("../backend/auth/auth.php");

if ($_SESSION['role'] !== 'teacher') {
    header("Location: login.php?error=unauthorized"); exit();
}
$user_id = $_SESSION['user_id'];
$uq = $conn->prepare("SELECT name FROM users WHERE id = ?");
$uq->bind_param("i", $user_id); $uq->execute();
$teacher_user = $uq->get_result()->fetch_assoc();
$initials = strtoupper(substr($teacher_user['name'], 0, 2));
?>
<!DOCTYPE html>
<html class="light" lang="en">
<head>
  <meta charset="utf-8"/>
  <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
  <title>EduSmart — Attendance Records</title>
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet"/>
  <script>
    tailwind.config = {
      darkMode:"class",
      theme:{ extend:{
        colors:{ primary:"#2b8cee","primary-dark":"#1a6ec0","background-light":"#f6f7f8","background-dark":"#101922" },
        fontFamily:{ display:["Lexend","sans-serif"] },
        borderRadius:{ DEFAULT:"0.375rem",lg:"0.5rem",xl:"0.75rem","2xl":"1rem",full:"9999px" },
      }},
    };
  </script>
  <style>
    body { font-family:"Lexend",sans-serif; }
    ::-webkit-scrollbar{ width:6px; } ::-webkit-scrollbar-thumb{ background:#cbd5e1;border-radius:4px; }
    .dark ::-webkit-scrollbar-thumb{ background:#334155; }
    .material-symbols-outlined{ font-variation-settings:"FILL" 0,"wght" 400,"GRAD" 0,"opsz" 24; }
    @keyframes fadeIn{ from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)} }
    .fade-in{ animation:fadeIn .25s ease forwards; }
    .toggle-btn{ transition:all .2s; }
  </style>
</head>

<body class="bg-background-light dark:bg-background-dark text-slate-900 dark:text-slate-100 min-h-screen flex flex-col">

<!-- HEADER -->
<header class="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-6 py-3 sticky top-0 z-50 shadow-sm">
  <div class="flex items-center gap-4">
    <div class="bg-primary/10 p-2 rounded-xl"><span class="material-symbols-outlined text-primary text-2xl">school</span></div>
    <h2 class="text-xl font-bold">EduSmart</h2>
  </div>
  <nav class="hidden md:flex items-center gap-6 text-sm font-medium">
    <a class="text-slate-500 hover:text-primary transition-colors" href="teacher_dashboard.php">Dashboard</a>
    <a class="text-slate-500 hover:text-primary transition-colors" href="teacher_take_attendance.php">Take Attendance</a>
    <a class="text-primary font-semibold border-b-2 border-primary pb-0.5" href="#">Records</a>
    <a class="text-slate-500 hover:text-primary transition-colors" href="teacher_reports.php">Reports</a>
  </nav>
  <div class="flex items-center gap-3">
    <div class="size-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm"><?= $initials ?></div>
    <span class="hidden md:block text-sm font-medium text-slate-700 dark:text-slate-300"><?= htmlspecialchars($teacher_user['name']) ?></span>
  </div>
</header>

<!-- MAIN -->
<main class="flex-1 px-4 sm:px-8 py-8 w-full max-w-[1100px] mx-auto flex flex-col gap-6">

  <!-- Title -->
  <div>
    <h1 class="text-3xl font-black tracking-tight mb-1">Attendance Records</h1>
    <p class="text-slate-500 dark:text-slate-400">View and update student attendance for any lecture date.</p>
  </div>

  <!-- FILTER CARD -->
  <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
    <div class="flex items-center gap-2 mb-5">
      <span class="material-symbols-outlined text-primary">tune</span>
      <h3 class="font-bold text-slate-800 dark:text-white">Select Class &amp; Date</h3>
    </div>
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">

      <!-- Class -->
      <div class="lg:col-span-2">
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Subject / Semester / Division <span class="text-red-400">*</span></label>
        <div class="relative">
          <select id="class-select" class="w-full appearance-none rounded-xl border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 px-4 pr-10 text-sm focus:border-primary focus:ring-primary">
            <option value="">-- Loading classes... --</option>
          </select>
        </div>
      </div>

      <!-- Date -->
      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Date <span class="text-red-400">*</span></label>
        <input type="date" id="sel-date"
          class="w-full rounded-xl border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 px-4 text-sm focus:border-primary focus:ring-primary"/>
      </div>

      <!-- Search -->
      <div>
        <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Search Student</label>
        <div class="relative">
          <span class="material-symbols-outlined absolute left-3 top-2.5 text-slate-400 text-[20px]">search</span>
          <input type="text" id="search-input" placeholder="Name or Roll No..."
            class="w-full rounded-xl border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 h-11 pl-10 pr-4 text-sm focus:border-primary focus:ring-primary"/>
        </div>
      </div>

      <!-- Buttons -->
      <div class="flex items-end gap-3 sm:col-span-2 lg:col-span-4">
        <button onclick="loadRecords()"
          class="h-11 px-8 rounded-xl bg-primary hover:bg-primary-dark text-white font-bold text-sm flex items-center gap-2 transition-all active:scale-95 shadow-md shadow-primary/20">
          <span class="material-symbols-outlined text-[18px]">search</span> View Records
        </button>
        <button onclick="clearAll()"
          class="h-11 px-5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-sm hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2 transition-colors">
          <span class="material-symbols-outlined text-[18px]">refresh</span> Clear
        </button>
      </div>
    </div>
  </div>

  <!-- NO LECTURE STATE -->
  <div id="no-lecture-state" class="hidden fade-in">
    <div class="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-2xl p-10 text-center">
      <span class="material-symbols-outlined text-6xl text-amber-400 block mb-4">event_busy</span>
      <h3 class="text-xl font-black text-amber-700 dark:text-amber-400 mb-2" id="no-lecture-title">No Lecture on This Day</h3>
      <p class="text-amber-600 dark:text-amber-500 text-sm max-w-sm mx-auto" id="no-lecture-msg"></p>
    </div>
  </div>

  <!-- STAT CARDS -->
  <div id="stats-row" class="hidden grid grid-cols-2 lg:grid-cols-4 gap-4 fade-in">
    <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm">
      <p class="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">Date</p>
      <h3 id="stat-date" class="text-lg font-black text-slate-900 dark:text-white leading-tight">--</h3>
      <p id="stat-day"  class="text-xs text-slate-400 mt-1">--</p>
    </div>
    <div class="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm relative overflow-hidden">
      <div class="absolute right-2 top-2 opacity-[0.06] pointer-events-none"><span class="material-symbols-outlined text-7xl text-blue-500">groups</span></div>
      <p class="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">Total Students</p>
      <h3 id="stat-total" class="text-4xl font-black text-slate-900 dark:text-white">--</h3>
    </div>
    <div class="bg-emerald-50 dark:bg-emerald-900/20 rounded-2xl border border-emerald-100 dark:border-emerald-800 p-5 shadow-sm relative overflow-hidden">
      <div class="absolute right-2 top-2 opacity-[0.08] pointer-events-none"><span class="material-symbols-outlined text-7xl text-emerald-500">how_to_reg</span></div>
      <p class="text-xs font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 mb-2">Present</p>
      <h3 id="stat-present" class="text-4xl font-black text-emerald-600 dark:text-emerald-400">--</h3>
      <p id="stat-present-pct" class="text-xs text-emerald-500 mt-2 font-medium"></p>
    </div>
    <div class="bg-rose-50 dark:bg-rose-900/20 rounded-2xl border border-rose-100 dark:border-rose-800 p-5 shadow-sm relative overflow-hidden">
      <div class="absolute right-2 top-2 opacity-[0.08] pointer-events-none"><span class="material-symbols-outlined text-7xl text-rose-500">person_off</span></div>
      <p class="text-xs font-semibold uppercase tracking-wider text-rose-500 mb-2">Absent</p>
      <h3 id="stat-absent" class="text-4xl font-black text-rose-500 dark:text-rose-400">--</h3>
      <p id="stat-absent-pct" class="text-xs text-rose-400 mt-2 font-medium"></p>
    </div>
  </div>

  <!-- RESULTS PANEL -->
  <div id="results-panel" class="hidden bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden fade-in">

    <!-- Toolbar -->
    <div class="flex flex-wrap items-center justify-between gap-3 px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40">
      <!-- Filter tabs -->
      <div class="flex items-center gap-1 bg-slate-200 dark:bg-slate-700 p-1 rounded-xl">
        <button id="tab-all"     onclick="filterTable('all')"
          class="px-4 py-1.5 rounded-lg text-sm font-semibold bg-primary text-white transition-all">
          All <span id="badge-all" class="ml-1 text-xs bg-white/20 px-1.5 py-0.5 rounded-full font-bold"></span>
        </button>
        <button id="tab-present" onclick="filterTable('present')"
          class="px-4 py-1.5 rounded-lg text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-slate-600 transition-all">
          Present <span id="badge-present" class="ml-1 text-xs bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-400 px-1.5 py-0.5 rounded-full font-bold"></span>
        </button>
        <button id="tab-absent"  onclick="filterTable('absent')"
          class="px-4 py-1.5 rounded-lg text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-white/60 dark:hover:bg-slate-600 transition-all">
          Absent <span id="badge-absent" class="ml-1 text-xs bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-400 px-1.5 py-0.5 rounded-full font-bold"></span>
        </button>
      </div>
    </div>

    <!-- Not-taken info banner -->
    <div id="not-taken-banner" class="hidden px-6 py-3 bg-blue-50 dark:bg-blue-900/20 border-b border-blue-200 dark:border-blue-800 flex items-center gap-2 text-blue-700 dark:text-blue-400 text-sm">
      <span class="material-symbols-outlined text-[18px]">info</span>
      Attendance not submitted yet for this date. You can mark and save it below.
    </div>

    <!-- Table -->
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead>
          <tr class="bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-500 uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
            <th class="px-5 py-3 text-left w-12">#</th>
            <th class="px-5 py-3 text-left w-28">Roll No</th>
            <th class="px-5 py-3 text-left">Student Name</th>
            <th class="px-5 py-3 text-left hidden sm:table-cell">Gender</th>
            <th class="px-5 py-3 text-center">Status</th>
            <th class="px-5 py-3 text-center w-36">Update</th>
          </tr>
        </thead>
        <tbody id="records-tbody" class="divide-y divide-slate-100 dark:divide-slate-800"></tbody>
      </table>
    </div>

    <!-- Empty -->
    <div id="empty-result" class="hidden text-center py-14">
      <span class="material-symbols-outlined text-5xl text-slate-300 dark:text-slate-600 block mb-3">search_off</span>
      <p class="text-slate-400 font-medium">No students found.</p>
    </div>
  </div>

  <!-- Initial state -->
  <div id="initial-state" class="text-center py-20">
    <span class="material-symbols-outlined text-7xl text-slate-300 dark:text-slate-600 block mb-4">event_note</span>
    <h3 class="text-lg font-bold text-slate-600 dark:text-slate-300 mb-2">Select a Class &amp; Date</h3>
    <p class="text-sm text-slate-400 max-w-xs mx-auto">Choose your subject, semester, division and a date, then click View Records.</p>
  </div>

  <!-- Loading -->
  <div id="loading-state" class="hidden text-center py-20">
    <div class="inline-block w-10 h-10 border-4 border-primary/30 border-t-primary rounded-full animate-spin mb-4"></div>
    <p class="text-slate-400 font-medium">Loading records...</p>
  </div>

</main>

<!-- Toast -->
<div id="toast" class="hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold flex items-center gap-2"></div>

<script>
let allClasses    = [];
let allStudents   = [];
let currentFilter = 'all';
let currentCls    = null;
let currentDate   = '';
const avatarColors = ['bg-blue-100 text-blue-700','bg-purple-100 text-purple-700','bg-amber-100 text-amber-700','bg-pink-100 text-pink-700','bg-teal-100 text-teal-700'];

// ── Load teacher classes ──────────────────────────────────────────────────────
async function loadClasses() {
  try {
    const res  = await fetch('../backend/attendance/get_teacher_classes.php');
    const data = await res.json();
    allClasses = data;
    const sel  = document.getElementById('class-select');
    sel.innerHTML = data.length ? '<option value="">-- Select a class --</option>' : '<option value="">No classes assigned</option>';
    data.forEach((c, i) => {
      const o = document.createElement('option');
      o.value = i;
      o.textContent = `${c.subject_name}  |  Sem ${c.semester_no}  |  Div ${c.division_name}`;
      sel.appendChild(o);
    });
  } catch(e) { toast('Failed to load classes: ' + e.message, 'error'); }
}

// ── Load records ──────────────────────────────────────────────────────────────
async function loadRecords() {
  const idx    = document.getElementById('class-select').value;
  const date   = document.getElementById('sel-date').value;
  const search = document.getElementById('search-input').value.trim();

  if (idx === '')  { toast('Please select a class.', 'error'); return; }
  if (date === '') { toast('Please select a date.',  'error'); return; }

  currentCls  = allClasses[+idx];
  currentDate = date;

  hide('initial-state'); hide('results-panel');
  hide('stats-row');     hide('no-lecture-state');
  show('loading-state');

  try {
    const p   = new URLSearchParams({ subject_id: currentCls.subject_id, semester_id: currentCls.semester_id, division_id: currentCls.division_id, date, search });
    const res = await fetch('../backend/attendance/get_attendance_records.php?' + p);
    const txt = await res.text();
    let data;
    try { data = JSON.parse(txt); } catch(e) { console.error('Raw:', txt); toast('Server error. Check console.', 'error'); hide('loading-state'); show('initial-state'); return; }

    hide('loading-state');

    if (data.error) { toast(data.error, 'error'); show('initial-state'); return; }

    // No lecture on this day
    if (data.no_lecture) {
      document.getElementById('no-lecture-title').textContent = `No Lecture on ${data.day}`;
      document.getElementById('no-lecture-msg').textContent   = `${currentCls.subject_name} is not scheduled on ${data.day}s for Sem ${currentCls.semester_no} Div ${currentCls.division_name}. Please select a different date.`;
      show('no-lecture-state');
      return;
    }

    allStudents = data.students;

    // Stat cards
    const d = new Date(date + 'T00:00:00');
    document.getElementById('stat-date').textContent        = d.toLocaleDateString('en-IN', { day:'numeric', month:'long', year:'numeric' });
    document.getElementById('stat-day').textContent         = d.toLocaleDateString('en-IN', { weekday:'long' });
    document.getElementById('stat-total').textContent       = data.total;
    document.getElementById('stat-present').textContent     = data.present;
    document.getElementById('stat-absent').textContent      = data.absent;
    document.getElementById('stat-present-pct').textContent = data.total > 0 ? Math.round(data.present / data.total * 100) + '% present' : '';
    document.getElementById('stat-absent-pct').textContent  = data.total > 0 ? Math.round(data.absent  / data.total * 100) + '% absent'  : '';

    // Badges
    document.getElementById('badge-all').textContent     = data.total;
    document.getElementById('badge-present').textContent = data.present;
    document.getElementById('badge-absent').textContent  = data.absent;

    data.attendance_taken ? hide('not-taken-banner') : show('not-taken-banner');

    show('stats-row');
    show('results-panel');
    currentFilter = 'all';
    setActiveTab('tab-all');
    renderTable('all');

  } catch(e) { hide('loading-state'); show('initial-state'); toast('Error: ' + e.message, 'error'); console.error(e); }
}

// ── Render table ──────────────────────────────────────────────────────────────
function renderTable(filter) {
  const tbody    = document.getElementById('records-tbody');
  const filtered = filter === 'all' ? allStudents : allStudents.filter(s => s.status === filter);

  if (!filtered.length) { tbody.innerHTML = ''; show('empty-result'); return; }
  hide('empty-result');

  tbody.innerHTML = filtered.map((s, i) => {
    const isPresent  = s.status === 'present';
    const isAbsent   = s.status === 'absent';
    const rowBg      = isAbsent  ? 'bg-rose-50/50 dark:bg-rose-900/5 border-l-4 border-l-rose-400'
                     : isPresent ? 'hover:bg-slate-50 dark:hover:bg-slate-800/30'
                     : 'hover:bg-slate-50 dark:hover:bg-slate-800/30';
    const initials   = s.student_name.split(' ').map(n=>n[0]).join('').substring(0,2).toUpperCase();
    const avatarCol  = avatarColors[i % avatarColors.length];

    const statusBadge = isPresent
      ? `<span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 text-xs font-bold"><span class="w-2 h-2 rounded-full bg-emerald-500"></span>Present</span>`
      : isAbsent
        ? `<span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-rose-100 dark:bg-rose-900/30 text-rose-700 dark:text-rose-400 text-xs font-bold"><span class="w-2 h-2 rounded-full bg-rose-500"></span>Absent</span>`
        : `<span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-500 text-xs font-bold"><span class="w-2 h-2 rounded-full bg-slate-400"></span>Not Taken</span>`;

    // Update button: shows opposite action
    const updateBtn = isPresent
      ? `<button onclick="updateStatus(${s.student_id}, 'absent', this)"
           class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800 text-xs font-bold hover:bg-rose-100 transition-colors">
           <span class="material-symbols-outlined text-[15px]">person_off</span> Mark Absent
         </button>`
      : `<button onclick="updateStatus(${s.student_id}, 'present', this)"
           class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 text-xs font-bold hover:bg-emerald-100 transition-colors">
           <span class="material-symbols-outlined text-[15px]">how_to_reg</span> Mark Present
         </button>`;

    return `
    <tr class="transition-colors ${rowBg}" id="row-${s.student_id}" data-student-id="${s.student_id}" data-status="${s.status}">
      <td class="px-5 py-3.5 text-slate-400 text-xs font-mono">${i+1}</td>
      <td class="px-5 py-3.5 font-mono text-slate-500 text-xs font-semibold">${esc(s.roll_no)}</td>
      <td class="px-5 py-3.5">
        <div class="flex items-center gap-3">
          <div class="size-9 rounded-full ${avatarCol} flex items-center justify-center font-bold text-xs shrink-0">${initials}</div>
          <span class="font-semibold text-slate-800 dark:text-white">${esc(s.student_name)}</span>
        </div>
      </td>
      <td class="px-5 py-3.5 text-slate-500 text-sm capitalize hidden sm:table-cell">${esc(s.gender||'--')}</td>
      <td class="px-5 py-3.5 text-center" id="status-cell-${s.student_id}">${statusBadge}</td>
      <td class="px-5 py-3.5 text-center" id="btn-cell-${s.student_id}">${updateBtn}</td>
    </tr>`;
  }).join('');
}

// ── Update single student attendance ─────────────────────────────────────────
async function updateStatus(studentId, newStatus, btn) {
  if (!currentCls || !currentDate) return;

  // Disable button during request
  btn.disabled = true;
  btn.innerHTML = '<div class="w-4 h-4 border-2 border-current/30 border-t-current rounded-full animate-spin mx-auto"></div>';

  try {
    const res = await fetch('../backend/attendance/update_attendance.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        student_id:  studentId,
        subject_id:  currentCls.subject_id,
        semester_id: currentCls.semester_id,
        division_id: currentCls.division_id,
        date:        currentDate,
        status:      newStatus,
      })
    });
    const data = await res.json();

    if (!data.success) { toast(data.message || 'Update failed', 'error'); btn.disabled = false; return; }

    // Update local data
    const idx = allStudents.findIndex(s => s.student_id == studentId);
    if (idx !== -1) allStudents[idx].status = newStatus;

    // Update row UI without full re-render
    updateRowUI(studentId, newStatus);
    updateStatCards();
    updateBadges();
    hide('not-taken-banner');

    toast(newStatus === 'present' ? 'Marked Present ✓' : 'Marked Absent ✓', 'success');

  } catch(e) { toast('Error: ' + e.message, 'error'); btn.disabled = false; console.error(e); }
}

// ── Update just one row's UI ──────────────────────────────────────────────────
function updateRowUI(studentId, newStatus) {
  const row        = document.getElementById('row-' + studentId);
  const statusCell = document.getElementById('status-cell-' + studentId);
  const btnCell    = document.getElementById('btn-cell-'    + studentId);
  if (!row) return;

  row.dataset.status = newStatus;

  // Row background
  row.className = row.className
    .replace(/bg-rose-50\/50[^\s]*/g,'').replace(/dark:bg-rose-900\/5/g,'')
    .replace(/border-l-4/g,'').replace(/border-l-rose-400/g,'').trim();

  if (newStatus === 'absent') {
    row.classList.add('bg-rose-50/50','dark:bg-rose-900/5','border-l-4','border-l-rose-400');
  }

  // Status badge
  statusCell.innerHTML = newStatus === 'present'
    ? `<span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 text-xs font-bold"><span class="w-2 h-2 rounded-full bg-emerald-500"></span>Present</span>`
    : `<span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-rose-100 dark:bg-rose-900/30 text-rose-700 dark:text-rose-400 text-xs font-bold"><span class="w-2 h-2 rounded-full bg-rose-500"></span>Absent</span>`;

  // Update button (opposite action)
  btnCell.innerHTML = newStatus === 'present'
    ? `<button onclick="updateStatus(${studentId}, 'absent', this)"
         class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800 text-xs font-bold hover:bg-rose-100 transition-colors">
         <span class="material-symbols-outlined text-[15px]">person_off</span> Mark Absent
       </button>`
    : `<button onclick="updateStatus(${studentId}, 'present', this)"
         class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-900/20 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 text-xs font-bold hover:bg-emerald-100 transition-colors">
         <span class="material-symbols-outlined text-[15px]">how_to_reg</span> Mark Present
       </button>`;
}

// ── Recount and update stat cards ────────────────────────────────────────────
function updateStatCards() {
  const total   = allStudents.length;
  const present = allStudents.filter(s => s.status === 'present').length;
  const absent  = allStudents.filter(s => s.status === 'absent').length;
  document.getElementById('stat-present').textContent     = present;
  document.getElementById('stat-absent').textContent      = absent;
  document.getElementById('stat-present-pct').textContent = total > 0 ? Math.round(present / total * 100) + '% present' : '';
  document.getElementById('stat-absent-pct').textContent  = total > 0 ? Math.round(absent  / total * 100) + '% absent'  : '';
}

function updateBadges() {
  const present = allStudents.filter(s => s.status === 'present').length;
  const absent  = allStudents.filter(s => s.status === 'absent').length;
  document.getElementById('badge-all').textContent     = allStudents.length;
  document.getElementById('badge-present').textContent = present;
  document.getElementById('badge-absent').textContent  = absent;
}

// ── Filter tabs ───────────────────────────────────────────────────────────────
function filterTable(filter) {
  currentFilter = filter;
  setActiveTab('tab-' + filter);
  renderTable(filter);
}

function setActiveTab(activeId) {
  ['tab-all','tab-present','tab-absent'].forEach(id => {
    const b = document.getElementById(id);
    b.classList.remove('bg-primary','text-white');
    b.classList.add('text-slate-600','dark:text-slate-300');
  });
  const a = document.getElementById(activeId);
  a.classList.add('bg-primary','text-white');
  a.classList.remove('text-slate-600','dark:text-slate-300');
}

// ── Clear ─────────────────────────────────────────────────────────────────────
function clearAll() {
  document.getElementById('class-select').value = '';
  document.getElementById('sel-date').value     = '';
  document.getElementById('search-input').value = '';
  allStudents = []; currentCls = null; currentDate = '';
  hide('results-panel'); hide('stats-row'); hide('loading-state'); hide('no-lecture-state');
  show('initial-state');
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function show(id) { document.getElementById(id)?.classList.remove('hidden'); }
function hide(id) { document.getElementById(id)?.classList.add('hidden'); }
function esc(s)   { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function toast(msg, type) {
  const t = document.getElementById('toast');
  t.innerHTML = (type==='success' ? '<span class="material-symbols-outlined text-[18px]">check_circle</span>' : '<span class="material-symbols-outlined text-[18px]">error</span>') + msg;
  t.className = `fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-5 py-3 rounded-xl shadow-xl text-white text-sm font-semibold flex items-center gap-2 ${type==='success'?'bg-green-600':'bg-red-500'}`;
  t.classList.remove('hidden');
  setTimeout(() => t.classList.add('hidden'), 3000);
}

document.addEventListener('DOMContentLoaded', () => {
  loadClasses();
  document.getElementById('sel-date').value = new Date().toISOString().split('T')[0];
  document.getElementById('search-input').addEventListener('keydown', e => { if(e.key==='Enter') loadRecords(); });
});
</script>
</body>
</html>