<!DOCTYPE html>
<html class="light" lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>EduSmart - Smart Attendance &amp; Learning Platform</title>
  <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com" rel="preconnect" />
  <link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect" />
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700;900&amp;display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet" />
  <script id="tailwind-config">
    tailwind.config = {
      darkMode: "class",
      theme: {
        extend: {
          colors: {
            primary: "#2b8cee",
            "background-light": "#f6f7f8",
            "background-dark": "#101922",
          },
          fontFamily: {
            display: ["Inter", "sans-serif"],
          },
          borderRadius: {
            DEFAULT: "0.25rem",
            lg: "0.5rem",
            xl: "0.75rem",
            full: "9999px",
          },
        },
      },
    };
  </script>
  <style>
    .material-symbols-outlined {
      font-variation-settings: "FILL" 0, "wght" 400, "GRAD" 0, "opsz" 24;
    }
  </style>
</head>

<body class="bg-background-light dark:bg-background-dark font-display text-slate-900 dark:text-slate-50 flex flex-col min-h-screen overflow-x-hidden">
  <!-- Navigation Bar -->
  <div class="sticky top-0 z-50 w-full bg-slate-50/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
    <div class="flex justify-center px-4 md:px-10 py-3">
      <div class="flex max-w-[1280px] flex-1 items-center justify-between">
        <div class="flex items-center gap-3">
          <div class="flex items-center justify-center size-8 rounded-lg bg-primary/10 text-primary">
            <span class="material-symbols-outlined text-[24px]">school</span>
          </div>
          <h2 class="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            EduSmart
          </h2>
        </div>
        <div class="hidden md:flex items-center gap-8">
          <a class="text-sm font-medium hover:text-primary transition-colors text-slate-700 dark:text-slate-300" href="#">Home</a>
          <a class="text-sm font-medium hover:text-primary transition-colors text-slate-700 dark:text-slate-300" href="#features">Features</a>
          <a class="text-sm font-medium hover:text-primary transition-colors text-slate-700 dark:text-slate-300" href="#how-it-works">How It Works</a>
          <a class="text-sm font-medium hover:text-primary transition-colors text-slate-700 dark:text-slate-300" href="#roles">Roles</a>
        </div>
        <div class="flex items-center gap-4">
          <button class="flex items-center justify-center h-10 px-6 rounded-lg bg-primary hover:bg-blue-600 text-white text-sm font-bold transition-all shadow-sm">
            <a href="login.php">Login</a>
          </button>
          <button class="flex items-center justify-center h-10 px-6 rounded-lg bg-primary hover:bg-blue-600 text-white text-sm font-bold transition-all shadow-sm">
            <a href="register.php">Register</a>
          </button>
        </div>
      </div>
    </div>
  </div>
  <!-- Hero Section -->
  <div class="relative w-full flex justify-center py-12 md:py-20 lg:py-24 px-4 md:px-10">
    <div class="max-w-[1280px] w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
      <div class="flex flex-col gap-6 text-center lg:text-left">
        <div class="flex flex-col gap-4">
          <h1 class="text-4xl md:text-5xl lg:text-6xl font-black leading-tight tracking-tight text-slate-900 dark:text-white">
            Smart Attendance &amp;
            <span class="text-primary">Learning</span> Platform
          </h1>
          <p class="text-lg text-slate-600 dark:text-slate-400 leading-relaxed max-w-2xl mx-auto lg:mx-0">
            Revolutionize your classroom management. Handle digital
            attendance, resolve student doubts instantly with AI, and track
            performance analytics in one unified system.
          </p>
        </div>
        <div class="flex flex-wrap justify-center lg:justify-start gap-4">
          <a href="../frontend/login.php">
            <button class="flex items-center justify-center h-12 px-8 rounded-lg bg-primary hover:bg-blue-600 text-white text-base font-bold transition-all shadow-md hover:shadow-lg">
              Get Started
            </button>
          </a>
        </div>
        <div class="pt-4 flex items-center justify-center lg:justify-start gap-4 text-sm text-slate-500 dark:text-slate-400">
          <div class="flex items-center gap-1">
            <span class="material-symbols-outlined text-[18px]">check_circle</span>
            Open Source
          </div>
        </div>
      </div>
      <div class="relative w-full aspect-[4/3] rounded-2xl overflow-hidden shadow-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 group">
        <div class="absolute inset-0 bg-cover bg-center transition-transform duration-700 group-hover:scale-105" data-alt="Modern technology illustration showing digital education concepts with abstract interface elements" style="
              background-image: url('https://lh3.googleusercontent.com/aida-public/AB6AXuDn2ofGU9KU5jhTPPajeP7kgx23161CtkCv_ibDrPJUW5UjCpSJ8Lu387u97VQtvA6NxJmBezI6l1wEOoAk-OAk5QWkhvX4oJipC471dxAzUnheOc3USZCuMuJOFm3iPmeVulfy_gEW8MSWNBLnBhtzQxmHFTaKCRzvuFMg-PCUcNSDQmNq7V5CQIT0yh1-Y5Nbv7BSGHg2j-I6ITASZmAWjX-XDx_PZ5ynxGvfUjFjt-qXcy0p4J2iuEj7HWlRDnYRorvMFkE_30uY');
            "></div>
        <div class="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent"></div>
        <div class="absolute bottom-6 left-6 right-6 p-4 bg-white/90 dark:bg-slate-900/90 backdrop-blur rounded-xl border border-slate-200 dark:border-slate-700 shadow-lg flex items-center gap-4">
          <div class="bg-primary/20 p-2 rounded-lg text-primary">
            <span class="material-symbols-outlined">smart_toy</span>
          </div>
          <div>
            <p class="text-sm font-medium text-slate-900 dark:text-white">
              Solving student doubts 24/7
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Features Section -->
  <div class="w-full bg-white dark:bg-slate-900 py-20 px-4 md:px-10 border-y border-slate-100 dark:border-slate-800" id="features">
    <div class="max-w-[1280px] mx-auto flex flex-col gap-12">
      <div class="text-center max-w-3xl mx-auto flex flex-col gap-4">
        <h2 class="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
          Everything needed to manage education smarter
        </h2>
        <p class="text-slate-600 dark:text-slate-400 text-lg">
          Comprehensive tools designed for teachers, students, and
          administrators to streamline the academic process.
        </p>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 px-24">
        <!-- Feature 1 -->
        <div class="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 hover:shadow-md transition-shadow">
          <div class="w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-primary mb-4">
            <span class="material-symbols-outlined text-[28px]">calendar_month</span>
          </div>
          <h3 class="text-xl font-bold text-slate-900 dark:text-white mb-2">
            Smart Attendance
          </h3>
          <p class="text-slate-600 dark:text-slate-400 leading-relaxed">
            Effortless digital attendance tracking for teachers. Get accurate
            records and save valuable class time.
          </p>
        </div>
        <!-- Feature 2 -->
        <div class="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 hover:shadow-md transition-shadow">
          <div class="w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-primary mb-4">
            <span class="material-symbols-outlined text-[28px]">chat</span>
          </div>
          <h3 class="text-xl font-bold text-slate-900 dark:text-white mb-2">
            Real-Time Chat
          </h3>
          <p class="text-slate-600 dark:text-slate-400 leading-relaxed">
            Seamless communication channel between teachers and students for
            announcements and discussions.
          </p>
        </div>
        <!-- Feature 3 -->
        <div class="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 hover:shadow-md transition-shadow">
          <div class="w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-primary mb-4">
            <span class="material-symbols-outlined text-[28px]">analytics</span>
          </div>
          <h3 class="text-xl font-bold text-slate-900 dark:text-white mb-2">
            Analytics Reports
          </h3>
          <p class="text-slate-600 dark:text-slate-400 leading-relaxed">
            Visual dashboards providing deep insights into class attendance
            trends and individual student performance.
          </p>
        </div>
        <!-- Feature 4 -->
        <div class="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 hover:shadow-md transition-shadow">
          <div class="w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-primary mb-4">
            <span class="material-symbols-outlined text-[28px]">notification_important</span>
          </div>
          <h3 class="text-xl font-bold text-slate-900 dark:text-white mb-2">
            Low Attendance Alerts
          </h3>
          <p class="text-slate-600 dark:text-slate-400 leading-relaxed">
            Automated notifications sent to students and admins when
            attendance drops below the required threshold.
          </p>
        </div>
        <!-- Feature 5 -->
        <div class="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 hover:shadow-md transition-shadow">
          <div class="w-12 h-12 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-primary mb-4">
            <span class="material-symbols-outlined text-[28px]">lock_person</span>
          </div>
          <h3 class="text-xl font-bold text-slate-900 dark:text-white mb-2">
            Secure Login
          </h3>
          <p class="text-slate-600 dark:text-slate-400 leading-relaxed">
            Role-based access control (RBAC) ensuring data privacy and
            security for Students, Teachers, and Admins.
          </p>
        </div>
      </div>
    </div>
  </div>
  <!-- How It Works Section -->
  <div class="w-full py-20 px-4 md:px-10" id="how-it-works">
    <div class="max-w-[1280px] mx-auto flex flex-col gap-12">
      <div class="flex flex-col gap-4 text-center">
        <h2 class="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
          How EduSmart Works
        </h2>
        <p class="text-slate-600 dark:text-slate-400 text-lg">
          A simple workflow designed for efficiency.
        </p>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 relative">
        <!-- Connecting Line (Desktop) -->
        <div class="hidden lg:block absolute top-12 left-0 w-full h-0.5 bg-slate-200 dark:bg-slate-800 -z-10"></div>
        <!-- Step 1 -->
        <div class="flex flex-col items-center text-center gap-4 bg-background-light dark:bg-background-dark p-4">
          <div class="w-16 h-16 rounded-full bg-primary text-white flex items-center justify-center shadow-lg shadow-blue-500/20 z-10">
            <span class="material-symbols-outlined text-[32px]">edit_square</span>
          </div>
          <div class="flex flex-col gap-2">
            <h3 class="text-lg font-bold text-slate-900 dark:text-white">
              1. Mark Attendance
            </h3>
            <p class="text-sm text-slate-600 dark:text-slate-400">
              Teachers log in and mark daily attendance digitally in seconds.
            </p>
          </div>
        </div>
        <!-- Step 2 -->
        <div class="flex flex-col items-center text-center gap-4 bg-background-light dark:bg-background-dark p-4">
          <div class="w-16 h-16 rounded-full bg-white dark:bg-slate-800 border-2 border-primary text-primary flex items-center justify-center shadow-lg z-10">
            <span class="material-symbols-outlined text-[32px]">visibility</span>
          </div>
          <div class="flex flex-col gap-2">
            <h3 class="text-lg font-bold text-slate-900 dark:text-white">
              2. Track &amp; View
            </h3>
            <p class="text-sm text-slate-600 dark:text-slate-400">
              Students view their real-time attendance percentage on their
              dashboard.
            </p>
          </div>
        </div>
        <!-- Step 3 -->
        <div class="flex flex-col items-center text-center gap-4 bg-background-light dark:bg-background-dark p-4">
          <div class="w-16 h-16 rounded-full bg-white dark:bg-slate-800 border-2 border-primary text-primary flex items-center justify-center shadow-lg z-10">
            <span class="material-symbols-outlined text-[32px]">admin_panel_settings</span>
          </div>
          <div class="flex flex-col gap-2">
            <h3 class="text-lg font-bold text-slate-900 dark:text-white">
              3. Admin Monitor
            </h3>
            <p class="text-sm text-slate-600 dark:text-slate-400">
              Admins oversee reports, analytics, and manage system users.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- User Roles Section -->
  <div class="w-full bg-slate-50 dark:bg-slate-900/50 py-20 px-4 md:px-10" id="roles">
    <div class="max-w-[1280px] mx-auto flex flex-col gap-12">
      <div class="flex flex-col gap-4 text-center">
        <h2 class="text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
          Built for Every Role
        </h2>
        <p class="text-slate-600 dark:text-slate-400 text-lg">
          Tailored interfaces for every stakeholder in the institution.
        </p>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
        <!-- Student Card -->
        <div class="flex flex-col gap-6 p-8 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
          <div class="w-14 h-14 rounded-full bg-green-100 dark:bg-green-900/30 text-green-600 flex items-center justify-center">
            <span class="material-symbols-outlined text-[32px]">school</span>
          </div>
          <div>
            <h3 class="text-2xl font-bold text-slate-900 dark:text-white">
              Student
            </h3>
            <p class="text-slate-500 dark:text-slate-400 mt-2">
              Access learning resources and track progress.
            </p>
          </div>
          <ul class="flex flex-col gap-3 mt-2">
            <li class="flex items-center gap-3 text-slate-700 dark:text-slate-300">
              <span class="material-symbols-outlined text-green-500 text-[20px]">check_circle</span>
              View Attendance
            </li>
            <li class="flex items-center gap-3 text-slate-700 dark:text-slate-300">
              <span class="material-symbols-outlined text-green-500 text-[20px]">check_circle</span>
              Ask Doubts
            </li>
            <li class="flex items-center gap-3 text-slate-700 dark:text-slate-300">
              <span class="material-symbols-outlined text-green-500 text-[20px]">check_circle</span>
              Chat with Teachers
            </li>
          </ul>
        </div>
        <!-- Teacher Card -->
        <div class="flex flex-col gap-6 p-8 rounded-2xl bg-white dark:bg-slate-800 border-2 border-primary/20 shadow-lg hover:-translate-y-1 transition-all duration-300 relative overflow-hidden">
          <div class="absolute top-0 right-0 p-3 bg-primary/10 rounded-bl-2xl">
            <span class="text-xs font-bold text-primary uppercase">Core User</span>
          </div>
          <div class="w-14 h-14 rounded-full bg-blue-100 dark:bg-blue-900/30 text-primary flex items-center justify-center">
            <span class="material-symbols-outlined text-[32px]">cast_for_education</span>
          </div>
          <div>
            <h3 class="text-2xl font-bold text-slate-900 dark:text-white">
              Teacher
            </h3>
            <p class="text-slate-500 dark:text-slate-400 mt-2">
              Manage classrooms and engage with students.
            </p>
          </div>
          <ul class="flex flex-col gap-3 mt-2">
            <li class="flex items-center gap-3 text-slate-700 dark:text-slate-300">
              <span class="material-symbols-outlined text-primary text-[20px]">check_circle</span>
              Mark Attendance
            </li>
            <li class="flex items-center gap-3 text-slate-700 dark:text-slate-300">
              <span class="material-symbols-outlined text-primary text-[20px]">check_circle</span>
              Answer Queries
            </li>
            <li class="flex items-center gap-3 text-slate-700 dark:text-slate-300">
              <span class="material-symbols-outlined text-primary text-[20px]">check_circle</span>
              Broadcast Notices
            </li>
          </ul>
        </div>
        <!-- Admin Card -->
        <div class="flex flex-col gap-6 p-8 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
          <div class="w-14 h-14 rounded-full bg-purple-100 dark:bg-purple-900/30 text-purple-600 flex items-center justify-center">
            <span class="material-symbols-outlined text-[32px]">manage_accounts</span>
          </div>
          <div>
            <h3 class="text-2xl font-bold text-slate-900 dark:text-white">
              Admin
            </h3>
            <p class="text-slate-500 dark:text-slate-400 mt-2">
              Oversee the entire institution's data.
            </p>
          </div>
          <ul class="flex flex-col gap-3 mt-2">
            <li class="flex items-center gap-3 text-slate-700 dark:text-slate-300">
              <span class="material-symbols-outlined text-purple-500 text-[20px]">check_circle</span>
              Monitor Reports
            </li>
            <li class="flex items-center gap-3 text-slate-700 dark:text-slate-300">
              <span class="material-symbols-outlined text-purple-500 text-[20px]">check_circle</span>
              Manage Users
            </li>
            <li class="flex items-center gap-3 text-slate-700 dark:text-slate-300">
              <span class="material-symbols-outlined text-purple-500 text-[20px]">check_circle</span>
              System Settings
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- Footer -->
  <footer class="bg-slate-900 text-slate-300 py-12 px-4 md:px-10 mt-auto border-t border-slate-800">
    <div class="max-w-[1280px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">

      <div class="col-span-1 md:col-span-2 flex flex-col gap-4">
        <div class="flex items-center gap-3 text-white">
          <span class="material-symbols-outlined text-[32px]">school</span>
          <h2 class="text-2xl font-bold">EduSmart</h2>
        </div>
        <p class="text-slate-400 max-w-sm text-sm leading-relaxed">
          A comprehensive smart attendance and learning management system
          designed to modernize educational institutions.
        </p>
      </div>
      <div class="flex flex-col gap-4">
        <h3 class="text-white font-bold text-lg">Platform</h3>
        <div class="flex flex-col gap-2 text-sm">
          <a class="hover:text-primary transition-colors" href="#">Home</a>
          <a class="hover:text-primary transition-colors" href="#features">Features</a>
          <a class="hover:text-primary transition-colors" href="#roles">Roles</a>
          <a class="hover:text-primary transition-colors" href="login.php">Login</a>
        </div>
      </div>

    </div>


    <div class="max-w-[1280px] mx-auto pt-8 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-slate-500">
      <p>&copy; <?php echo date('Y'); ?> EduSmart Project. All rights reserved.</p>
      <div class="flex gap-6">
        <a class="hover:text-white transition-colors" href="#">Privacy Policy</a>
        <a class="hover:text-white transition-colors" href="#">Terms of Service</a>
      </div>
    </div>
  </footer>
</body>

</html>