--
-- Database: `edusmart`
--
CREATE DATABASE IF NOT EXISTS `edusmart` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `edusmart`;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `attendance_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `division_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `attendance_date` date NOT NULL,
  `status` enum('present','absent') NOT NULL DEFAULT 'absent',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `attendance`:
--   `student_id`
--       `students` -> `student_id`
--   `semester_id`
--       `semesters` -> `semester_id`
--   `division_id`
--       `divisions` -> `division_id`
--   `subject_id`
--       `subjects` -> `subject_id`
--   `teacher_id`
--       `teachers` -> `teacher_id`
--

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`attendance_id`, `student_id`, `semester_id`, `division_id`, `subject_id`, `teacher_id`, `attendance_date`, `status`, `created_at`) VALUES
(1, 2, 1, 1, 3, 3, '2026-03-31', 'present', '2026-03-31 15:13:07'),
(2, 2, 1, 1, 3, 3, '2026-03-30', 'present', '2026-03-31 15:13:37'),
(3, 2, 1, 1, 3, 3, '2026-03-27', 'absent', '2026-03-31 15:13:47'),
(4, 2, 1, 1, 3, 3, '2026-03-26', 'present', '2026-03-31 15:13:53'),
(5, 2, 1, 1, 4, 4, '2026-03-31', 'present', '2026-03-31 15:16:54'),
(8, 2, 1, 1, 5, 5, '2026-04-01', 'present', '2026-04-01 10:45:31'),
(9, 3, 1, 1, 5, 5, '2026-04-01', 'present', '2026-04-01 10:45:31'),
(10, 3, 1, 1, 4, 4, '2026-03-31', 'present', '2026-04-02 04:29:02'),
(11, 3, 1, 1, 3, 3, '2026-03-31', 'present', '2026-04-02 05:35:03'),
(12, 2, 1, 1, 2, 2, '2026-04-02', 'present', '2026-04-02 09:19:08'),
(13, 3, 1, 1, 2, 2, '2026-04-02', 'present', '2026-04-02 09:19:08'),
(14, 2, 1, 1, 3, 3, '2026-04-03', 'present', '2026-04-03 09:29:25'),
(15, 4, 1, 1, 3, 3, '2026-04-03', 'present', '2026-04-03 09:29:25'),
(16, 3, 1, 1, 3, 3, '2026-04-03', 'present', '2026-04-03 09:29:25'),
(17, 4, 1, 1, 3, 3, '2026-03-27', 'present', '2026-04-05 09:32:47');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `courses`:
--

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`) VALUES
(1, 'BSc IT');

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

DROP TABLE IF EXISTS `divisions`;
CREATE TABLE `divisions` (
  `division_id` int(11) NOT NULL,
  `division_name` char(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `divisions`:
--

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`division_id`, `division_name`) VALUES
(1, 'A'),
(2, 'B'),
(3, 'C'),
(4, 'D');

-- --------------------------------------------------------

--
-- Table structure for table `division_subject_teacher`
--

DROP TABLE IF EXISTS `division_subject_teacher`;
CREATE TABLE `division_subject_teacher` (
  `dst_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `division_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `division_subject_teacher`:
--   `semester_id`
--       `semesters` -> `semester_id`
--   `division_id`
--       `divisions` -> `division_id`
--   `subject_id`
--       `subjects` -> `subject_id`
--

--
-- Dumping data for table `division_subject_teacher`
--

INSERT INTO `division_subject_teacher` (`dst_id`, `semester_id`, `division_id`, `subject_id`) VALUES
(1, 1, 2, 1),
(2, 1, 2, 2),
(3, 1, 2, 3),
(4, 1, 2, 4),
(5, 1, 2, 5),
(6, 1, 2, 6),
(7, 1, 3, 1),
(8, 1, 3, 2),
(9, 1, 3, 3),
(10, 1, 3, 4),
(11, 1, 3, 5),
(12, 1, 3, 6),
(13, 1, 4, 1),
(14, 1, 4, 2),
(15, 1, 4, 3),
(16, 1, 4, 4),
(17, 1, 4, 5),
(18, 1, 4, 6),
(19, 2, 2, 7),
(20, 2, 2, 8),
(21, 2, 2, 9),
(22, 2, 2, 10),
(23, 2, 2, 11),
(24, 2, 2, 12),
(25, 2, 3, 7),
(26, 2, 3, 8),
(27, 2, 3, 9),
(28, 2, 3, 10),
(29, 2, 3, 11),
(30, 2, 3, 12),
(31, 2, 4, 7),
(32, 2, 4, 8),
(33, 2, 4, 9),
(34, 2, 4, 10),
(35, 2, 4, 11),
(36, 2, 4, 12),
(37, 3, 2, 13),
(38, 3, 2, 14),
(39, 3, 2, 15),
(40, 3, 2, 16),
(41, 3, 2, 17),
(42, 3, 2, 18),
(43, 3, 3, 13),
(44, 3, 3, 14),
(45, 3, 3, 15),
(46, 3, 3, 16),
(47, 3, 3, 17),
(48, 3, 3, 18),
(49, 3, 4, 13),
(50, 3, 4, 14),
(51, 3, 4, 15),
(52, 3, 4, 16),
(53, 3, 4, 17),
(54, 3, 4, 18),
(55, 4, 2, 19),
(56, 4, 2, 20),
(57, 4, 2, 21),
(58, 4, 2, 22),
(59, 4, 2, 23),
(60, 4, 2, 24),
(61, 4, 3, 19),
(62, 4, 3, 20),
(63, 4, 3, 21),
(64, 4, 3, 22),
(65, 4, 3, 23),
(66, 4, 3, 24),
(67, 4, 4, 19),
(68, 4, 4, 20),
(69, 4, 4, 21),
(70, 4, 4, 22),
(71, 4, 4, 23),
(72, 4, 4, 24),
(73, 5, 2, 25),
(74, 5, 2, 26),
(75, 5, 2, 27),
(76, 5, 2, 28),
(77, 5, 2, 29),
(78, 5, 2, 30),
(79, 5, 3, 25),
(80, 5, 3, 26),
(81, 5, 3, 27),
(82, 5, 3, 28),
(83, 5, 3, 29),
(84, 5, 3, 30),
(85, 5, 4, 25),
(86, 5, 4, 26),
(87, 5, 4, 27),
(88, 5, 4, 28),
(89, 5, 4, 29),
(90, 5, 4, 30),
(91, 6, 2, 31),
(92, 6, 2, 32),
(93, 6, 2, 33),
(94, 6, 2, 34),
(95, 6, 2, 35),
(96, 6, 2, 36),
(97, 6, 3, 31),
(98, 6, 3, 32),
(99, 6, 3, 33),
(100, 6, 3, 34),
(101, 6, 3, 35),
(102, 6, 3, 36),
(103, 6, 4, 31),
(104, 6, 4, 32),
(105, 6, 4, 33),
(106, 6, 4, 34),
(107, 6, 4, 35),
(108, 6, 4, 36),
(109, 1, 1, 1),
(110, 1, 1, 2),
(111, 1, 1, 3),
(112, 1, 1, 4),
(113, 1, 1, 5),
(114, 1, 1, 6),
(115, 2, 1, 7),
(116, 2, 1, 8),
(117, 2, 1, 9),
(118, 2, 1, 10),
(119, 2, 1, 11),
(120, 2, 1, 12),
(121, 3, 1, 13),
(122, 3, 1, 14),
(123, 3, 1, 15),
(124, 3, 1, 16),
(125, 3, 1, 17),
(126, 3, 1, 18),
(127, 4, 1, 19),
(128, 4, 1, 20),
(129, 4, 1, 21),
(130, 4, 1, 22),
(131, 4, 1, 23),
(132, 4, 1, 24),
(133, 5, 1, 25),
(134, 5, 1, 26),
(135, 5, 1, 27),
(136, 5, 1, 28),
(137, 5, 1, 29),
(138, 5, 1, 30),
(139, 6, 1, 31),
(140, 6, 1, 32),
(141, 6, 1, 33),
(142, 6, 1, 34),
(143, 6, 1, 35),
(144, 6, 1, 36);

-- --------------------------------------------------------

--
-- Table structure for table `doubts`
--

DROP TABLE IF EXISTS `doubts`;
CREATE TABLE `doubts` (
  `doubt_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `sent_by` enum('student','teacher') NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `doubts`:
--   `student_id`
--       `students` -> `student_id`
--   `teacher_id`
--       `teachers` -> `teacher_id`
--

--
-- Dumping data for table `doubts`
--

INSERT INTO `doubts` (`doubt_id`, `student_id`, `teacher_id`, `message`, `sent_by`, `is_read`, `created_at`) VALUES
(1, 2, 4, 'what is variables?', 'student', 1, '2026-04-06 10:22:13'),
(2, 2, 4, '?', 'student', 1, '2026-04-06 10:27:45'),
(3, 2, 4, 'A variable is a container that stores a value, and that value can be modified during program execution.', 'teacher', 1, '2026-04-06 10:29:54'),
(4, 2, 4, 'thank you!', 'student', 1, '2026-04-06 10:33:03'),
(5, 2, 4, 'what is Data types?', 'student', 1, '2026-04-06 10:50:23'),
(6, 2, 4, 'A data type specifies:\n\nThe type of value (number, character, etc.)\nThe size of memory\nThe range of values', 'teacher', 1, '2026-04-06 10:52:31');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `otp` varchar(6) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `password_resets`:
--

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `email`, `otp`, `expires_at`, `used`, `created_at`) VALUES
(2, 'kalsariyakishan25@gmail.com', '875280', '2026-04-03 12:44:47', 1, '2026-04-03 07:04:47'),
(3, 'kalsariyakishan25@gmail.com', '708264', '2026-04-03 12:47:40', 1, '2026-04-03 07:07:40'),
(4, 'kalsariyakishan25@gmail.com', '579447', '2026-04-03 12:48:55', 1, '2026-04-03 07:08:55'),
(5, '2023040185@vnsgu.ac.in', '535996', '2026-04-03 12:54:16', 1, '2026-04-03 07:14:16'),
(6, '2023040185@vnsgu.ac.in', '991646', '2026-04-03 12:55:58', 1, '2026-04-03 07:15:58');

-- --------------------------------------------------------

--
-- Table structure for table `semesters`
--

DROP TABLE IF EXISTS `semesters`;
CREATE TABLE `semesters` (
  `semester_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `semester_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `semesters`:
--   `course_id`
--       `courses` -> `course_id`
--

--
-- Dumping data for table `semesters`
--

INSERT INTO `semesters` (`semester_id`, `course_id`, `semester_no`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `roll_no` int(11) DEFAULT NULL,
  `gender` enum('male','female') DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `course_id` int(11) DEFAULT 1,
  `semester_id` int(11) DEFAULT NULL,
  `division_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `students`:
--   `user_id`
--       `users` -> `id`
--   `course_id`
--       `courses` -> `course_id`
--   `semester_id`
--       `semesters` -> `semester_id`
--   `division_id`
--       `divisions` -> `division_id`
--

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `user_id`, `first_name`, `last_name`, `roll_no`, `gender`, `dob`, `phone`, `address`, `course_id`, `semester_id`, `division_id`, `created_at`) VALUES
(1, 8, 'kishan', 'kalsariya', 77, 'male', '2004-08-13', '9879282993', 'B-54 Raman Nagar Soc., Ved Road, Surat 395004', 1, 6, 2, '2026-01-31 07:56:42'),
(2, 10, 'aditya', 'gupta', 63, 'male', '2005-04-10', '7622994981', 'althan, surat 4', 1, 1, 1, '2026-02-21 11:54:00'),
(3, 9, 'krunal', 'mandaviya', 115, 'male', '2004-08-12', '6353074507', 'nandanvan soc., surat', 1, 1, 1, '2026-04-01 10:43:45'),
(4, 11, 'himalay', 'malvi', 114, 'male', '2006-06-07', '9173323103', 'narayan soc., surat', 1, 1, 1, '2026-04-02 09:49:27');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
CREATE TABLE `subjects` (
  `subject_id` int(11) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `semester_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `subjects`:
--   `semester_id`
--       `semesters` -> `semester_id`
--

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_id`, `subject_name`, `semester_id`) VALUES
(4, 'C Programming', 1),
(5, 'Communication Skills', 1),
(3, 'Digital Logic', 1),
(2, 'Mathematics I', 1),
(1, 'Programming Fundamentals', 1),
(6, 'Web Basics', 1),
(7, 'Data Structures', 2),
(11, 'DBMS Basics', 2),
(12, 'Environmental Studies', 2),
(8, 'Mathematics II', 2),
(10, 'OOP with C++', 2),
(9, 'Operating Systems', 2),
(14, 'Computer Networks', 3),
(13, 'Java Programming', 3),
(16, 'Python Programming', 3),
(15, 'Software Engineering', 3),
(18, 'Statistics', 3),
(17, 'Web Development I', 3),
(19, 'Advanced Java', 4),
(21, 'Computer Security', 4),
(22, 'Data Warehousing', 4),
(23, 'Linux Administration', 4),
(24, 'Mobile Computing', 4),
(20, 'Web Development II', 4),
(29, 'Advanced PHP', 5),
(26, 'Artificial Intelligence', 5),
(27, 'Big Data Analytics', 5),
(25, 'Cloud Computing', 5),
(28, 'IoT', 5),
(30, 'Research Methodology', 5),
(32, 'Blockchain Technology', 6),
(34, 'Cyber Law', 6),
(33, 'DevOps', 6),
(31, 'Machine Learning', 6),
(36, 'Major Project', 6),
(35, 'Project Management', 6);

-- --------------------------------------------------------

--
-- Table structure for table `subject_teacher_assignment`
--

DROP TABLE IF EXISTS `subject_teacher_assignment`;
CREATE TABLE `subject_teacher_assignment` (
  `assignment_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `division_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `academic_year` varchar(20) NOT NULL,
  `assigned_date` date DEFAULT curdate(),
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `subject_teacher_assignment`:
--   `semester_id`
--       `semesters` -> `semester_id`
--   `division_id`
--       `divisions` -> `division_id`
--   `subject_id`
--       `subjects` -> `subject_id`
--   `teacher_id`
--       `teachers` -> `teacher_id`
--

--
-- Dumping data for table `subject_teacher_assignment`
--

INSERT INTO `subject_teacher_assignment` (`assignment_id`, `semester_id`, `division_id`, `subject_id`, `teacher_id`, `academic_year`, `assigned_date`, `status`) VALUES
(2, 1, 1, 1, 1, '2026-2027', '2026-03-30', 'active'),
(3, 1, 1, 2, 2, '2026-2027', '2026-03-30', 'active'),
(4, 1, 1, 3, 3, '2026-2027', '2026-03-30', 'active'),
(5, 1, 1, 4, 4, '2026-2027', '2026-04-03', 'active'),
(6, 1, 1, 5, 5, '2026-2027', '2026-03-30', 'active'),
(7, 1, 1, 6, 6, '2026-2027', '2026-03-30', 'active'),
(8, 1, 2, 1, 2, '2026-2027', '2026-03-30', 'active'),
(9, 1, 2, 2, 3, '2026-2027', '2026-03-30', 'active'),
(10, 1, 2, 3, 4, '2026-2027', '2026-03-30', 'active'),
(11, 1, 2, 4, 5, '2026-2027', '2026-03-30', 'active'),
(12, 1, 2, 5, 6, '2026-2027', '2026-03-30', 'active'),
(13, 1, 2, 6, 1, '2026-2027', '2026-03-30', 'active'),
(14, 1, 3, 1, 3, '2026-2027', '2026-03-30', 'active'),
(15, 1, 3, 2, 4, '2026-2027', '2026-03-30', 'active'),
(16, 1, 3, 3, 5, '2026-2027', '2026-03-30', 'active'),
(17, 1, 3, 4, 6, '2026-2027', '2026-03-30', 'active'),
(18, 1, 3, 5, 1, '2026-2027', '2026-03-30', 'active'),
(19, 1, 3, 6, 2, '2026-2027', '2026-03-30', 'active'),
(20, 1, 4, 1, 4, '2026-2027', '2026-03-30', 'active'),
(21, 1, 4, 2, 5, '2026-2027', '2026-03-30', 'active'),
(22, 1, 4, 3, 6, '2026-2027', '2026-03-30', 'active'),
(23, 1, 4, 4, 1, '2026-2027', '2026-03-30', 'active'),
(24, 1, 4, 5, 2, '2026-2027', '2026-03-30', 'active'),
(25, 1, 4, 6, 3, '2026-2027', '2026-03-30', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
CREATE TABLE `teachers` (
  `teacher_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `teachers`:
--   `user_id`
--       `users` -> `id`
--

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`teacher_id`, `user_id`, `status`) VALUES
(1, 2, 'active'),
(2, 3, 'active'),
(3, 4, 'active'),
(4, 5, 'active'),
(5, 6, 'active'),
(6, 7, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `teacher_leaves`
--

DROP TABLE IF EXISTS `teacher_leaves`;
CREATE TABLE `teacher_leaves` (
  `leave_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `division_id` int(11) NOT NULL,
  `leave_date` date NOT NULL,
  `reason` varchar(255) DEFAULT '',
  `applied_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `teacher_leaves`:
--   `teacher_id`
--       `teachers` -> `teacher_id`
--   `subject_id`
--       `subjects` -> `subject_id`
--   `semester_id`
--       `semesters` -> `semester_id`
--   `division_id`
--       `divisions` -> `division_id`
--

--
-- Dumping data for table `teacher_leaves`
--

INSERT INTO `teacher_leaves` (`leave_id`, `teacher_id`, `subject_id`, `semester_id`, `division_id`, `leave_date`, `reason`, `applied_at`) VALUES
(5, 4, 4, 1, 1, '2026-04-03', 'fever', '2026-04-03 16:59:23'),
(6, 1, 1, 1, 1, '2026-04-06', '', '2026-04-06 05:13:30');

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

DROP TABLE IF EXISTS `timetable`;
CREATE TABLE `timetable` (
  `timetable_id` int(11) NOT NULL,
  `dst_id` int(11) NOT NULL,
  `day` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `timetable`:
--   `dst_id`
--       `division_subject_teacher` -> `dst_id`
--

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`timetable_id`, `dst_id`, `day`, `start_time`, `end_time`) VALUES
(1, 1, 'Monday', '09:00:00', '10:00:00'),
(2, 2, 'Monday', '10:00:00', '11:00:00'),
(3, 3, 'Tuesday', '09:00:00', '10:00:00'),
(4, 4, 'Tuesday', '10:00:00', '11:00:00'),
(5, 5, 'Wednesday', '09:00:00', '10:00:00'),
(6, 6, 'Wednesday', '10:00:00', '11:00:00'),
(7, 1, 'Thursday', '11:15:00', '12:15:00'),
(8, 2, 'Thursday', '12:15:00', '13:15:00'),
(9, 3, 'Friday', '09:00:00', '10:00:00'),
(10, 4, 'Friday', '10:00:00', '11:00:00'),
(11, 7, 'Monday', '11:15:00', '12:15:00'),
(12, 8, 'Monday', '12:15:00', '13:15:00'),
(13, 9, 'Tuesday', '11:15:00', '12:15:00'),
(14, 10, 'Tuesday', '12:15:00', '13:15:00'),
(15, 11, 'Wednesday', '11:15:00', '12:15:00'),
(16, 12, 'Wednesday', '12:15:00', '13:15:00'),
(17, 7, 'Thursday', '14:00:00', '15:00:00'),
(18, 8, 'Thursday', '09:00:00', '10:00:00'),
(19, 9, 'Friday', '11:15:00', '12:15:00'),
(20, 10, 'Friday', '12:15:00', '13:15:00'),
(21, 13, 'Monday', '14:00:00', '15:00:00'),
(22, 14, 'Monday', '09:00:00', '10:00:00'),
(23, 15, 'Tuesday', '14:00:00', '15:00:00'),
(24, 16, 'Tuesday', '09:00:00', '10:00:00'),
(25, 17, 'Wednesday', '14:00:00', '15:00:00'),
(26, 18, 'Wednesday', '09:00:00', '10:00:00'),
(27, 13, 'Thursday', '11:15:00', '12:15:00'),
(28, 14, 'Thursday', '12:15:00', '13:15:00'),
(29, 15, 'Friday', '14:00:00', '15:00:00'),
(30, 16, 'Friday', '09:00:00', '10:00:00'),
(31, 19, 'Monday', '09:00:00', '10:00:00'),
(32, 20, 'Monday', '10:00:00', '11:00:00'),
(33, 21, 'Tuesday', '09:00:00', '10:00:00'),
(34, 22, 'Tuesday', '10:00:00', '11:00:00'),
(35, 23, 'Wednesday', '09:00:00', '10:00:00'),
(36, 24, 'Wednesday', '10:00:00', '11:00:00'),
(37, 19, 'Thursday', '14:00:00', '15:00:00'),
(38, 20, 'Thursday', '11:15:00', '12:15:00'),
(39, 21, 'Friday', '09:00:00', '10:00:00'),
(40, 22, 'Friday', '10:00:00', '11:00:00'),
(41, 25, 'Monday', '11:15:00', '12:15:00'),
(42, 26, 'Monday', '12:15:00', '13:15:00'),
(43, 27, 'Tuesday', '11:15:00', '12:15:00'),
(44, 28, 'Tuesday', '12:15:00', '13:15:00'),
(45, 29, 'Wednesday', '11:15:00', '12:15:00'),
(46, 30, 'Wednesday', '12:15:00', '13:15:00'),
(47, 25, 'Thursday', '09:00:00', '10:00:00'),
(48, 26, 'Thursday', '10:00:00', '11:00:00'),
(49, 27, 'Friday', '11:15:00', '12:15:00'),
(50, 28, 'Friday', '12:15:00', '13:15:00'),
(51, 31, 'Monday', '09:00:00', '10:00:00'),
(52, 32, 'Monday', '10:00:00', '11:00:00'),
(53, 33, 'Tuesday', '09:00:00', '10:00:00'),
(54, 34, 'Tuesday', '10:00:00', '11:00:00'),
(55, 35, 'Wednesday', '09:00:00', '10:00:00'),
(56, 36, 'Wednesday', '10:00:00', '11:00:00'),
(57, 31, 'Thursday', '14:00:00', '15:00:00'),
(58, 32, 'Thursday', '11:15:00', '12:15:00'),
(59, 33, 'Friday', '09:00:00', '10:00:00'),
(60, 34, 'Friday', '10:00:00', '11:00:00'),
(61, 37, 'Monday', '14:00:00', '15:00:00'),
(62, 38, 'Monday', '09:00:00', '10:00:00'),
(63, 39, 'Tuesday', '14:00:00', '15:00:00'),
(64, 40, 'Tuesday', '09:00:00', '10:00:00'),
(65, 41, 'Wednesday', '14:00:00', '15:00:00'),
(66, 42, 'Wednesday', '09:00:00', '10:00:00'),
(67, 37, 'Thursday', '11:15:00', '12:15:00'),
(68, 38, 'Thursday', '12:15:00', '13:15:00'),
(69, 39, 'Friday', '14:00:00', '15:00:00'),
(70, 40, 'Friday', '09:00:00', '10:00:00'),
(71, 43, 'Monday', '11:15:00', '12:15:00'),
(72, 44, 'Monday', '12:15:00', '13:15:00'),
(73, 45, 'Tuesday', '11:15:00', '12:15:00'),
(74, 46, 'Tuesday', '12:15:00', '13:15:00'),
(75, 47, 'Wednesday', '11:15:00', '12:15:00'),
(76, 48, 'Wednesday', '12:15:00', '13:15:00'),
(77, 43, 'Thursday', '09:00:00', '10:00:00'),
(78, 44, 'Thursday', '10:00:00', '11:00:00'),
(79, 45, 'Friday', '11:15:00', '12:15:00'),
(80, 46, 'Friday', '12:15:00', '13:15:00'),
(81, 49, 'Monday', '09:00:00', '10:00:00'),
(82, 50, 'Monday', '10:00:00', '11:00:00'),
(83, 51, 'Tuesday', '09:00:00', '10:00:00'),
(84, 52, 'Tuesday', '10:00:00', '11:00:00'),
(85, 53, 'Wednesday', '09:00:00', '10:00:00'),
(86, 54, 'Wednesday', '10:00:00', '11:00:00'),
(87, 49, 'Thursday', '11:15:00', '12:15:00'),
(88, 50, 'Thursday', '12:15:00', '13:15:00'),
(89, 51, 'Friday', '09:00:00', '10:00:00'),
(90, 52, 'Friday', '10:00:00', '11:00:00'),
(91, 55, 'Monday', '11:15:00', '12:15:00'),
(92, 56, 'Monday', '12:15:00', '13:15:00'),
(93, 57, 'Tuesday', '11:15:00', '12:15:00'),
(94, 58, 'Tuesday', '12:15:00', '13:15:00'),
(95, 59, 'Wednesday', '11:15:00', '12:15:00'),
(96, 60, 'Wednesday', '12:15:00', '13:15:00'),
(97, 55, 'Thursday', '14:00:00', '15:00:00'),
(98, 56, 'Thursday', '09:00:00', '10:00:00'),
(99, 57, 'Friday', '11:15:00', '12:15:00'),
(100, 58, 'Friday', '12:15:00', '13:15:00'),
(101, 61, 'Monday', '14:00:00', '15:00:00'),
(102, 62, 'Monday', '09:00:00', '10:00:00'),
(103, 63, 'Tuesday', '14:00:00', '15:00:00'),
(104, 64, 'Tuesday', '09:00:00', '10:00:00'),
(105, 65, 'Wednesday', '14:00:00', '15:00:00'),
(106, 66, 'Wednesday', '09:00:00', '10:00:00'),
(107, 61, 'Thursday', '11:15:00', '12:15:00'),
(108, 62, 'Thursday', '12:15:00', '13:15:00'),
(109, 63, 'Friday', '14:00:00', '15:00:00'),
(110, 64, 'Friday', '09:00:00', '10:00:00'),
(111, 67, 'Monday', '09:00:00', '10:00:00'),
(112, 68, 'Monday', '10:00:00', '11:00:00'),
(113, 69, 'Tuesday', '09:00:00', '10:00:00'),
(114, 70, 'Tuesday', '10:00:00', '11:00:00'),
(115, 71, 'Wednesday', '09:00:00', '10:00:00'),
(116, 72, 'Wednesday', '10:00:00', '11:00:00'),
(117, 67, 'Thursday', '14:00:00', '15:00:00'),
(118, 68, 'Thursday', '11:15:00', '12:15:00'),
(119, 69, 'Friday', '09:00:00', '10:00:00'),
(120, 70, 'Friday', '10:00:00', '11:00:00'),
(121, 73, 'Monday', '11:15:00', '12:15:00'),
(122, 74, 'Monday', '12:15:00', '13:15:00'),
(123, 75, 'Tuesday', '11:15:00', '12:15:00'),
(124, 76, 'Tuesday', '12:15:00', '13:15:00'),
(125, 77, 'Wednesday', '11:15:00', '12:15:00'),
(126, 78, 'Wednesday', '12:15:00', '13:15:00'),
(127, 73, 'Thursday', '09:00:00', '10:00:00'),
(128, 74, 'Thursday', '10:00:00', '11:00:00'),
(129, 75, 'Friday', '11:15:00', '12:15:00'),
(130, 76, 'Friday', '12:15:00', '13:15:00'),
(131, 79, 'Monday', '09:00:00', '10:00:00'),
(132, 80, 'Monday', '10:00:00', '11:00:00'),
(133, 81, 'Tuesday', '09:00:00', '10:00:00'),
(134, 82, 'Tuesday', '10:00:00', '11:00:00'),
(135, 83, 'Wednesday', '09:00:00', '10:00:00'),
(136, 84, 'Wednesday', '10:00:00', '11:00:00'),
(137, 79, 'Thursday', '14:00:00', '15:00:00'),
(138, 80, 'Thursday', '11:15:00', '12:15:00'),
(139, 81, 'Friday', '09:00:00', '10:00:00'),
(140, 82, 'Friday', '10:00:00', '11:00:00'),
(141, 85, 'Monday', '14:00:00', '15:00:00'),
(142, 86, 'Monday', '09:00:00', '10:00:00'),
(143, 87, 'Tuesday', '14:00:00', '15:00:00'),
(144, 88, 'Tuesday', '09:00:00', '10:00:00'),
(145, 89, 'Wednesday', '14:00:00', '15:00:00'),
(146, 90, 'Wednesday', '09:00:00', '10:00:00'),
(147, 85, 'Thursday', '11:15:00', '12:15:00'),
(148, 86, 'Thursday', '12:15:00', '13:15:00'),
(149, 87, 'Friday', '14:00:00', '15:00:00'),
(150, 88, 'Friday', '09:00:00', '10:00:00'),
(151, 91, 'Monday', '11:15:00', '12:15:00'),
(152, 92, 'Monday', '12:15:00', '13:15:00'),
(153, 93, 'Tuesday', '11:15:00', '12:15:00'),
(154, 94, 'Tuesday', '12:15:00', '13:15:00'),
(155, 95, 'Wednesday', '11:15:00', '12:15:00'),
(156, 96, 'Wednesday', '12:15:00', '13:15:00'),
(157, 91, 'Thursday', '09:00:00', '10:00:00'),
(158, 92, 'Thursday', '10:00:00', '11:00:00'),
(159, 93, 'Friday', '11:15:00', '12:15:00'),
(160, 94, 'Friday', '12:15:00', '13:15:00'),
(161, 97, 'Monday', '09:00:00', '10:00:00'),
(162, 98, 'Monday', '10:00:00', '11:00:00'),
(163, 99, 'Tuesday', '09:00:00', '10:00:00'),
(164, 100, 'Tuesday', '10:00:00', '11:00:00'),
(165, 101, 'Wednesday', '09:00:00', '10:00:00'),
(166, 102, 'Wednesday', '10:00:00', '11:00:00'),
(167, 97, 'Thursday', '11:15:00', '12:15:00'),
(168, 98, 'Thursday', '12:15:00', '13:15:00'),
(169, 99, 'Friday', '09:00:00', '10:00:00'),
(170, 100, 'Friday', '10:00:00', '11:00:00'),
(171, 103, 'Monday', '11:15:00', '12:15:00'),
(172, 104, 'Monday', '12:15:00', '13:15:00'),
(173, 105, 'Tuesday', '11:15:00', '12:15:00'),
(174, 106, 'Tuesday', '12:15:00', '13:15:00'),
(175, 107, 'Wednesday', '11:15:00', '12:15:00'),
(176, 108, 'Wednesday', '12:15:00', '13:15:00'),
(177, 103, 'Thursday', '14:00:00', '15:00:00'),
(178, 104, 'Thursday', '09:00:00', '10:00:00'),
(179, 105, 'Friday', '11:15:00', '12:15:00'),
(180, 106, 'Friday', '12:15:00', '13:15:00'),
(181, 109, 'Monday', '14:00:00', '15:00:00'),
(182, 110, 'Monday', '09:00:00', '10:00:00'),
(183, 111, 'Tuesday', '14:00:00', '15:00:00'),
(184, 112, 'Tuesday', '09:00:00', '10:00:00'),
(185, 113, 'Wednesday', '14:00:00', '15:00:00'),
(186, 114, 'Wednesday', '09:00:00', '10:00:00'),
(187, 109, 'Thursday', '11:15:00', '12:15:00'),
(188, 110, 'Thursday', '12:15:00', '13:15:00'),
(189, 111, 'Friday', '14:00:00', '15:00:00'),
(190, 112, 'Friday', '09:00:00', '10:00:00'),
(191, 115, 'Monday', '09:00:00', '10:00:00'),
(192, 116, 'Monday', '10:00:00', '11:00:00'),
(193, 117, 'Tuesday', '09:00:00', '10:00:00'),
(194, 118, 'Tuesday', '10:00:00', '11:00:00'),
(195, 119, 'Wednesday', '09:00:00', '10:00:00'),
(196, 120, 'Wednesday', '10:00:00', '11:00:00'),
(197, 115, 'Thursday', '14:00:00', '15:00:00'),
(198, 116, 'Thursday', '11:15:00', '12:15:00'),
(199, 117, 'Friday', '09:00:00', '10:00:00'),
(200, 118, 'Friday', '10:00:00', '11:00:00'),
(201, 121, 'Monday', '11:15:00', '12:15:00'),
(202, 122, 'Monday', '12:15:00', '13:15:00'),
(203, 123, 'Tuesday', '11:15:00', '12:15:00'),
(204, 124, 'Tuesday', '12:15:00', '13:15:00'),
(205, 125, 'Wednesday', '11:15:00', '12:15:00'),
(206, 126, 'Wednesday', '12:15:00', '13:15:00'),
(207, 121, 'Thursday', '09:00:00', '10:00:00'),
(208, 122, 'Thursday', '10:00:00', '11:00:00'),
(209, 123, 'Friday', '11:15:00', '12:15:00'),
(210, 124, 'Friday', '12:15:00', '13:15:00'),
(211, 127, 'Monday', '09:00:00', '10:00:00'),
(212, 128, 'Monday', '10:00:00', '11:00:00'),
(213, 129, 'Tuesday', '09:00:00', '10:00:00'),
(214, 130, 'Tuesday', '10:00:00', '11:00:00'),
(215, 131, 'Wednesday', '09:00:00', '10:00:00'),
(216, 132, 'Wednesday', '10:00:00', '11:00:00'),
(217, 127, 'Thursday', '14:00:00', '15:00:00'),
(218, 128, 'Thursday', '11:15:00', '12:15:00'),
(219, 129, 'Friday', '09:00:00', '10:00:00'),
(220, 130, 'Friday', '10:00:00', '11:00:00'),
(221, 133, 'Monday', '14:00:00', '15:00:00'),
(222, 134, 'Monday', '09:00:00', '10:00:00'),
(223, 135, 'Tuesday', '14:00:00', '15:00:00'),
(224, 136, 'Tuesday', '09:00:00', '10:00:00'),
(225, 137, 'Wednesday', '14:00:00', '15:00:00'),
(226, 138, 'Wednesday', '09:00:00', '10:00:00'),
(227, 133, 'Thursday', '11:15:00', '12:15:00'),
(228, 134, 'Thursday', '12:15:00', '13:15:00'),
(229, 135, 'Friday', '14:00:00', '15:00:00'),
(230, 136, 'Friday', '09:00:00', '10:00:00'),
(231, 139, 'Monday', '11:15:00', '12:15:00'),
(232, 140, 'Monday', '12:15:00', '13:15:00'),
(233, 141, 'Tuesday', '11:15:00', '12:15:00'),
(234, 142, 'Tuesday', '12:15:00', '13:15:00'),
(235, 143, 'Wednesday', '11:15:00', '12:15:00'),
(236, 144, 'Wednesday', '12:15:00', '13:15:00'),
(237, 139, 'Thursday', '09:00:00', '10:00:00'),
(238, 140, 'Thursday', '10:00:00', '11:00:00'),
(239, 141, 'Friday', '11:15:00', '12:15:00'),
(240, 142, 'Friday', '12:15:00', '13:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `uid` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','teacher','student') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `users`:
--

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `uid`, `password`, `role`, `created_at`) VALUES
(1, 'admin', 'admin@edusmart.com', 'admin001', '$2y$10$wLqg1Pxei5g5vQrB2idiouahVgXSDYl5sMPb7pJruxjNTnr0MTtuy', 'admin', '2026-01-17 07:29:41'),
(2, 'prof. Mehta', 'mehta@gmail.com', '1456', '$2y$10$l.lGUZt4wKXDRkDG6ca6OuSJsv/lCxEe6s.9goqSm9ClX8aMo/WKS', 'teacher', '2026-01-26 09:24:09'),
(3, 'prof. Sharma', 'sharma@gmail.com', '1457', '$2y$10$YBtshZ1xScrjDmmfEZEx0.mxydKJCWC.b/fA3Dj8q5jHpruiGnj/2', 'teacher', '2026-01-26 09:25:08'),
(4, 'prof. Patel', 'patel@gmail.com', '1458', '$2y$10$RMMKUHm3E54Ea/FEQYBm2uSvxi.uejMY2jRYyYm2C2mFyp/rvFZda', 'teacher', '2026-01-26 09:25:41'),
(5, 'prof. Iyer', 'iyer@gmail.com', '1459', '$2y$10$XKkGmedOwHfYL0TPQ/gp8e.DJ5ut3K4GAtqpp1TCLoYrVmMrPweae', 'teacher', '2026-01-26 09:26:11'),
(6, 'prof. Desai', 'desai@gmail.com', '1460', '$2y$10$VVvxikUeUy0FsFQoKsdKguasJFa7J0ydAorjGivxnnFvHdnyS7fX.', 'teacher', '2026-01-26 09:26:51'),
(7, 'prof. Joshi', 'joshi@gmail.com', '1461', '$2y$10$aQncrAsYfznRq58RsuXWGunl1k/06IgAYQYjKBTF2FS11ustLEtc.', 'teacher', '2026-01-26 09:27:21'),
(8, 'kishan', 'kishan25@gmail.com', '2023040185', '$2y$10$CvnXHFNGbkTm3n0wAxbqu.KaSd/rjwnfYLeywAQrTr/MdFQnyiqB6', 'student', '2026-01-31 04:37:48'),
(9, 'krunal mandaviya', 'krunal@gmail.com', '2023040223', '$2y$10$st6mEEdOefrJWpOoQUKVsudgvfmBBgc/fQ..V8UgwzNHP6/rv7pVC', 'student', '2026-02-01 10:17:26'),
(10, 'aditya gupta', 'kalsariyakishan25@gmail.com', '2023040174', '$2y$10$eNWxwKSqXv.xYH6905aC..1VQykYQ6WBAaSi2dCkEtDTkwy7bC0DC', 'student', '2026-02-21 11:52:33'),
(11, 'himalay', 'himalay@gmail.com', '20230222', '$2y$10$VudVnjdrUdXzMxSuycYiKeRoUK1n2Y5WjpwXdn9Q5GWLVgTu5wKuu', 'student', '2026-04-02 09:46:01'),
(14, 'manthan khuman', 'manthan@gmail.com', '2023040200', '$2y$10$5S6McP3qOyFTUjVYYHK4MeGYDZ7lrDC4q57Gk7fcwW0gFpxpRS9x2', 'student', '2026-04-03 11:25:14'),
(15, 'abc', 'abc@gmail.com', '202340300', '$2y$10$Q3e1eeBIrm6/kMnosk/cPOdeqmBtdbP111eKYQpCaGXCNxbX0T9hO', 'student', '2026-04-04 09:45:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendance_id`),
  ADD UNIQUE KEY `uq_attendance` (`student_id`,`subject_id`,`attendance_date`),
  ADD KEY `semester_id` (`semester_id`),
  ADD KEY `division_id` (`division_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`),
  ADD UNIQUE KEY `course_name` (`course_name`);

--
-- Indexes for table `divisions`
--
ALTER TABLE `divisions`
  ADD PRIMARY KEY (`division_id`);

--
-- Indexes for table `division_subject_teacher`
--
ALTER TABLE `division_subject_teacher`
  ADD PRIMARY KEY (`dst_id`),
  ADD UNIQUE KEY `division_id` (`division_id`,`subject_id`),
  ADD KEY `semester_id` (`semester_id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `doubts`
--
ALTER TABLE `doubts`
  ADD PRIMARY KEY (`doubt_id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `idx_conversation` (`student_id`,`teacher_id`,`created_at`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_email` (`email`);

--
-- Indexes for table `semesters`
--
ALTER TABLE `semesters`
  ADD PRIMARY KEY (`semester_id`),
  ADD UNIQUE KEY `course_id` (`course_id`,`semester_no`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD UNIQUE KEY `unique_roll_sem` (`roll_no`,`semester_id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `semester_id` (`semester_id`),
  ADD KEY `division_id` (`division_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`),
  ADD UNIQUE KEY `semester_id` (`semester_id`,`subject_name`);

--
-- Indexes for table `subject_teacher_assignment`
--
ALTER TABLE `subject_teacher_assignment`
  ADD PRIMARY KEY (`assignment_id`),
  ADD UNIQUE KEY `unique_assignment` (`semester_id`,`division_id`,`subject_id`,`academic_year`),
  ADD KEY `division_id` (`division_id`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`teacher_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `teacher_leaves`
--
ALTER TABLE `teacher_leaves`
  ADD PRIMARY KEY (`leave_id`),
  ADD UNIQUE KEY `uq_leave` (`teacher_id`,`subject_id`,`semester_id`,`division_id`,`leave_date`),
  ADD KEY `subject_id` (`subject_id`),
  ADD KEY `semester_id` (`semester_id`),
  ADD KEY `division_id` (`division_id`);

--
-- Indexes for table `timetable`
--
ALTER TABLE `timetable`
  ADD PRIMARY KEY (`timetable_id`),
  ADD KEY `dst_id` (`dst_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `divisions`
--
ALTER TABLE `divisions`
  MODIFY `division_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `division_subject_teacher`
--
ALTER TABLE `division_subject_teacher`
  MODIFY `dst_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT for table `doubts`
--
ALTER TABLE `doubts`
  MODIFY `doubt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `semesters`
--
ALTER TABLE `semesters`
  MODIFY `semester_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `subject_teacher_assignment`
--
ALTER TABLE `subject_teacher_assignment`
  MODIFY `assignment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `teacher_leaves`
--
ALTER TABLE `teacher_leaves`
  MODIFY `leave_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `timetable`
--
ALTER TABLE `timetable`
  MODIFY `timetable_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=241;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`semester_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_ibfk_3` FOREIGN KEY (`division_id`) REFERENCES `divisions` (`division_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_ibfk_4` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_ibfk_5` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE;

--
-- Constraints for table `division_subject_teacher`
--
ALTER TABLE `division_subject_teacher`
  ADD CONSTRAINT `division_subject_teacher_ibfk_1` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`semester_id`),
  ADD CONSTRAINT `division_subject_teacher_ibfk_2` FOREIGN KEY (`division_id`) REFERENCES `divisions` (`division_id`),
  ADD CONSTRAINT `division_subject_teacher_ibfk_3` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`);

--
-- Constraints for table `doubts`
--
ALTER TABLE `doubts`
  ADD CONSTRAINT `doubts_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `doubts_ibfk_2` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE;

--
-- Constraints for table `semesters`
--
ALTER TABLE `semesters`
  ADD CONSTRAINT `semesters_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `students_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`),
  ADD CONSTRAINT `students_ibfk_3` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`semester_id`),
  ADD CONSTRAINT `students_ibfk_4` FOREIGN KEY (`division_id`) REFERENCES `divisions` (`division_id`);

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`semester_id`);

--
-- Constraints for table `subject_teacher_assignment`
--
ALTER TABLE `subject_teacher_assignment`
  ADD CONSTRAINT `subject_teacher_assignment_ibfk_1` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`semester_id`),
  ADD CONSTRAINT `subject_teacher_assignment_ibfk_2` FOREIGN KEY (`division_id`) REFERENCES `divisions` (`division_id`),
  ADD CONSTRAINT `subject_teacher_assignment_ibfk_3` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`),
  ADD CONSTRAINT `subject_teacher_assignment_ibfk_4` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`);

--
-- Constraints for table `teachers`
--
ALTER TABLE `teachers`
  ADD CONSTRAINT `teachers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `teacher_leaves`
--
ALTER TABLE `teacher_leaves`
  ADD CONSTRAINT `teacher_leaves_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `teacher_leaves_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `teacher_leaves_ibfk_3` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`semester_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `teacher_leaves_ibfk_4` FOREIGN KEY (`division_id`) REFERENCES `divisions` (`division_id`) ON DELETE CASCADE;

--
-- Constraints for table `timetable`
--
ALTER TABLE `timetable`
  ADD CONSTRAINT `timetable_ibfk_1` FOREIGN KEY (`dst_id`) REFERENCES `division_subject_teacher` (`dst_id`);
SET FOREIGN_KEY_CHECKS=1;
COMMIT;
